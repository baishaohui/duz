from flask import render_template
from app import create_app
from app.web.models import UserProfile
from app import login_manager

app = create_app()


@login_manager.user_loader
def load_user(user_id):
    return UserProfile.query.get(user_id)


if __name__ == '__main__':
    app.run()


