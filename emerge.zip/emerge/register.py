# -*- coding: utf-8 -*-
from app import app
from app.web.models import UserProfile
from app.web.models import db
from app.web.permission import PERMISSION_DICT

ROLE_LIST = PERMISSION_DICT.keys()


def user_register(*args):
    if args[-1] not in ROLE_LIST:
        print("Register failed, message: role should be %s." % " or ".join(ROLE_LIST))
        return
    app.app_context().push()
    with app.app_context():
        new_user = UserProfile(*args)
        db.session.add(new_user)
        db.session.commit()
        print("Register success")


if __name__ == '__main__':
    import sys
    print(sys.argv)
    module_name, *profile = sys.argv
    user_register(*profile)