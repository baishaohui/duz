# -*- coding: utf-8 -*-

title_list = [
    "漏洞名称(名称)", "漏洞中文描述(描述)", "CVE编号(选填)", "Bugraq ID(选填)",
    "漏洞影响对象类型(非空)", "厂商(非空)", "产品(非空)", "版本号(选填)",
    "最早公开时间(非空)", "安全建议(非空)", "原始信息来源(非空)", "补丁链接(选填)",
    "验证POC(选填)", "验证信息参考链接(选填)", "攻击途径(选填)", "攻击复杂度(选填)",
    "认证(选填)", "机密性(选填)", "完整性(选填)", "可用性(选填)"]

CONVERT_INTO_CHINESE = {
    "attack_vector": {
        "NETWORK": "远程网络",
        "LOCAL": "本地",
        "ADJACENT_NETWORK": "相邻网络",
        "default": "相邻网络"
    },
    "attack_complexity": {
        "HIGH": "高",
        "LOW": "低",
        "NONE": "低",
        "default": "低"
    },
    "privileges_required": {
        "HIGH": "多次",
        "LOW": "一次",
        "NONE": "不需要认证",
        "default": "不需要认证"
    },
    "confidentiality_impact": {
        "HIGH": "完全地",
        "LOW": "部分地",
        "NONE": "不受影响",
        "default": "不受影响"
    },
    "integrity_impact": {
        "HIGH": "完全地",
        "LOW": "部分地",
        "NONE": "不受影响",
        "default": "不受影响"
    },
    "availability_impact": {
        "HIGH": "完全地",
        "LOW": "部分地",
        "NONE": "不受影响",
        "default": "不受影响"
    },
    "product_type": {
        "Application": "应用程序",
        "OS": "操作系统",
        "default": "应用程序"
    }
}

CONVERT_INTO_FULL_VALUE = {
    "attack_vector": {
        "N": "NETWORK",
        "L": "LOCAL",
        "A": "ADJACENT_NETWORK"
    },
    "attack_complexity": {
        "H": "HIGH",
        "L": "LOW",
        "N": "NONE"
    },
    "privileges_required": {
        "H": "HIGH",
        "L": "LOW",
        "N": "NONE"
    },
    "confidentiality_impact": {
        "H": "HIGH",
        "L": "LOW",
        "N": "NONE"
    },
    "integrity_impact": {
        "H": "HIGH",
        "L": "LOW",
        "N": "NONE"
    },
    "availability_impact": {
        "H": "HIGH",
        "L": "LOW",
        "N": "NONE"
    },
    "product_type": {
        "Application": "应用程序",
        "OS": "操作系统",
        "default": "应用程序"
    }
}


cpe_sql_start = """
select REPLACE(version_start_including, '\\\\', '') from 
cpes WHERE nvd_json_id=(select id from nvd_jsons where cve_id=:cve_id)
 AND version_start_including <> '' ORDER BY version_start_including ASC 
"""

cpe_sql_end = """
select REPLACE(version_end_excluding, '\\\\', '') from 
cpes WHERE nvd_json_id=(select id from nvd_jsons where cve_id=:cve_id)
 AND version_end_excluding <> '' ORDER BY version_end_excluding DESC 
"""

complex_excel_sql = """
    SELECT 
        A.cve_id,
        A.version_start_including,
        A.version_end_excluding,
        "" AS bugraq_id,
        vul_new_pre.cpe,
        vul_new_pre.title_cn,
        vul_new_pre.summary_cn,
        vul_new_pre.product_type,
        vul_new_pre.vendor,
        vul_new_pre.product,
        DATE_FORMAT(vul_new_pre.release_time, "%Y/%m/%d") AS release_time,
        vul_new_pre.solution_cn,
        vul_new_pre.reference,
        vul_new_pre.cvss3_vector
    FROM 
    (
    SELECT 
      T.nvd_json_id,
        T.cve_id,
        T.attack_vector,
        T.vector_string,
        T.attack_complexity,
        T.availability_impact,
        T.privileges_required,
        T.integrity_impact,
        T.confidentiality_impact,
        cpes.version_start_including,
        cpes.version_end_excluding
    FROM 
    (
    SELECT
        cvss3.nvd_json_id AS nvd_json_id,
        nvd_jsons.cve_id AS cve_id,
        cvss3.attack_vector AS attack_vector,
        cvss3.vector_string AS vector_string,
        cvss3.privileges_required AS privileges_required,
        cvss3.attack_complexity AS attack_complexity,
        cvss3.availability_impact AS availability_impact,
        cvss3.integrity_impact AS integrity_impact,
        cvss3.confidentiality_impact AS confidentiality_impact
    FROM
        nvd_jsons
        LEFT JOIN cvss3 ON cvss3.nvd_json_id = nvd_jsons.id 
    HAVING
        nvd_jsons.cve_id in {cve_id_list}
    )T LEFT JOIN cpes ON cpes.nvd_json_id=T.nvd_json_id
    )A LEFT JOIN vul_new_pre ON vul_new_pre.cve_id=A.cve_id
"""
