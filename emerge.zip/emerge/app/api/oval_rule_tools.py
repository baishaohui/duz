# -*- coding: utf-8 -*-
import re
import json

from xml.etree import cElementTree as etree_
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker


Base = declarative_base()
metadata = Base.metadata

db = create_engine('mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/vul_db')


def fetch_rules():
    DBSession = sessionmaker(bind=db)
    session = DBSession()
    sql = """
        SELECT
            vul_rule_usn_aid.rule_name AS rule_name,
            vul_rule_usn_aid.alias_name AS alias_name,
            vul_oval_rule.system_name AS system_name,
            vul_oval_rule.rule_detail AS rule_detail,
            vul_rule_usn_aid.aid AS aid,
            vul_oval_rule.`status` AS `status`
        FROM
            vul_rule_usn_aid
            LEFT JOIN vul_oval_rule ON vul_rule_usn_aid.rule_name = vul_oval_rule.rule_name 
        HAVING
            (
                vul_oval_rule.`status` = 1 
                AND vul_oval_rule.system_name IN 
                ('redhat6', 'redhat7', 'ubuntu_bionic', 'ubuntu_trusty', 'ubuntu_xenial')		
                AND  vul_rule_usn_aid.aid NOT IN ('', '0')
            ) 
    """
    result = session.execute(sql)
    session.close()
    return result.fetchall()


def version_formatter(info):
    version_list = info.split("\n")
    latest_version = version_list[0]
    if latest_version:
        app, version, *_ = latest_version.split(" | ")
        return version


def parse(doc_):
    root = etree_.fromstring(doc_)
    separator = "is earlier than"
    ubuntu_separator = "been fixed"
    detail = {}
    for a in root.iter():
        comment = a.get("comment")
        if comment is not None:
            if separator in comment:
                product, version = comment.split(separator)
            elif ubuntu_separator in comment:
                match = re.search("The '(.*)'.*'(.*)'", comment)
                if not match:
                    match = re.search("(\S+) package .*'(.*)'", comment)
                    if not match:
                        print(comment)
                product = match.group(1)
                version = match.group(2)
            else:
                continue
            product = product.strip()
            version = version.strip()
            if product in detail:
                detail[product].add(version)
            else:
                detail[product] = {version}
    return detail


if __name__ == '__main__':
    doc = """
   <criteria xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5">
                <extend_definition definition_ref="oval:com.ubuntu.bionic:def:100" comment="Ubuntu 18.04 LTS (bionic) is installed." applicability_check="true"/>
                <criteria operator="OR">
                    <criterion test_ref="oval:com.ubuntu.bionic:tst:201810600000000" comment="python2.7 package in bionic, is related to the CVE in some way and has been fixed (note: '2.7.15~rc1-1')."/>
                    <criterion test_ref="oval:com.ubuntu.bionic:tst:201810600000010" comment="python3.6 package in bionic, is related to the CVE in some way and has been fixed (note: '3.6.6-1~18.04')."/>
                    <criterion test_ref="oval:com.ubuntu.bionic:tst:201810600000020" comment="python3.7 package in bionic, is related to the CVE in some way and has been fixed (note: '3.7.0~b3-1')."/>
                </criteria>
            </criteria>
    """
    print(parse(doc))