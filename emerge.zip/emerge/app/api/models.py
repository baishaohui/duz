# -*- coding: utf-8 -*-
import datetime

from contextlib import contextmanager
from flask_sqlalchemy import SQLAlchemy as _SQLAlchemy
from sqlalchemy import Column, Integer, String, DateTime, Text

from utils.compare_version import v_compare
from app import db


class RuleProduct(db.Model):
    __tablename__ = "vul_rule_product"
    id = Column(Integer, primary_key=True, comment="主键")
    gmt_create = Column(DateTime, default=datetime.datetime.now, nullable=False, comment="创建时间")
    gmt_modified = Column(DateTime, default=datetime.datetime.now, nullable=False, comment="修改时间")
    rule_name = db.Column(db.String(128), nullable=False, unique=True, comment="漏洞名称")
    alias_name = db.Column(db.String(128), nullable=True, default=None, comment="漏洞别名")
    system_name = db.Column(db.String(64), nullable=False, comment="操作系统名称")
    status = db.Column(db.Integer, nullable=False, comment="状态")
    product = db.Column(db.String(256), nullable=False, comment="产品")
    versions = db.Column(db.String(256), nullable=True, comment="版本")
    available_version =db.Column(db.String(128), nullable=True, comment="最新版本")

    def ping(self):
        self.gmt_modified = datetime.datetime.now()

    def diff_version(self, available_version):
        return v_compare(self.versions, available_version)

    @staticmethod
    def diff(version1, version2):
        return v_compare(version1, version2)