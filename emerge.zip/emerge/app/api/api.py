# -*- coding: utf-8 -*-
import json
import re
import zipfile
from io import BytesIO
from urllib.parse import quote
from concurrent.futures import ThreadPoolExecutor

import os

import datetime
import paramiko
import sys
from flask import jsonify, request, stream_with_context, Response, send_file, make_response
from flask.blueprints import Blueprint
from flask_login import login_required

from app.api.oval_rule_tools import fetch_rules, parse
from app.api.tool import convert_to_excel
from app.web.permission import permission_required
from utils.error_hunter import ding_reporter
from .models import RuleProduct
from app.web.models import VulNew, KBModel, VulNewPre
# from .models import db
from app import db
from app.web.models import RuleUsnAid
from app.viewmodel.vulnerability import VulnerabilityViewModel

api = Blueprint("api", __name__)
worker = ThreadPoolExecutor(max_workers=1)
KB_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(KB_BASE_DIR)

SERVER_CONFIG = {
    "redhat6": ["121.40.87.23", "root", "Alibaba40dadao"],
    "redhat7": ["121.40.69.80", "root", "Alibaba40dadao"],
    "ubuntu_bionic": ["116.62.226.203", "root", "Alibaba40dadao"],
    "ubuntu_trusty": ["47.111.86.200", "root", "Alibaba40dadao"],
    "ubuntu_xenial": ["47.111.91.61", "root", "Alibaba40dadao"]
}

COMMANDS = ["apt-cache madison %s", "yum list %s"]

id_reg = re.compile("^(CVE|CMS|APP|AVE)-\d+-\d+$", re.IGNORECASE)
# ACCESS_TOKEN = "ZFo4OTNUTTdXNEcxUm4xeEdIYnU2bUY3SWdhUGlyRWo="
lang_list = ["en", "cn"]


@api.route("/detail/vul.json", endpoint="vul", methods=["GET"])
def vul_detail():
    result_json = {
        "code": 404,
        "msg": "not found"
    }
    cve_id = request.args.get("id", "")
    token = request.args.get("token", "")
    avd_id = cve_id.lower()
    if not authenticate(cve_id, token):
        return jsonify(result_json)
    obj = VulNew.query.filter_by(avd_id="AVD-" + avd_id).first()
    if not obj:
        return jsonify(result_json)
    lang = request.args.get("lang", "cn")
    lang = lang if lang in lang_list else "cn"
    view_model = VulnerabilityViewModel(obj, lang=lang)
    result_json["code"] = 200
    result_json["msg"] = "ok"
    result_json.update(view_model.api_attr)
    return jsonify(result_json)


def authenticate(adv_id, token):
    id_auth = re.match(id_reg, adv_id)
    # token_auth = (ACCESS_TOKEN == token)
    return id_auth and 1


@api.route("/check/rule", endpoint="check_rule", methods=["POST"])
def check_rule():
    rules = request.form.getlist("rules")
    response = {"status": 200}
    if not rules:
        response["status"] = 400
        response["msg"] = "no rule accepted"
        return jsonify(response)
    data = {}
    for rule in rules:
        rule_obj = RuleUsnAid.query.filter_by(rule_name=rule).first()
        if not rule_obj:
            response["status"] = 404
            response["msg"] = "rule not found!"
            response["target"] = rule_obj.rule_name
            return jsonify(response)
        rule_product = RuleProduct.query.filter_by(rule_name=rule).all()
        if not rule_product:
            continue
        system_name = rule_product[0].system_name
        multi_latest = get_multi_latest(system_name, rule_product)
        available, multi_latest = check_rule_availability(multi_latest)
        if available != rule_obj.available:
            # RuleUsnAid.query.filter_by(id=rule_obj.id).update({"available": available})
            rule_obj.available = available
            db.session.commit()
        data.setdefault(rule, multi_latest)
    response["data"] = data
    return jsonify(response)


@api.route("/update/oval/rules", endpoint="update_oval", methods=["POST"])
def update_product_version():
    """更新未上线、有公告规则的product、version"""
    all_rules = fetch_rules()
    total = len(all_rules)
    response = {"code": 200, "msg": "ok", "count": total}
    if not all_rules:
        response["code"] = 404
        response["msg"] = "rule not found"
        return jsonify(response)
    worker.submit(update_product, all_rules)
    return jsonify(response)


@api.route("/export/kb", endpoint="top_kb")
def export_kb():
    # files = {
    #     "2003_r2": {
    #         "month": [
    #               {"month": "", "sec": ""},
    #               ...
    #           ]
    #         "KBlist": [
    #             {"KBID": kb,
    #              "details": [
    #                  {"bit": 64, "patch": "xxxx"}
    #              ]
    #              }]
    #           }
    #     }
    files = {}
    for kb in KBModel.query.order_by(KBModel.product.asc()).all():
        if not kb.product:
            print("Product of %s is null" % kb.kb)
            continue
        if kb.is_top:
            key_list = re.findall("\d\d\d\d", kb.product)
            if kb.architecture == "x86":
                bit = "32"
            else:
                bit = "64"
            if key_list:
                if "R2" in kb.product:
                    key_list.append("R2")
                if "SP1" in kb.product:
                    key_list.append("SP1")
                if "SP2" in kb.product:
                    key_list.append("SP2")
            key = "_".join(key_list)
            if not files.get(key):
                files[key] = {
                    "month": [],
                    "KBlist": [{"KBID": kb.kb, "details": []}]}
            i = None
            for index, item in enumerate(files[key]["KBlist"]):
                if item.get("KBID") == kb.kb:
                    i = index
                    files[key]["KBlist"][index]["details"].append({"bit": bit, "patch": kb.files})
                    break
            if i is None:
                files[key]["KBlist"].append({"KBID": kb.kb, "details": [{"bit": bit, "patch": kb.files}]})
            if not files[key]["month"]:
                month = [{"month": item.kb, "sec": item.all_security_kb}
                         for item in KBModel.query.with_entities(
                        KBModel.kb, KBModel.all_security_kb).filter(
                        KBModel.product == kb.product, KBModel.monthly_rollup == True).distinct(KBModel.kb)]

                files[key]["month"] = month
    memory_file = BytesIO()
    zf = zipfile.ZipFile(memory_file, "w", compression=zipfile.ZIP_DEFLATED)

    for name, file in files.items():
        # print(name, len(file))
        zf.writestr("%s.json" % name, json.dumps(file, indent=2))
    zf.close()
    memory_file.seek(0)
    response = Response(stream_with_context(memory_file), mimetype="application/zip")
    response.headers['Content-Disposition'] = 'attachment; filename=kb.gz'
    return response


@api.route("/init/kb/status", endpoint="init_top")
@login_required
@permission_required
def init_top():
    response = {"code": 200, "msg": ""}
    try:
        KBModel.fresh()
    except Exception as e:
        response["code"] = 500
        response["msg"] = str(e)
    return jsonify(response)


@api.route("/export/cnvd", endpoint="cnvd")
def cnvd():
    cves = VulNewPre.get_vul_from_last_month()
    print(len(cves))
    excel_data = [cve.export_excel_values() for cve in cves]
    sio = convert_to_excel(excel_data)
    resp = make_response(sio.getvalue())
    filename = quote(f"阿里云-{datetime.date.today().strftime('%Y%m%d')}.xls")
    resp.headers["Content-Disposition"] = "attachment; filename*=utf-8''{}".format(
        filename)
    resp.headers['Content-Type'] = 'application/x-xls'
    return resp


def ssh_connect(hostname, user, pwd):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname, 22, user, pwd)
    return ssh


def get_latest(ssh, rule_obj):
    """获取单个rule product的产品版本"""
    product = rule_obj.product
    system_name = rule_obj.system_name
    command = get_command(system_name, product)
    result = execute_command(ssh, command)
    return fetch_latest(system_name, result)


def get_multi_latest(system_name, rule_products):
    """连接ssh并获取某一个rule下的所有产品的latest version"""
    server_cfg = SERVER_CONFIG.get(system_name)
    if server_cfg is None:
        return
    ssh = ssh_connect(*server_cfg)
    multi_latest = {}
    for rule in rule_products:
        latest_version = get_latest(ssh, rule)
        useful = rule.diff_version(latest_version)
        multi_latest.setdefault(rule.product, [useful, rule.versions, latest_version])
    ssh.close()
    return multi_latest


def get_command(system: str, product: str):
    """获取不同系统的版本命令"""
    if system.startswith("redhat"):
        return COMMANDS[1] % product
    else:
        return COMMANDS[0] % product


def execute_command(ssh, command):
    """执行结果并返回标准输出"""
    stdin, stdout, stderr = ssh.exec_command(command)
    return stdout.read().decode("utf8")


def version_filter(info):
    """用于判断yum list命令返回结果中是否带有版本信息"""
    if isinstance(info, (bytearray, bytes)):
        info = info.decode("utf-8")
    msgs = info.split("\n")
    signal_1 = ["Available Packages", "可安装的软件包"]
    signal = ["Installed Packages", "已安装的软件包"]
    is_version = False
    for msg in msgs:
        if is_version:
            return msg
        if msg in signal:
            is_version = True
        else:
            if msg in signal_1:
                is_version = True


def fetch_rh(result):
    """获取redhat系统中的软件版本信息"""
    version = version_filter(result)
    if version:
        version = version.strip()
        matched = re.search("\s+(\S+)\s+", version)
        if matched:
            version = matched.group(1)
    return version


def fetch_ubuntu(result):
    """获取Ubuntu系统中的软件版本信息"""
    chunks = result.split("\n")
    v_tmp = None
    for chunk in chunks:
        if "|" not in chunk:
            continue
        _, v, *_ = re.split("\s+\|\s+", chunk)
        if v_tmp is None:
            v_tmp = v
            continue
        if RuleProduct.diff(v_tmp, v):
            v_tmp = v
    return v_tmp


def fetch_latest(system_name, result):
    """通过系统名获取对应的软件版本"""
    if system_name.startswith("redhat"):
        return fetch_rh(result)
    else:
        return fetch_ubuntu(result)


def check_rule_availability(multi_latest):
    if multi_latest:
        results = [latest[0] for latest in multi_latest.values()]
        if False not in results:
            available = any(results)
        else:
            available = all(results)
        if available:
            available = 1
        else:
            available = 0
    else:
        multi_latest = {None: [None, None, None]}
        available = 2
    return available, multi_latest


def update_product(all_rules):
    from run import app
    with app.app_context():
        action = "「oval rule 软件信息更新」"
        session = db.session
        try:
            for rule in all_rules:
                document = rule.rule_detail
                rule_name = rule.rule_name
                alias_name = rule.alias_name
                system_name = rule.system_name
                status = rule.status
                if document:
                    detail = parse(document)
                    queries = RuleProduct.query.filter_by(rule_name=rule_name).all()
                    if queries and detail:
                        for query in queries:
                            session.delete(query)
                    if not detail:
                        print(rule_name, detail)
                    for product, versions in detail.items():
                        obj = RuleProduct(
                            rule_name=rule_name, alias_name=alias_name,
                            product=product, versions=",".join(versions),
                            system_name=system_name, status=status
                        )
                        session.add(obj)
            session.commit()
            ding_reporter(action=action)
        except Exception as e:
            # response["code"] = 500
            # response["msg"] = str(e)
            ding_reporter(error_msg=str(e), action=action)
            print(e)
