# -*- coding: utf-8 -*-
import io

from xlwt import Workbook, Worksheet

from app.api.constants import title_list, CONVERT_INTO_CHINESE, CONVERT_INTO_FULL_VALUE


def write_title(sheet: Worksheet):
    """
    write the title into excel sheet
    :param sheet: the sheet to be written
    :return: the written sheet
    """
    for index, title in enumerate(title_list):
        sheet.write(0, index, title)
    return sheet


def write_data(sheet: Worksheet, data: list):
    print(len(data))
    for row, item in enumerate(data, 1):
        # print(item)
        for index, d in enumerate(item):
            sheet.write(row, index, d or "")
    return sheet


def convert_to_excel(data):
    file = io.BytesIO()
    book = Workbook(encoding="utf-8")
    sheet = book.add_sheet("sheet1", cell_overwrite_ok=True)
    write_title(sheet)
    write_data(sheet, data)
    book.save(file)
    file.seek(0)
    return file
    # book.save("aliyun.xls")


def convert_to_chinese(key, word):
    """
    convert values from mysql into the Chinese words
    :param key: field of the mysql table
    :param word: value of the field
    :return: the value in Chinese or default
    """
    fullname = convert_shortcut_to_fullname(key, word)
    chinese_dict = CONVERT_INTO_CHINESE[key]
    return chinese_dict.get(fullname) or chinese_dict.get("default")


def shortcut(word: str):
    return word.split(":")[-1]


def convert_shortcut_to_fullname(key, short):
    try:
        fullname_dict = CONVERT_INTO_FULL_VALUE[key]
        if short in fullname_dict.values():
            return short
        return fullname_dict[short]
    except KeyError:
        return "default"


def convert_cvss_to_values(cvss3_vector):
    if cvss3_vector:
        version, attack_vector, attack_complexity, \
        privileges_required, user_interaction, scope, \
        confidentiality_impact, integrity_impact, \
        availability_impact = cvss3_vector.split("/")
    else:
        attack_vector = attack_complexity = privileges_required = \
            user_interaction = scope = confidentiality_impact = \
            integrity_impact = availability_impact = "default"
    # return {
    #     "attack_vector": convert_to_chinese("attack_vector", shortcut(attack_vector)) ,
    #     "attack_complexity": convert_to_chinese("attack_complexity", shortcut(attack_complexity)),
    #     "privileges_required": convert_to_chinese("privileges_required", shortcut(privileges_required)),
    #     "confidentiality_impact": convert_to_chinese("confidentiality_impact", shortcut(confidentiality_impact)),
    #     "integrity_impact": convert_to_chinese("integrity_impact", shortcut(integrity_impact)),
    #     "availability_impact": convert_to_chinese("availability_impact", shortcut(availability_impact))
    # }
    return [
        convert_to_chinese("attack_vector", shortcut(attack_vector)),
        convert_to_chinese("attack_complexity", shortcut(attack_complexity)),
        convert_to_chinese("privileges_required", shortcut(privileges_required)),
        convert_to_chinese("confidentiality_impact", shortcut(confidentiality_impact)),
        convert_to_chinese("integrity_impact", shortcut(integrity_impact)),
        convert_to_chinese("availability_impact", shortcut(availability_impact))
    ]


if __name__ == '__main__':
    # filename = f"阿里云-{datetime.date.today().strftime('%Y%m%d')}"
    # convert_to_excel()
    cvss3 = "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:H"
    print(convert_cvss_to_values(cvss3))
