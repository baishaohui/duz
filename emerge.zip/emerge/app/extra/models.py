# -*- coding: utf-8 -*-
import datetime

from app import db


template = """
阿里云受{gdname}委托提醒您的资产：{url} 存在${vulname}漏洞，{proof}，根据《网络安全法》和《公共互联网网络安全威胁监测与处置办法》相关规定，请于{endtime}之前完成安全整改或关闭网站，届时不整改者将被关停服务器处置。参考：{reference}
"""


class PortFinger(db.Model):
    __tablename__ = "portfinger"
    __bind_key__ = "cva"
    id = db.Column(db.Integer, primary_key=True)
    ip = db.Column(db.String(20), nullable=False, comment="ip")
    port = db.Column(db.Integer, nullable=False)
    aliuid = db.Column(db.String(32), nullable=False, comment="aliuid")
    gc_level = db.Column(db.String(32), nullable=False)
    service = db.Column(db.String(32), nullable=False)
    product = db.Column(db.String(256), nullable=False)
    version = db.Column(db.String(256), nullable=False)
    protocol = db.Column(db.String(32), nullable=False)
    comment = "portfinger"

    def __repr__(self):
        return self.ip


class GDPushMsg(db.Model):
    __tablename__ = "gd_push_msg"
    __bind_key__ = "cva"
    id = db.Column(db.Integer, primary_key=True)
    userid = db.Column(db.String(512), comment="用户ID")
    proof = db.Column(db.Text, comment="proof")
    is_push = db.Column(db.Boolean(), default=False, comment="发送状态")
    gmt_time = db.Column(db.DateTime, default=datetime.datetime.now, comment="创建时间")
    comment = "通知记录"

    def __repr__(self):
        return self.userid

    def construct_msg(self):
        """用于构造信息"""
        pass


class GDMsgTemplate(db.Model):
    __tablename__ = "gd_msg_tmpl"
    id = db.Column(db.Integer, primary_key=True)
    ip = db.Column(db.String())
    message = db.Column(db.Text)
    comment = "通知消息"

    def __repr__(self):
        return self.userid