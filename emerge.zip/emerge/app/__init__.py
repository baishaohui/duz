# -*- coding: utf-8 -*-
import os
from flask import Flask, url_for
from flask_debugtoolbar import DebugToolbarExtension
from flask_login import LoginManager

from app.web.models import db
from app.web.views import admin_dict, app_dict, permission_app
from config import ProductConfig
from app.web.views import bp
from app.api.api import api
from app.web.auth import auth
from flask_bootstrap import Bootstrap
from flask_moment import Moment
from flask_uploads import UploadSet, IMAGES, configure_uploads, patch_request_class
from flask_migrate import Migrate
from utils.json_encoder import JSONEncoder
from app.web.template_filter import search_fields

login_manager = LoginManager()
toolbar = DebugToolbarExtension()
photos = UploadSet('photos', IMAGES)
BASE_DIR = os.path.dirname(os.path.dirname(__file__))


def create_app():
    static_dir = os.path.join(BASE_DIR, 'static')
    templates_dir = os.path.join(BASE_DIR, 'templates')
    app = Flask(
        __name__,
        instance_relative_config=True,
        static_folder=static_dir,
        template_folder=templates_dir
    )
    app.config.from_object(ProductConfig)
    moment = Moment()
    app = register_login(app)
    Bootstrap(app)
    db.init_app(app)
    app.register_blueprint(bp)
    app.register_blueprint(auth)
    app.register_blueprint(api)
    app.config['UPLOADED_PHOTOS_DEST'] = os.path.join(static_dir, "uploads")
    app.config['UPLOAD_FOLDER'] = os.path.join(static_dir, "uploads")
    app.config['UPLOADS_DEFAULT_URL'] = os.path.join(static_dir, "uploads")
    configure_uploads(app, photos)
    patch_request_class(app)
    Migrate(app, db)
    moment.init_app(app)
    app.json_encoder = JSONEncoder
    app.debug = True
    # toolbar.init_app(app)
    env = app.jinja_env
    env.filters["search_fields"] = search_fields
    return app


def register_login(app):
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"
    login_manager.session_protection = "strong"
    login_manager.login_message = "请先登录"
    login_manager.login_message_category = "info"
    return app


