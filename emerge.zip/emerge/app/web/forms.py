# -*- coding: utf-8 -*-
import datetime
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileRequired, FileAllowed
from wtforms import (StringField, SubmitField, TextAreaField, SelectField, PasswordField,
                     SelectMultipleField, DateField, BooleanField,
                     DateTimeField)
from wtforms.validators import DataRequired, Length, InputRequired, ValidationError, Optional

from config import CLASSIFY_MAP, ADVISORY_TAG_CHOICES

DATAREQUIRED_MESSAGE = "该字段为必填字段"
LENGTH_MESSAGE = "最大长度为%d字符"


class LoginForm(FlaskForm):
    username = StringField("用户名",
                           validators=[DataRequired("请输入用户名"), Length(6, 24, message="请输入6到24个字符")],
                           render_kw={"placeholder": "用户名"})
    password = PasswordField("密码",
                             validators=[DataRequired(), Length(8, 64, message="请输入8到64个字符")],
                             render_kw={"placeholder": "密码"}
                             )
    submit = SubmitField("登录")


class KeywordForm(FlaskForm):
    word = StringField("关键词", validators=[
        DataRequired("字段不能为空"),
        Length(min=1, max=256, message="字段长度不可超过256字符")], render_kw={"placeholder": "关键词"})
    submit = SubmitField("保存")


class AdvisoryForm(FlaskForm):
    translated_title = StringField(
        "标题", validators=[DataRequired("标题不能为空")], render_kw={"placeholder": "公告标题"})
    translation = TextAreaField("翻译", validators=[DataRequired("翻译不能为空")], render_kw={"placeholder": "翻译内容"})
    submit = SubmitField("保存")


class AdvisoryEditForm(FlaskForm):
    aid = StringField("公告编号", validators=[DataRequired("编号不为空")])
    title = StringField("公告标题", validators=[DataRequired("标题不为空")])
    translated_title = StringField("翻译标题", validators=[Optional()])
    link = StringField("公告链接", validators=[DataRequired("链接不为空")])
    pub_date = StringField("发布日期('年-月-日'格式)", validators=[DataRequired("发布日期不为空")])
    cves = StringField("相关CVE(','分隔，小写)", validators=[Optional()])
    advisory_type = SelectField(
        "公告类型", choices=(
            (1, "Ubuntu"), (2, "RedHat")), default=1, validators=[DataRequired("请选择公告类型")], coerce=int)
    affect_versions = TextAreaField("影响版本(Ubuntu，换行分隔)", validators=[Optional()])
    tags = SelectMultipleField("tags(中文，,分隔)", choices=[(a, a) for a in ADVISORY_TAG_CHOICES.keys()],
                               validators=[Optional()])
    advisory_body = TextAreaField("公告内容(HTML格式)", validators=[Optional()])
    description = TextAreaField("公告英文描述(HTML格式)", validators=[Optional()])
    translation = TextAreaField("公告中文描述(HTML格式)", validators=[Optional()])


class VulNewForm(FlaskForm):
    title_en = StringField("英文标题", validators=[DataRequired("字段不能为空")], render_kw={"placeholder": "英文标题"})
    title_cn = StringField("中文标题", validators=[DataRequired("字段不能为空")], render_kw={"placeholder": "中文标题"})


class VulNewEditForm(FlaskForm):
    avd_id = StringField(
        "avd-id", validators=[DataRequired("字段不能为空"), Length(max=128, message="最大长度128个字符")])
    cve_id = StringField("CVE ID", validators=[Length(max=50, message="最大长度50个字符")])
    title_cn = StringField("中文标题", validators=[Length(max=500, message="最大长度500个字符")])
    title_en = StringField("英文标题", validators=[Length(max=500, message="最大长度500个字符")])
    release_time = StringField("发现/披露时间", default=None, validators=(Optional(),))  # Datetime
    poc_disclosure_time = StringField("poc公开日期", default=None, validators=(Optional(),))  # Datetime
    cwe_id = StringField("CWE ID", validators=[Length(max=50, message="最大长度50个字符")])
    cpe = StringField("CPE", validators=[Length(max=500, message="最大长度500个字符")])
    cvss3_score = StringField("cvss3评分", validators=[Length(max=10, message="最大长度10个字符")])
    cvss3_vector = StringField("cvss3打分串", validators=[Length(max=255, message="最大长度255个字符")])
    vendor = StringField("漏洞厂商", validators=[Length(max=500, message="最大长度500个字符")])
    product = StringField("影响产品", validators=[Length(max=500, message="最大长度500个字符")])
    product_type = SelectField("产品类型\n（OS/Application/硬件）", choices=(
        ("OS", "OS"), ("Application", "Application"), ("硬件", "硬件")), validators=[
        DataRequired("请选择产品类型")], coerce=str)
    authentication = SelectField("是否需要身份认证,\n1需要,0不需要", choices=((0, "不需要"), (1, "需要"), ("", "未知")),
                                 coerce=str, default="")
    gained_privilege = SelectField(
        "是否能获取服务权限,\n1可以,0不可以", choices=((0, "不可以"), (1, "可以"), ("", "未知")), default="", coerce=str)
    vul_level = SelectField("漏洞等级严重、高危、中危、低危", choices=(
        ("low", "低危"), ("medium", "中危"), ("high", "高危"), ("serious", "严重"), ("", "未知")), default="", coerce=str)
    classify = SelectMultipleField("漏洞类型", choices=[
        (k, v.get("cn")) for k, v in CLASSIFY_MAP.items()],
                                   coerce=str, render_kw={"placeholder": "请选择漏洞类型"})
    reference = TextAreaField("参考链接", render_kw={"rows": 6})
    summary_en = TextAreaField("漏洞简介-en")
    summary_cn = TextAreaField("漏洞简介-cn")
    solution_en = TextAreaField("修复方案-en")
    solution_cn = TextAreaField("修复方案-cn")
    poc = TextAreaField("poc利用脚本")


class RuleSearchForm(FlaskForm):
    status = SelectField("状态", choices=[(0, "全部"), (1, "未上线"), (2, "灰度/已上线")], default=0, coerce=int,
                         render_kw={"class": "form-control"})
    has_adv = SelectField("公告", choices=[(0, "全部"), (1, "有公告"), (2, "无公告")], default=0, coerce=int,
                          render_kw={"class": "form-control"})
    available = SelectField("可用", choices=[(0, "全部"), (1, "可用"), (2, "不可用"), (3, "未知")], default=0, coerce=int,
                            render_kw={"class": "form-control"})


class AdvisorySearchForm(FlaskForm):
    has_translated = SelectField("状态", choices=[(0, "全部"), (1, "已审核"), (2, "未审核")], default=0, coerce=int,
                                 render_kw={"class": "form-control"})


class VulSearchForm(FlaskForm):
    status = SelectField("状态", choices=[(0, "全部"), (1, "未上线"), (2, "已上线或灰度中")], default=0, coerce=int,
                         render_kw={"class": "form-control"})
    checked = SelectField("审核", choices=[(0, "全部"), (1, "已审核"), (2, "未审核")], default=0, coerce=int,
                          render_kw={"class": "form-control"})


class VulKBSearchForm(FlaskForm):
    product_choices = [(0, "全部"), (1, "2003"), (2, "2003 SP2"),
                       (3, "2008"), (4, "2008 R2"),
                       (5, "2008 R2 SP1"), (6, "2008 SP2"),
                       (7, "2012"), (8, "2012 R2"),
                       (9, "2016"), (10, "2019")]
    product = SelectField("产品", choices=product_choices, default=0, coerce=int, render_kw={"class": "form-control"})
    is_top = SelectField("顶级", choices=[(0, "全部"), (1, "顶级"), (2, "非顶级")], default=0, coerce=int,
                         render_kw={"class": "form-control"})
    architecture = SelectField("架构", choices=[(0, "全部"), (1, "x86"), (2, "x64")], default=0, coerce=int,
                               render_kw={"class": "form-control"})
    monthly_rollup = SelectField("分类", choices=[(0, "全部"), (1, "安全"), (2, "月度")], default=0, coerce=int,
                                 render_kw={"class": "form-control"})


class VulForPrForm(FlaskForm):
    title = StringField(
        "标题", validators=[DataRequired(DATAREQUIRED_MESSAGE), Length(max=50, message=LENGTH_MESSAGE % 50)])
    release_time = DateTimeField("披露日期", default=datetime.datetime.now)
    # QR_code = TextAreaField("二维码链接", validators=[DataRequired(message="二维码地址不能为空")], render_kw={"rows": 4})
    allowed_photos = ["jpg", "png"]
    QR_code = FileField("二维码图片", validators=[
        FileRequired(message="二维码地址不能为空"),
        FileAllowed(allowed_photos, "只能上传格式为%s的图片" % "、".join(allowed_photos))])
    introduction = TextAreaField("简介", default="", render_kw={"rows": 4})
    summary_help = """
        说明：只可以使用固定格式渲染，每一小段内容的格式为：
        ### 漏洞描述
        balabalabala
        
        多个段落示例：
        
        ### 漏洞描述
        balabalabala
        
        ### 相关链接
        - 链接1
        - 链接2
        ...
    """
    summary = TextAreaField("漏洞描述", default="", render_kw={"placeholder": summary_help})


class VulKBForm(FlaskForm):
    kb = StringField("kb", validators=[DataRequired(message="KB 不能为空")], render_kw={"placeholder": "请输入KB"})
    title = StringField("标题", render_kw={"placeholder": "请输入标题"})
    product = StringField("产品", render_kw={"placeholder": "请输入产品名"})
    severity_choices = (
        ("", "请选择漏洞等级"),
        ("Low", "低危"),
        ("Moderate", "中危"),
        ("Important", "高危"),
        ("Critical", "严重"),
        ("Unspecified", "未知")
    )
    architecture_choices = (
        ("", "请选择架构类型"),
        ("x86", "x86"),
        ("x64", "x64")
    )
    severity = SelectField("等级", choices=severity_choices, coerce=str, default=None,
                           render_kw={"placeholder": "请选择漏洞等级"})
    architecture = SelectField("架构", choices=architecture_choices, coerce=str, default=None,
                               render_kw={"placeholder": "请选择架构类型"})
    size = StringField("补丁大小", render_kw={"placeholder": "请输入补丁文件大小"})
    security_kb = StringField("安全KB", render_kw={"placeholder": "请输入安全KB"})
    release_time = DateField("发布时间", validators=[Optional()], render_kw={"placeholder": "请输入发布日期"})
    replace = TextAreaField("replace", render_kw={"placeholder": "请输入replace kb，多个kb以英文逗号分隔", "rows": 6})
    all_security_kb = TextAreaField("子安全KB", render_kw={"placeholder": "请输入子安全KB，以'|'分隔", "rows": 6})
    reference = TextAreaField("参考链接", render_kw={"placeholder": "请输入参考链接，多个链接以英文逗号分隔", "rows": 6})
    files = TextAreaField("文件名", render_kw={"placeholder": "请输入补丁文件名，多个文件以英文逗号分隔", "rows": 6})
    description = TextAreaField("描述", render_kw={"placeholder": "请输入KB描述", "rows": 6})
    download_from = TextAreaField("下载链接",
                                  render_kw={"placeholder": "请输入补丁下载链接，多个链接以英文逗号分隔", "rows": 6})
    update_id = TextAreaField("update id", render_kw={"placeholder": "请输入update id", "rows": 6})
    # monthly_rollup = BooleanField("月度", default=False)


form_dict = {
    "vul_rule_usn_aid_search": RuleSearchForm,
    "vul_advisory_search": AdvisorySearchForm,
    "vul_new_search": VulSearchForm,
    "vul_new_pre_search": VulSearchForm,
    "vul_new_running_search": VulSearchForm,
    "vul_kb_search": VulKBSearchForm,
    "vul_new_test": VulNewEditForm,
    "vul_new_pre": VulNewEditForm,
    "vul_new_running": VulNewEditForm,
    "vul_advisory": AdvisoryEditForm,
    "vul_for_pr": VulForPrForm,
    "vul_kb": VulKBForm
}
