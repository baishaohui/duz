# -*- coding: utf-8 -*-
import re
import xlrd
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()
metadata = Base.metadata

db = create_engine('mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/vul_db')
sql_existed = "select * from :table WHERE cve_id=:cve_id"
update_sql = "update {table} set title_en=:title,summary_en=:summary where cve_id=:cve_id"
# insert_sql = "insert into %s ()"
tables = ["select * from vul_new WHERE cve_id=:cve_id",
          "select * from vul_new_pre WHERE cve_id=:cve_id",
          "select * from vul_new_running WHERE cve_id=:cve_id"]


def read():
    ex = xlrd.open_workbook("title.xlsx")
    sheet = ex.sheet_by_index(0)
    for i in range(sheet.nrows):
        if i <= 87:
            continue
        _, cve, title, summary = sheet.row_values(i)
        if cve.strip():
            cve = cve.strip()
            title = title.strip()
            summary = summary.strip() or str()
            if summary == "√":
                summary = None
            if title == "RED HAT 和CVE数据库中未查询到相关数据":
                title = None
            set_title(cve, title, summary)
            # print(cve, title, summary)


def set_title(cve, title, summary):
    DBSession = sessionmaker(bind=db)
    session = DBSession()
    print(cve, title, summary)
    for table in tables:
        result = session.execute(table, {"cve_id": cve}).fetchall()
        if result:
            result = result[0]
            title = title or result["title_en"]
            summary = summary or result["summary_en"]
            table_name = re.search("vul_new_?\w*", table)
            table_name = table_name.group()
            session.execute(
                update_sql.format(table=table_name),
                {"title": title, "summary": summary, "cve_id": cve})
            session.commit()
            print("updated", cve)


# √
if __name__ == '__main__':
    read()