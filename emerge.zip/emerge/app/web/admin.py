# -*- coding: utf-8 -*-
from sqlalchemy.sql import or_
from .models import (Advisory, OvalRule, RuleUsnAid, VulNew,
                     VulNewPre, VulNewRun, VulNewTest, VulForPr, KBModel)
from app.extra.models import GDPushMsg, PortFinger


class BaseAdmin:
    display_fields = []
    search_fields = []
    search_sections = {"": "全部"}
    form_fields = []
    order_by_fields = []
    filter_fields = {}
    page_items = 30
    form_exclude_fields = []
    allow_edit = False
    allow_add = False
    allow_del = False
    model = None
    pk = None


class Site:

    def __init__(self, name="admin"):
        self.name = name
        self.admin_dict = {}

    def register(self, model_cls, admin_cls=None):
        if not admin_cls:
            admin_cls = BaseAdmin()
        admin_cls.model = model_cls
        if model_cls.__tablename__ not in self.admin_dict:
            self.admin_dict[model_cls.__tablename__] = admin_cls


class AdvisoryAdmin(BaseAdmin):
    display_fields = ["title", "translated_title", "link", "tags", "tags_en", "pub_date", "is_translated"]
    search_fields = ["aid", "title", "link"]
    search_sections = {"": "全部", "has_translated": "已翻译", "not_translated": "未翻译"}
    condition_map = {
        "not_translated": Advisory.is_translated == False,
        "has_translated": Advisory.is_translated == True,
    }
    form_fields = ["aid", "title", "translated_title", "link", "advisory_body", "description", "translation", "cves",
                   "affect_versions", "pub_date", "advisory_type"]
    order_by_fields = ["pub_date"]
    page_items = 50
    allow_add = True
    allow_edit = True
    # allow_del = True


class OvalRuleAdmin(BaseAdmin):
    display_fields = ["rule_name", "alias_name", "status", "aid", "cve_id", "type", "is_translated"]
    search_fields = ["rule_name", "alias_name"]
    search_sections = {
        "": "全部", "has_adv": "有公告", "no_adv": "无公告", "running": "上线", "stop": "未上线", "gray": "灰度"}
    # form_fields = ["title", "link", "is_translated"]
    # order_by_fields = ["pub_date"]
    allow_edit = False
    allow_add = False
    allow_del = False


class RuleUsnAidAdmin(BaseAdmin):
    display_fields = ["rule_name", "alias_name", "available", "title", "translated_title", "aid", "cve_id", "type",
                      "status"]
    search_fields = ["rule_name", "alias_name", "aid", "title", "translated_title"]
    search_sections = {
        "": "全部", "has_adv": "有公告", "no_adv": "无公告",
        "running": "上线/灰度", "stop": "未上线",
        "available": "可用", "not_available": "不可用",
    }
    filter_fields = {
        "has_adv": {"1": Advisory.title != None, "2": Advisory.title == None},
        "status": {"1": OvalRule.status == 1, "2": or_(OvalRule.status == 2, OvalRule.status == 3)},
        "available": {"1": RuleUsnAid.available == 1, "2": RuleUsnAid.available == 0, "3": RuleUsnAid.available == 2}
    }


class VulNewAdmin(BaseAdmin):
    display_fields = ["cve_id", "title_cn", "title_en", "cvss3_score", "rule_status", "is_translated"]
    search_fields = ["title_en", "title_cn", "cve_id"]
    form_fields = ["avd_id", "cve_id", "title_cn", "title_en", "release_time", "poc_disclosure_time", "cwe_id",
                   "cpe", "cvss3_score", "cvss3_vector", "vendor", "product", "product_type", "authentication",
                   "gained_privilege", "vul_level", "classify", "poc", "summary_en", "summary_cn", "solution_en",
                   "solution_cn", "reference"]
    search_sections = {
        "": "全部",
        "online": "已上线",
        "offline": "未上线"
    }
    filter_fields = {
        "status": {"1": VulNew.rule_status == 1,
                   "2": or_(VulNew.rule_status == 2, VulNew.rule_status == 3)},
        "checked": {"1": VulNew.is_translated == 1, "2": VulNew.is_translated == 0}
    }
    page_items = 50
    pk = "cve_id"


class VulNewPreAdmin(VulNewAdmin):
    filter_fields = {
        "status": {"1": VulNewPre.rule_status == 1,
                   "2": or_(VulNewPre.rule_status == 2, VulNewPre.rule_status == 3)},
        "checked": {"1": VulNewPre.is_translated == 1, "2": VulNewPre.is_translated == 0}
    }
    allow_add = True


class VulNewRunAdmin(VulNewPreAdmin):
    display_fields = ["cve_id", "title_cn", "title_en", "cvss3_score", "is_translated"]
    order_by_fields = ["cve_id"]
    filter_fields = {
        "status": {"1": VulNewRun.rule_status == 1,
                   "2": or_(VulNewRun.rule_status == 2, VulNewRun.rule_status == 3)},
        "checked": {"1": VulNewRun.is_translated == 1, "2": VulNewRun.is_translated == 0}
    }


class VulNewTestAdmin(VulNewPreAdmin):
    pass


class VulForPrAdmin(BaseAdmin):
    display_fields = ["id", "cve_id", "title", "release_time"]
    search_fields = ["title", "release_time"]
    form_fields = ["title", "release_time", "introduction", "QR_code", "summary"]
    allow_edit = True
    allow_add = True
    allow_del = True


class GDPushMsgAdmin(BaseAdmin):
    display_fields = ["userid", "proof", "is_push"]
    search_fields = ["userid"]
    allow_add = True
    allow_del = True
    allow_edit = True


class PortFingerAdmin(BaseAdmin):
    display_fields = ["ip", "aliuid"]
    search_fields = ["aliuid", "ip"]


class VulKBAdmin(BaseAdmin):
    display_fields = ["kb", "title", "product", "reference", "architecture", "is_top"]
    form_fields = ["kb", "title", "product", "architecture", "severity",
                   "size", "replace", "release_time", "reference", "is_top"
                   "files", "description", "download_from", "update_id"]
    search_fields = ["kb", "title", "product"]
    product_list = ["Windows Server 2003",
                    "Windows Server 2003 SP2",
                    "Windows Server 2008",
                    "Windows Server 2008 R2",
                    "Windows Server 2008 R2 SP1",
                    "Windows Server 2008 SP2",
                    "Windows Server 2012",
                    "Windows Server 2012 R2",
                    "Windows Server 2016",
                    "Windows Server 2019"]
    order_by_fields = ["kb"]
    filter_fields = {
        "product": {str(i): KBModel.product == p for i, p in enumerate(product_list, 1)},
        "is_top": {"1": KBModel.is_top == True, "2": KBModel.is_top == False},
        "architecture": {"1": KBModel.architecture == "x86", "2": KBModel.architecture == "x64"},
        "monthly_rollup": {"1": KBModel.monthly_rollup == False, "2": KBModel.monthly_rollup == True}
    }
    allow_add = True
    allow_edit = True
    allow_del = True


site = Site()
site.register(Advisory, AdvisoryAdmin)
# site.register(OvalRule, OvalRuleAdmin)
site.register(RuleUsnAid, RuleUsnAidAdmin)
site.register(VulNew, VulNewAdmin)
site.register(VulNewTest, VulNewTestAdmin)
site.register(VulNewPre, VulNewPreAdmin)
site.register(VulNewRun, VulNewRunAdmin)
site.register(VulForPr, VulForPrAdmin)
site.register(KBModel, VulKBAdmin)
site.register(GDPushMsg, GDPushMsgAdmin)
site.register(PortFinger, PortFingerAdmin)
