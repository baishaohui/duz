# -*- coding: utf-8 -*-
from flask import Blueprint

bp = Blueprint("list", __name__)
