# -*- coding: utf-8 -*-
import re
from urllib.parse import urlencode, parse_qs, parse_qsl
from bleach.sanitizer import Cleaner
from flask import url_for

from .views import bp



TAGS = ['a', 'abbr', 'acronym', 'b', 'blockquote', 'code', 'em', 'i', 'li', 'ol', 'strong', 'ul']
TAGS.extend(
    ["div", "p", "hr", "br", "pre", "code", "span", "h1", "h2", "h3", "h4", "h5", "h6", "del", "dl", "table", "thead",
     "tr", "td", "tbody", "dd", "blockquote", "section"])
STYLES = ["color", "font", "font-size", "font-weight"]
ATTRIBUTES = {"*": ["class", "id", "style"], "a": ["href", "title", "target"],
              "img": ["src", "style", "width", "height"]}
cleaner = Cleaner(tags=TAGS, attributes=ATTRIBUTES, styles=STYLES)


@bp.app_template_filter()
def bool_to_icon(value, field, pr=False):
    if pr:
        if isinstance(value, int):
            value = "<a href='{prefix}'>{0}</a>".format(
                value, prefix=url_for("list.pr", pk=value))
    if isinstance(value, bool):
        if value is True:
            return '<i class="fa fa-check text-success"></i>'
        else:
            return '<i class="fa fa-remove text-red"></i>'
    elif isinstance(value, str):
        value = value.strip()
        if value.startswith("http://") or value.startswith("https://"):
            value = "<a href='{0}' target='_blank'>{0}</a>".format(value)
        elif re.search("^CVE-\d+-\d+$", value) or re.search("^cve-\d+-\d+$", value):
            if not pr:
                value = "<a href='https://avd.aliyun.com/detail/{0}' target='_blank'>{0}</a>".format(value)
        elif re.search("^USN-\d+-\d+$", value):
            value = "<a href='/advisory/ubuntu?q=%s'>%s</a>" % (value, value)
        elif re.search("^RHSA-\d+:\d+$", value):
            value = "<a href='/advisory/redhat?q=%s'>%s</a>" % (value, value)
    else:
        if value is None:
            value = ""
        if isinstance(value, int) and field == "available":
            if value == 0:
                value = "<i class='fa fa-remove text-red'></i>"
            elif value == 1:
                value = "<i class='fa fa-check text-success'></i>"
            elif value == 2:
                value = "<i class='fa fa-question text-danger'></i>"
    return value


@bp.app_template_filter(name="search_fields")
def search_fields(admin):
    fields = []
    for field in admin.model._sa_class_manager.attributes:
        if field.key in admin.search_fields:
            fields.append(field.comment)
    return "，".join(fields)


@bp.app_template_filter()
def xss(html):
    if html:
        return cleaner.clean(html)
    return html


@bp.app_template_filter()
def render_field(query, key):
    if hasattr(query, "__dict__"):
        return query.__dict__.get(key)
    else:
        if getattr(query, key, None) is None:
            return ""
        return getattr(query, key)


@bp.app_template_filter()
def render_field_header(model, field):
    if hasattr(model, field):
        return getattr(model, field).comment
    else:
        return field


@bp.app_template_filter()
def render_query(query_string, page_num):
    url_dict = dict(parse_qsl(query_string))
    url_dict["page"] = page_num
    return urlencode(url_dict)


@bp.app_template_filter()
def none_to_str(string_or_none, cn=True):
    if string_or_none:
        return string_or_none
    elif not string_or_none and cn:
        return "暂无"
    return str()
