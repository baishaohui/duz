# -*- coding: utf-8 -*-
from functools import wraps
import re
from flask import request
from flask_login import current_user
from flask import abort

PERMISSION_DICT = {
    "translator": {
        "allowed_app": ["advisory", "vulnerability", "windows"],
        "allowed_endpoint": [
            "list.index", "list.item_list", "list.advisory", "list.item_update",
            "list.translate", "list.vul_translate", "list.vul_edit", "list.add"
        ],
        "allowed_tables": ["vul_advisory", "vul_new_pre",
                           "vul_new", "vul_new_running", "vul_kb"]
    },
    "pr_editor": {
        "allowed_app": ["vulnerability"],
        "allowed_endpoint": [
            "list.index", "list.item_list", "list.item_add", "list.item_update"
        ],
        "allowed_tables": ["vul_for_pr"]
    }
}


def permission_required(f):
    def decorated_function(*args, **kwargs):
        role_perm = PERMISSION_DICT.get(current_user.role, {})
        # if current_user.is_admin or (request.endpoint in role_perm.get("allowed_endpoint", []) or (
        #         kwargs.get("table_name") in role_perm.get("allowed_tables")) if kwargs.get("table_name") else
        #         request.endpoint == "list.index"
        # ):
        if current_user.is_admin or (
                request.endpoint in role_perm.get("allowed_endpoint", []) or request.endpoint == "list.index"
        ):
            return f(*args, **kwargs)
        abort(404)

    return decorated_function
