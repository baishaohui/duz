# -*- coding: utf-8 -*-
from flask import render_template

from . import bp


@bp.app_errorhandler(404)
def page_not_found(e):
    status = 404
    error_title = "您要找的页面不存在！"
    return render_template("error_pages/40x.html", status=status, error_title=error_title), status