# -*- coding: utf-8 -*-
import base64
import re
import time
import datetime
import subprocess
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlencode, urlsplit

import os
import pymysql
import requests
from flask import abort
from flask import request
from flask import redirect
from flask import url_for
from flask import jsonify
from flask import session
from flask_login import login_required
from flask_login import current_user
from sqlalchemy import or_, not_, desc, create_engine
from py_translator import Translator as T
from flask.templating import render_template
from sqlalchemy.orm import sessionmaker
from werkzeug.utils import secure_filename

from app.web import bp
from utils.error_hunter import ding_reporter
from utils.extra_handler import fetch_tags, future_pre_to_new
from .models import db, VulForPr, KBModel
from .admin import site
from utils.db import db_con
from .permission import permission_required, PERMISSION_DICT
from .models import (
    Advisory, OvalRule, RuleUsnAid, DataBase, VulNew, VulNewRun, VulNewPre)
from .forms import form_dict, AdvisoryForm, AdvisorySearchForm
from config import OL_DB_CONFIG, DB_CONFIG, ADVISORY_TAG_CHOICES, CLASSIFY_MAP
from utils.translator import Translator, google_translate
from utils.vul_rule_aid_update import rule_aid_related, match_ubuntu, match_redhat

ADVISORY_DICT = {
    "redhat": 2,
    "ubuntu": 1,
    "emerge": 3
}
img_src_pattern = re.compile("src=\"(http.*)\"|!\[.*\]\((http\S+)\w?\"?.*\)")

translation_src = ["google", "ali-standard", "ali-general"]
MULTISELECTFIELDS = ["tags", "classify"]
task_worker = ThreadPoolExecutor(1)
cve_db = create_engine(
            (f'mysql+pymysql://{DB_CONFIG.get("user")}:'
             f'{DB_CONFIG.get("password")}@{DB_CONFIG.get("host")}:{DB_CONFIG.get("port")}/cva_db'))


@bp.app_context_processor
@bp.app_template_global()
def admin_dict():
    return site.admin_dict


@bp.app_context_processor
@bp.app_template_global()
def permission_app():
    if current_user.is_authenticated:
        return PERMISSION_DICT.get(current_user.role) or {}
    else:
        return {}


@bp.app_context_processor
@bp.app_template_global()
def app_dict():
    return {
        # "TI": {"ch_name": "漏洞情报", "tables": ["keyword", "client", "info_source", "record"]},
        # "MMS": {"ch_name": "数据监控", "tables": ["config", "tactics"]},
        "advisory": {"ch_name": "Linux公告", "tables": ["vul_advisory", ]},
        "oval_rule": {"ch_name": "oval规则", "tables": ["vul_rule_usn_aid", ]},
        "vulnerability": {"ch_name": "漏洞库", "tables": ["vul_new", "vul_new_pre", "vul_new_running", "vul_for_pr"]},
        "windows": {"ch_name": "Windows补丁", "tables": ["vul_kb"]}
    }


@bp.route("/", endpoint="index")
@login_required
@permission_required
def index():
    if current_user.role == "admin":
        # return redirect(url_for("list.advisory", a_type="redhat"))
        model = None
        return render_template("dashboard.html", model=model)
    di = PERMISSION_DICT.get(current_user.role)
    first_endpoint = ""
    for ep in di.get("allowed_endpoint", {}):
        if ep != "list.index":
            first_endpoint = ep
            break
    table_name = di.get("allowed_tables", [])[0]
    return redirect(url_for(first_endpoint, table_name=table_name))


@bp.route("/<string:table_name>", endpoint="item_list", methods=["GET", "POST"])
@login_required
@permission_required
def item_list(table_name):
    if request.method == "POST":
        page = request.form.get("page", 1)
        args = request.args.to_dict()
        args["page"] = page
        return redirect(url_for("list.item_list", table_name=table_name) + "?" + urlencode(args))
    admin_cls = site.admin_dict.get(table_name)
    is_top = request.args.get("top")
    if admin_cls is None and table_name != "vul_new_online":
        abort(404)
    model = admin_cls.model
    if table_name == "vul_rule_usn_aid":
        query_sql = db.session.query(
            RuleUsnAid.rule_name, RuleUsnAid.alias_name, OvalRule.status, RuleUsnAid.type, RuleUsnAid.aid,
            RuleUsnAid.cve_id, RuleUsnAid.available, Advisory.title, Advisory.translated_title
        ).outerjoin(OvalRule, RuleUsnAid.rule_name == OvalRule.rule_name).outerjoin(
            Advisory, Advisory.aid == RuleUsnAid.aid)
    # elif table_name == "vul_kb" and is_top and is_top == "true":
    #     top_kb_id_list = [kb.id for kb in model.query.all() if kb.is_top]
    #     print(len(top_kb_id_list))
    #     query_sql = model.query.filter(model.id.in_(top_kb_id_list))
    else:
        query_sql = model.query
        attr_list = [getattr(model, i) for i in admin_cls.display_fields if hasattr(model, i)]
        if table_name == "vul_kb":
            attr_list.append("id")
        query_sql = query_sql.with_entities(
            *attr_list
        )
    title = model.comment + " - 列表"
    keyword = request.args.get("q")
    search_form = form_dict.get(table_name + "_search", {})
    filter_form = search_form(request.args, meta={'csrf': False}) if search_form else None
    for key, value in admin_cls.filter_fields.items():
        param = request.args.get(key)
        if param in value:
            query_sql = query_sql.filter(value.get(param))
    try:
        page = int(request.args.get("page", 1))
    except ValueError:
        page = 1
    if keyword:
        condition = [
            getattr(model, field).ilike("%" + keyword.strip() + "%") if hasattr(
                model, field) else getattr(Advisory, field).ilike(
                "%" + keyword.strip() + "%") for field in admin_cls.search_fields
        ]
        condition_obj = or_(*condition)
        query_sql = query_sql.filter(condition_obj)
    if admin_cls.order_by_fields:
        query_sql = query_sql.order_by(*[desc(getattr(model, field)) for field in admin_cls.order_by_fields])
    query = query_sql.paginate(page, per_page=admin_cls.page_items, error_out=False)
    total = query.total
    return render_template(
        "list.html",
        query_list=query.items,
        model=model,
        admin=admin_cls,
        pagination=query,
        q=keyword,
        title=title,
        total=total,
        filter_form=filter_form
    )


@bp.route("/<string:table_name>/add", endpoint="item_add", methods=["GET", "POST"])
@login_required
@permission_required
def item_add(table_name):
    form_cls = form_dict.get(table_name)
    if not form_cls:
        abort(404)
    admin = site.admin_dict.get(table_name)
    model = admin.model
    title = model.comment + " - 添加"
    form = form_cls()
    if request.method == "GET":

        return render_template("form.html", form=form, model=model, title=title)
    elif request.method == "POST":
        if form.validate_on_submit():
            obj_dict = {}
            for field in form:
                if field.name in admin.form_fields:
                    if field.type == "BooleanField":
                        if request.form.get(field.name):
                            obj_dict[field.name] = True
                        else:
                            obj_dict[field.name] = False
                    elif field.type == "SubmitField":
                        continue
                    elif field.type == "FileField":
                        from app import photos
                        files = request.files["QR_code"]
                        filename = photos.save(files)
                        file_url = photos.url(secure_filename(filename))
                        obj_dict[field.name] = file_url
                    else:
                        obj_dict[field.name] = request.form.get(field.name)
                    if "last_update_time" in admin.form_fields:
                        obj_dict["last_update_time"] = datetime.datetime.now()
            new_obj = model(**obj_dict)
            if hasattr(new_obj, "gmt_modified"):
                setattr(new_obj, "gmt_modified", datetime.datetime.now())
            if hasattr(new_obj, "classify"):
                classify_list = request.form.getlist("classify")
                # setattr(new_obj, "classify", ",".join(
                #     getattr(new_obj, "classify", [])) if getattr(new_obj, "classify", []) else "")
                setattr(new_obj, "classify", " ".join(classify_list) if classify_list else "")
            if hasattr(new_obj, "tags"):
                tag_list = request.form.getlist("tags")
                setattr(new_obj, "tags_en",
                        ",".join([ADVISORY_TAG_CHOICES.get(tag, "") for tag in tag_list if tag] if tag_list else []))
                setattr(new_obj, "tags", ",".join(tag_list) if tag_list else "")
            if table_name.startswith("vul_new_") and request.form.get("flag") == "1":
                new_online_obj = VulNew(
                    avd_id=form.avd_id.data, gmt_create=datetime.datetime.now(), cwe_id=form.cwe_id.data,
                    release_time=form.release_time.data, cvss3_vector=form.cvss3_vector.data,
                    cvss3_score=form.cvss3_score.data,
                    product_type=form.product_type.data, vendor=form.vendor.data, product=form.product.data,
                    cpe=form.cpe.data,
                    authentication=form.authentication.data, gained_privilege=form.gained_privilege.data,
                    vul_level=form.vul_level.data,
                    summary_cn=form.summary_cn.data, summary_en=form.summary_en.data, poc=form.poc.data,
                    poc_disclosure_time=form.poc_disclosure_time.data,
                    solution_cn=form.solution_cn.data, solution_en=form.solution_en.data,
                    reference=form.reference.data,
                    classify=form.classify.data,
                    cve_id=form.cve_id.data, title_en=form.title_en.data, title_cn=form.title_cn.data,
                    gmt_modified=datetime.datetime.now()
                )
                new_online_obj.classify = " ".join(request.form.getlist("classify"))
                db.session.add(new_online_obj)
            db.session.add(new_obj)
            db.session.commit()
            if table_name.startswith("vul_new_"):
                return redirect(url_for("list.vul_detail", table_name=table_name, cve_id=form.cve_id.data))
            return redirect(url_for("list.item_list", table_name=table_name))
        else:
            return render_template("form.html", form=form, model=model, title=title)


@bp.route("/<string:table_name>/<pk>", endpoint="item_update", methods=["GET", "POST"])
@login_required
@permission_required
def item_update(table_name, pk):
    admin = site.admin_dict.get(table_name)
    if not admin:
        abort(404)
    model = admin.model
    title = model.comment + " - 修改"
    form_cls = form_dict.get(table_name)
    if not form_cls:
        abort(404)
    if not admin.pk:
        query_obj = model.query.filter_by(id=pk).first_or_404()
    else:
        query_obj = model.query.filter_by(**{admin.pk: pk}).first_or_404()

    if request.method == "GET":
        for field in MULTISELECTFIELDS:
            if hasattr(query_obj, field) and getattr(query_obj, field):
                t_list = getattr(query_obj, field).split(",")
                setattr(query_obj, field, t_list)
    form = form_cls(obj=query_obj)
    if request.method == "POST":
        if form.validate_on_submit():
            form.populate_obj(query_obj)
            if hasattr(query_obj, "gmt_modified"):
                setattr(query_obj, "gmt_modified", datetime.datetime.now())
            if hasattr(query_obj, "tags"):
                setattr(query_obj, "tags_en", ",".join(
                    [ADVISORY_TAG_CHOICES.get(tag, "") for tag in query_obj.tags] if query_obj.tags else []))
                setattr(query_obj, "tags", ",".join(query_obj.tags if query_obj.tags else []))
            if hasattr(query_obj, "classify"):
                setattr(query_obj, "classify", ",".join(query_obj.classify) if query_obj.classify else "")
            if hasattr(query_obj, "QR_code"):
                from app import photos
                files = request.files["QR_code"]
                filename = photos.save(files)
                file_url = photos.url(secure_filename(filename))
                setattr(query_obj, "QR_code", file_url)
            db.session.commit()
            return redirect(url_for("list.item_list", table_name=table_name))
    return render_template("form.html", form=form, model=model, title=title)


@bp.route("/<string:table_name>/del", endpoint="item_del", methods=["GET", "POST"])
@login_required
@permission_required
def item_del(table_name):
    admin = site.admin_dict.get(table_name)
    if not admin:
        abort(404)
    pk = request.form.get("pk") if request.method == "POST" else request.args.get("pk")
    model = admin.model
    query_obj = model.query.filter_by(id=pk).first_or_404()
    result = {"success": True}
    if request.method == "GET":
        result["data"] = query_obj.__repr__()
        return jsonify(result)
    try:
        db.session.delete(query_obj)
        db.session.commit()
        redirect_url = url_for("list.item_list", table_name=table_name)
        result["redirect"] = redirect_url
    except Exception as e:
        result["success"] = 0
        result["errorMsg"] = "删除失败"
    return jsonify(result)


# @bp.route("/send/ding", endpoint="ding", methods=["POST"])
# @login_required
# @permission_required
# def send_ding():
#     pk = request.form.get("pk")
#     obj = Record.query.filter_by(id=pk).first_or_404()
#     clients = Client.query.filter_by(active=True).all()
#     if not obj.short_url:
#         url = shorten_url(obj.link)
#         if url:
#             shorts, *_ = url
#             if shorts:
#                 Record.query.filter_by(id=pk).update({"short_url": shorts.get("url_short")})
#                 db.session.commit()
#     msg = "#### %s \n\n \1 \n\n[%s](%s)\n" % (
#         obj.title.strip(),
#         obj.short_url if obj.short_url else obj.link,
#         obj.short_url if obj.short_url else obj.link
#     )
#     template = DING_TEMPLATE.copy()
#     template["markdown"]["text"] = msg
#     result = {"success": 1, }
#     try:
#         for client in clients:
#             current_link = client.ding_url
#             error_dict = send_msg(template, current_link)
#             error_code = error_dict.get("errcode")
#             if error_code != 0:
#                 raise ValueError(error_dict.get("errmsg"))
#         Record.query.filter_by(id=pk).update(
#             {"analyzed": True, "has_sent": True, "is_intelligence": True, "analyze_time": datetime.datetime.now()})
#         db.session.commit()
#         result["msg"] = "发送成功"
#     except Exception as e:
#         result["success"] = 0
#         result["errorMsg"] = "钉钉消息发送失败，错误信息：%s" % e
#     return jsonify(result)


# @bp.route("/test/tactics", endpoint="test_tactics", methods=["POST"])
# @login_required
# @permission_required
# def test_tactics():
#     pk = request.form.get("pk")
#     result = {"success": 1, }
#     try:
#         obj = Tactics.query.filter_by(id=pk).first_or_404()
#         from schedule import task
#         task(obj, obj.config)
#         result["msg"] = "发送成功，让消息飞一会..."
#     except Exception as e:
#         result["success"] = 0
#         result["errorMsg"] = "测试出错，错误信息：%s" % e
#     return jsonify(result)


# @bp.route("/test/config", endpoint="test_config", methods=["POST"])
# @login_required
# @permission_required
# def test_config():
#     result = {"success": 1}
#     try:
#         obj = Config.query.filter_by(id=request.form.get("pk")).first_or_404()
#         con = pymysql.connect(
#             host=obj.host,
#             port=obj.port,
#             user=obj.user,
#             password=obj.pwd,
#             db=obj.db_name,
#             charset="utf8",
#             cursorclass=pymysql.cursors.SSDictCursor
#         )
#         with con.cursor(pymysql.cursors.DictCursor) as cur:
#             cur.execute("SELECT sysdate() AS cur_time FROM dual")
#             data = cur.fetchone()
#             cur_time = data.get("cur_time")
#             result["msg"] = "连接成功！服务器返回时间：%s" % cur_time.strftime("%Y-%m-%d %H:%M:%S")
#     except Exception as e:
#         result["success"] = 0
#         result["errorMsg"] = "连接出错，错误信息：%s" % e
#     return jsonify(result)


@bp.route("/vul_advisory/<string:aid>/translate/<string:a_type>", endpoint="translate", methods=["GET", "POST"])
@login_required
@permission_required
def advisory_translate(aid, a_type):
    obj = Advisory.query.filter_by(aid=aid).first_or_404()

    if request.method == "POST":
        form = AdvisoryForm(request.form)
        if form.validate_on_submit():
            translation = request.form.get("translation")
            translated_title = request.form.get("translated_title")
            obj.translation = translation
            obj.translated_title = translated_title
            obj.gmt_modified = datetime.datetime.now()
            obj.is_translated = True
            db.session.commit()
            return redirect(
                session.get("referer") if session.get("referer") else url_for(
                    "list.advisory", a_type=a_type) + "?has_translated=2")
    admin_cls = site.admin_dict.get("vul_advisory")
    if not obj.is_translated:
        obj.translation = google_translate(obj.description)
    form = AdvisoryForm(obj=obj)
    referer = request.referrer
    if referer != request.url and urlsplit(referer).netloc == request.host:
        session["referer"] = referer
    else:
        session["referer"] = None
    return render_template("translate.html", form=form, obj=obj, model=admin_cls.model)


@bp.route("/<string:table_name>/<string:cve_id>/translate", endpoint="vul_translate", methods=["GET", "POST"])
@login_required
@permission_required
def vul_translate(table_name, cve_id):
    if table_name not in ("vul_new_running", "vul_new_pre"):
        abort(404)
    admin_cls = site.admin_dict.get(table_name)
    model = admin_cls.model
    obj = model.query.filter_by(cve_id=cve_id).first_or_404()

    if request.method == "POST":
        form = AdvisoryForm(request.form)
        if form.validate_on_submit():
            translation = request.form.get("translation")
            translated_title = request.form.get("translated_title")
            now = datetime.datetime.now()
            obj.summary_cn = translation
            obj.title_cn = translated_title
            obj.gmt_modified = now
            obj.is_translated = True
            new_obj = VulNew.query.filter_by(cve_id=cve_id).first()
            if table_name == "vul_new_running":
                pre_new_obj = VulNewPre.query.filter_by(cve_id=cve_id).first()
                pre_new_obj.title_cn = translated_title
                pre_new_obj.summary_cn = translation
                pre_new_obj.is_translated = True
                pre_new_obj.gmt_modified = now
            if new_obj is None:
                new_obj = VulNew(
                    avd_id=obj.avd_id, gmt_create=obj.gmt_create, cwe_id=obj.cwe_id,
                    release_time=obj.release_time, cvss3_vector=obj.cvss3_vector,
                    cvss3_score=obj.cvss3_score,
                    product_type=obj.product_type, vendor=obj.vendor, product=obj.product,
                    cpe=obj.cpe,
                    authentication=obj.authentication, gained_privilege=obj.gained_privilege,
                    vul_level=obj.vul_level,
                    summary_en=obj.summary_en, poc=obj.poc,
                    poc_disclosure_time=obj.poc_disclosure_time,
                    solution_cn=obj.solution_cn, solution_en=obj.solution_en,
                    reference=obj.reference,
                    classify=obj.classify,
                    cve_id=obj.cve_id, title_en=obj.title_en,
                )
            new_obj.title_cn =  translated_title
            new_obj.summary_cn = translation
            new_obj.is_translated = True
            new_obj.gmt_modified = now
            if new_obj.id is None:
                db.session.add(new_obj)
            db.session.commit()
            return redirect(
                session.get("referer") if session.get("referer") else url_for(
                    "list.vul_translate", table_name=table_name, cve_id=cve_id) + "?checked=2")
    if not obj.is_translated:
        obj.translation = google_translate(obj.summary_en)
    obj.translation = obj.summary_cn
    obj.translated_title = obj.title_cn
    form = AdvisoryForm(obj=obj)
    referer = request.referrer
    if referer != request.url and urlsplit(referer).netloc == request.host:
        session["referer"] = referer
    else:
        session["referer"] = None
    return render_template("translate.html", form=form, obj=obj, model=model)


@bp.route("/advisory/<string:a_type>", endpoint="advisory", methods=["GET", "POST"])
@login_required
@permission_required
def advisory_display(a_type):
    if not ADVISORY_DICT.get(a_type):
        abort(404)
    if request.method == "POST":
        page = request.form.get("page", 1)
        args = request.args.to_dict()
        args["page"] = page
        return redirect(url_for("list.advisory", a_type=a_type) + "?" + urlencode(args))
    admin = site.admin_dict.get("vul_advisory", {})
    title = a_type.strip() + " - 公告信息"
    model = admin.model
    keyword = request.args.get("q", "")
    # search = request.args.get("type", "")
    has_translated = request.args.get("has_translated", "")
    filter_form = AdvisorySearchForm(request.args, meta={'csrf': False})
    # query = model.query
    if ADVISORY_DICT.get(a_type) in (1, 2):
        query = model.query.filter(model.advisory_type == ADVISORY_DICT.get(a_type))
    else:
        sql_result = db.session.execute(
            "SELECT DISTINCT aid FROM vul_rule_usn_aid WHERE rule_name IN "
            "(SELECT rule_name FROM vul_oval_rule WHERE status IN (2,3));"
        )
        aid_list = [i[0] for i in sql_result.fetchall()]
        aid_list = list(map(lambda x: x.upper(), filter(lambda x: x, aid_list)))
        query = model.query.filter(model.aid.in_(aid_list))
    if has_translated and has_translated != '0':
        query = translated_filter(model, query, has_translated)
    if a_type == "ubuntu":
        version_list = ["ubuntu 16.04", "ubuntu 14.04 lts", "ubuntu 18.04 lts"]
        query = query.filter(or_(*[model.affect_versions.contains(version) for version in version_list]))
    try:
        page = int(request.args.get("page", 1))
    except ValueError:
        page = 1
    if keyword:
        condition = [getattr(model, field).ilike("%" + keyword.strip() + "%") for field in admin.search_fields]
        condition_obj = or_(*condition)
        query = query.filter(condition_obj)
    # total = query.count()
    fields = [getattr(model, i) for i in admin.display_fields if hasattr(model, i)]
    fields.extend([getattr(model, "aid"), getattr(model, "id")])
    query = query.with_entities(*fields)
    query = query.order_by(model.pub_date.desc()).paginate(page, per_page=admin.page_items, error_out=False)
    total = query.total
    return render_template(
        "list.html",
        query_list=query.items,
        model=model,
        fields=model._sa_class_manager.values(),
        admin=admin,
        pagination=query,
        q=keyword,
        title=title,
        total=total,
        a_type=a_type,
        filter_form=filter_form
    )


@bp.route("/detail/translate", endpoint="translate_online", methods=["GET"])
@login_required
def ajax_translate():
    aid = request.args.get("pk", "")
    src = request.args.get("src", "google")
    if re.match("^CVE", aid):
        if request.args.get("table", "") == "vul_new_running":
            model = VulNewRun
        else:
            model = VulNewPre
        adv = model.query.filter_by(cve_id=aid).first()
    else:
        adv = Advisory.query.filter_by(aid=aid).first()
    result = {"success": 0}
    if not adv:
        result["errorMsg"] = "公告不存在，请刷新重试"
        return jsonify(result)
    description_or_summary_cn = adv.translation if hasattr(adv, "description") else adv.summary_cn
    description_or_summary_en = adv.description if hasattr(adv, "description") else adv.summary_en
    if src not in translation_src:
        if adv.is_translated:
            src = "raw"
        else:
            src = translation_src[0]
    if src == "google":
        msg = google_translate(description_or_summary_en)
    elif src == "raw":
        msg = description_or_summary_cn
    else:
        if src == "ali-standard":
            translator = Translator(general=False)
        else:
            translator = Translator()
        msg = translator.translate(description_or_summary_en, format_type="html")
    result["success"] = 1
    result["msg"] = msg
    return jsonify(result)
    pass


@bp.route("/vul/syn", endpoint="syn", methods=["GET", "POST"])
@login_required
@permission_required
def vul_new():
    # code=200:需要同步，展示同步数据；code=201:无需同步，展示msg文字
    update_dict = get_vul_new_data()
    response = {"code": 200, "msg": ""}
    if not any([any([data.get("insert"), data.get("update")]) for data in update_dict.values()]):
        response["code"] = 201
        response["msg"] = "没有需要同步的数据"
        return jsonify(response)
    if request.method == "GET":
        response["msg"] = update_dict
    if request.method == "POST":
        try:
            syn_execute(update_dict)
            response["msg"] = "数据同步成功！"
            response["result"] = update_dict
        except Exception as e:
            response["code"] = 500
            response["msg"] = "%s" % e
    return jsonify(response)


@bp.route("/api/translate", endpoint="api_translate", methods=["GET"])
@login_required
def translate_api():
    query = request.args.get("query")
    target = request.args.get("lang")
    lang = target if target in ["zh-cn", "en"] else "zh-cn"
    response = {"code": 200}
    if not query:
        response["query"] = query
        return jsonify(response)
    translator = T()
    text = translator.translate(query, dest=lang).text
    response["query"] = text
    return jsonify(response)


@bp.route("/rule/syn", endpoint="rule_syn", methods=["GET"])
@login_required
@permission_required
def online2local():
    response = {"code": 200}
    online_db = DataBase.query.first()
    if not online_db:
        response["code"] = 404
        response["msg"] = "未找到数据库配置"
        return jsonify(response)
    try:
        command = ("mysqldump -h{from_host} -P{from_port} -u{from_user} -p'{from_pwd}' --databases {from_db_name} "
                   "--tables {from_table_name} | mysql -h{to_host} -P{to_port} -u{to_user} -p'{to_pwd}' {to_db_name}"
                   ).format(
            from_host=online_db.host, from_port=online_db.port, from_user=online_db.user, from_pwd=online_db.pwd,
            from_db_name=online_db.db_name, from_table_name=online_db.table_name, to_host=DB_CONFIG.get("host"),
            to_port=DB_CONFIG.get("port"), to_user=DB_CONFIG.get("user"), to_pwd=DB_CONFIG.get("password"),
            to_db_name=DB_CONFIG.get("db")
        )
        execution = subprocess.Popen(
            command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, close_fds=True)
        execution.wait(600)
        exit_code = execution.returncode
        if exit_code != 0:
            response["code"] = 500
            response["msg"] = "同步出错。\n输出内容：{out}\n输出错误：{err}".format(
                out=execution.stdout.read(), err=execution.stderr.read()
            )
        else:
            response["msg"] = "ok"
    except Exception as e:
        response["code"] = 500
        response["msg"] = "执行出错。\n错误信息：%s" % e
    return jsonify(response)


@bp.route("/rule_aid/update", endpoint="rule_update", methods=["GET", "POST"])
@login_required
@permission_required
def rule_update():
    """

    :return:
        code
            200 -> success
            400 -> need be confirmed
            500 -> update error
    """
    action = "「rule aid 更新」"
    response = {"code": 200}
    if request.method == "GET":
        try:
            execute_result = rule_aid_related()
        except Exception as e:
            response["code"] = 500
            response["msg"] = e.__str__()
            return jsonify(response)
        if isinstance(execute_result, tuple):
            if not execute_result[0]:
                response["msg"] = "success"
                response["error_list"] = execute_result[1]
            else:
                response["code"] = 400
                response["form_list"] = execute_result[0]
                response["error_list"] = execute_result[1]
        else:
            response["code"] = 500
            response["msg"] = execute_result
    elif request.method == "POST":
        try:
            for key, value in request.form.to_dict().items():
                data = db.session.execute(
                    "select distinct rule_name,alias_name from vul_oval_rule where rule_name='{rule_name}'".format(
                        rule_name=key
                    )
                ).first()
                alias_name = data[1]
                version = re.search('(Ubuntu\W\d\d\.\d\d\WLTS)', alias_name)
                cve_id = re.search('(CVE-\d\d\d\d-\d+)', alias_name)
                if version and cve_id:
                    db.session.execute(
                        'insert into vul_rule_usn_aid (rule_name, alias_name,cve_id,type,aid) '
                        'value("{rule_name}","{alias_name}","{cve_id}","{type}","{aid}")'.format(
                            rule_name=key, alias_name=alias_name, cve_id=cve_id.group(1).lower(),
                            type=version.group(1).lower(), aid=value
                        )
                    )
            db.session.commit()
            response["msg"] = "success"
            ding_reporter(action)
        except Exception as e:
            db.session.rollback()
            response["code"] = 500
            response["msg"] = e.__str__()
            ding_reporter(error_msg=str(e), action=action)
    return jsonify(response)


@bp.route("/vul_rule_usn_aid/update", endpoint="rule_aid_obj_update", methods=["POST"])
@login_required
@permission_required
def update_vul():
    response = {"code": 200}
    if request.method == "POST":
        rule_name = request.form.get("rule")
        obj_list = db.session.execute(
            "select distinct rule_name,alias_name,`type` from vul_oval_rule"
            " where type='oval' and (system_name like '%ubuntu%' or "
            "system_name like '%redhat%') and rule_name='{rule}'".format(rule=rule_name)
        ).fetchall()
        if len(obj_list) > 1:
            response["code"] = 400
            response["msg"] = "检测到规则名为「%s」的记录不止一条，请查看后再试。" % rule_name
        elif len(obj_list) == 0:
            response["code"] = 404
            response["msg"] = "未检测到名为「%s」的规则，请确认后重试" % rule_name
        else:
            obj = obj_list[0]
            try:
                if match_redhat(obj[1]):
                    aid = match_redhat(obj[1])
                    if aid:
                        aid = aid.group()
                        db.session.execute(
                            "update vul_rule_usn_aid set alias_name='{alias_name}',aid='{aid}' where rule_name='{rule_name}'".format(
                                alias_name=obj[1], aid=aid, rule_name=rule_name
                            )
                        )
                else:
                    cve, version = match_ubuntu(obj[1])
                    if cve and version:
                        cve_id = cve.group(1).lower()
                        version_type = version.group(1).lower()
                        adv = db.session.execute(
                            "select aid from vul_advisory where affect_versions like '%{type}%' and (cves like '%{cve_id},%' "
                            "or cves like '%{cve_id}')".format(type=version_type, cve_id=cve_id)).fetchone()
                        if not adv:
                            aid = ""
                        else:
                            aid = adv[0]
                        db.session.execute(
                            "update vul_rule_usn_aid set aid='{aid}',`type`='{type}',cve_id='{cve_id}',"
                            "alias_name='{alias_name}' where rule_name='{rule_name}'".format(
                                aid=aid, type=version_type, cve_id=cve_id, alias_name=obj[1], rule_name=rule_name
                            )
                        )
                    response["msg"] = "success"
                db.session.commit()
            except Exception as e:
                db.session.rollback()
                response["code"] = 500
                response["msg"] = "同步规则「%s」时出错。\n错误信息：%s" % (rule_name, e.__str__())
        return jsonify(response)


@bp.route("/<string:table_name>/detail/<string:cve_id>", endpoint="vul_detail", methods=["GET"])
@login_required
@permission_required
def vul_detail(table_name, cve_id):
    admin_cls = site.admin_dict.get(table_name)
    if table_name not in ["vul_new_pre", "vul_new_running"] or not admin_cls:
        abort(404)

    title = "%s - 详情" % cve_id
    model = admin_cls.model
    obj = model.query.filter_by(cve_id=cve_id).first_or_404()
    return render_template("detail.html", vul=obj, model=model, cve_id=cve_id, title=title)


@bp.route("/<string:table_name>/edit/<string:cve_id>", endpoint="vul_edit", methods=["GET", "POST"])
@login_required
@permission_required
def vul_edit(table_name, cve_id):
    admin_cls = site.admin_dict.get(table_name)
    if not admin_cls or table_name not in ["vul_new_pre", "vul_new_running"]:
        abort(404)
    model = admin_cls.model
    obj = model.query.filter_by(cve_id=cve_id).first_or_404()

    title = "%s - 编辑" % cve_id

    form_cls = form_dict.get(table_name)
    if request.method == "GET":
        c_list = obj.classify.split(" ") if obj.classify is not None else None
        obj.classify = c_list
        form = form_cls(obj=obj)
        # form.classify.data = c_list
    elif request.method == "POST":
        syn_flag = request.form.get("flag")
        form = form_cls(request.form)
        if form.is_submitted():
            if syn_flag == "1":
                online_obj = VulNew.query.filter_by(cve_id=cve_id).first()
                if online_obj:
                    form.populate_obj(online_obj)
                    online_obj.gmt_modified = datetime.datetime.now()
                    online_obj.is_translated = True
                else:
                    online_obj = VulNew(
                        avd_id=form.avd_id.data, gmt_create=datetime.datetime.now(), cwe_id=form.cwe_id.data,
                        release_time=form.release_time.data, cvss3_vector=form.cvss3_vector.data,
                        cvss3_score=form.cvss3_score.data,
                        product_type=form.product_type.data, vendor=form.vendor.data, product=form.product.data,
                        cpe=form.cpe.data,
                        authentication=form.authentication.data, gained_privilege=form.gained_privilege.data,
                        vul_level=form.vul_level.data,
                        summary_cn=form.summary_cn.data, summary_en=form.summary_en.data, poc=form.poc.data,
                        poc_disclosure_time=form.poc_disclosure_time.data,
                        solution_cn=form.solution_cn.data, solution_en=form.solution_en.data,
                        reference=form.reference.data,
                        classify=form.classify.data,
                        cve_id=form.cve_id.data, title_en=form.title_en.data, title_cn=form.title_cn.data,
                        gmt_modified=datetime.datetime.now()
                    )
                online_obj.classify = " ".join(online_obj.classify)
                obj.is_translated = True
                db.session.add(online_obj)
            form.populate_obj(obj)
            obj.gmt_modified = datetime.datetime.now()
            obj.classify = " ".join(obj.classify)
            db.session.commit()
            if current_user.is_admin:
                return redirect(url_for("list.vul_detail", table_name=table_name, cve_id=obj.cve_id))
            else:
                return redirect(url_for("list.vul_translate", table_name=table_name, cve_id=cve_id))
    return render_template("form.html", model=model, form=form, title=title)


@bp.route("/cve/running/update", endpoint="running_fresh", methods=["POST"])
@login_required
@permission_required
def fresh_running_cve():
    """
    vul_new_pre -> vul_new_running
    :return:
    """
    start = time.time()
    result = {"code": 200}
    cve_result = db.session.execute(
        "SELECT cves FROM vul_advisory WHERE aid IN( SELECT aid FROM vul_rule_usn_aid WHERE rule_name "
        "IN( SELECT rule_name FROM vul_oval_rule WHERE STATUS != 1))"
    ).fetchall()
    cve_list = set(
        ",".join([result["cves"].upper() for result in cve_result if result["cves"] and re.search(
            "^CVE-\d+-\d+", result["cves"].upper())]).split(",")
    )
    existed_cve = db.session.execute(
        "SELECT DISTINCT cve_id FROM vul_new_pre"
    ).fetchall()
    existed_cve_list = {i[0].strip() for i in existed_cve if i[0]}
    queries = VulNewPre.query.filter(VulNewPre.cve_id.in_(cve_list)).all()
    exclude_cves = cve_list - existed_cve_list
    try:
        # 首先清除VulNewRun表数据
        VulNewRun.query.delete()
        for cve in exclude_cves:
            obj = VulNewRun()
            obj.cve_id = cve
            obj.avd_id = "avd-" + cve.lower()
            obj.rule_status = 3
            obj.gmt_create = obj.gmt_modified = datetime.datetime.now()
            db.session.add(obj)
        for query in queries:
            obj = VulNewRun()
            value_dict = query._sa_instance_state.dict
            value_dict.pop("_sa_instance_state")
            value_dict.pop("id")
            for field, value in value_dict.items():
                if field == "rule_status":
                    value = 3
                setattr(obj, field, value)
            db.session.add(obj)
        db.session.commit()
        result["msg"] = "update success"
        result["rowcount"] = len(queries) + len(exclude_cves)
        result["elapse"] = round(time.time() - start, 2)
    except Exception as e:
        db.session.rollback()
        result["code"] = 500
        result["errorMsg"] = str(e)
    return jsonify(result)


@bp.route("/cve/pre/to/new", endpoint="pre_to_new", methods=["POST"])
@login_required
@permission_required
def pre_to_new():
    """
    vul_new_pre -> vul_new
    :return:
    """
    pre_cve = db.session.execute("SELECT DISTINCT cve_id FROM vul_new_pre").fetchall()
    new_cve = db.session.execute("SELECT DISTINCT cve_id FROM vul_new").fetchall()
    update_list = {i[0].strip() for i in pre_cve if i[0]}.difference({i[0].strip() for i in new_cve if i[0]})
    if update_list:
        try:
            task_worker.submit(future_pre_to_new, update_list)
            #     for field in data_list
            return jsonify({"code": 200})
        except Exception as e:
            print(e)
            return jsonify({"code": 500, "msg": str(e)})


@bp.route("/tag/update", endpoint="tag_update", methods=["POST"])
@login_required
@permission_required
def update_tags():
    try:
        task_worker.submit(fetch_tags)
        return jsonify({"code": 200})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)})


@bp.route("/pr/<int:pk>", endpoint="pr", methods=["GET"])
def pr(pk):
    obj = VulForPr.query.filter_by(id=pk).first_or_404()
    # clf = obj.classify
    # if clf:
    #     for classify, alias_dict in CLASSIFY_MAP.items():
    #         clf = clf.replace(classify, alias_dict.get("cn"))
    # obj.classify = clf.replace(",", "，") if clf else ""
    # return render_template("pr.html", obj=obj)
    return render_template("new_pr.html", obj=obj)


@bp.route("/pr/content/<int:pk>", endpoint="pr_content")
def pr_content(pk):
    obj = VulForPr.query.filter_by(id=pk).first()
    res = {"code": 200}
    if not obj:
        res["code"] = 404
        res["msg"] = "data not found"
        return jsonify(res)
    summary = obj.summary
    urls = get_img_urls(obj.summary)
    if urls:
        mapping = img_to_bs64(urls)
        for k, v in mapping.items():
            summary = summary.replace(k, v)
    res["data"] = {"content": summary}
    return jsonify(res)


def fetch_data(session, sql):
    cursor = session.execute(sql)
    return cursor.fetchall()


def result_construct(title, result):
    aliuid, name = [], []
    for i in result:
        aliuid.append(i[1])
        name.append(title % int(i[0]))
    return aliuid, name


@bp.route("/api/chart", endpoint="cve_chart", methods=["GET"])
def get_chart():
    chart_type = request.args.get("chart_type", "")
    today = datetime.date.today()
    response = []
    if chart_type == "vulns":
        monthly_condition = (
            "m",
            "months",
            f"WHERE YEAR(created_at)={today.year} AND flow_name='sas_high_risk_baseline'"
        )
        weekly_condition = (
            "u",
            "weeks",
            f"WHERE YEAR(created_at)={today.year} "
            f"{'AND WEEK(created_at)>=20' if today.year==2019 else ''} AND flow_name='sas_high_risk_baseline'"
        )
        weekly_description_str = "%d周"
        monthly_description_str = f"{today.year}年%d月"
        aliuid_sql = (
            "SELECT DATE_FORMAT(created_at,'%{0}') {1},count(DISTINCT cron_id) "
            "count FROM job_sessions {2} GROUP BY {1};"
        )
        vuln_sql = (
            "SELECT A.{1} {1},count(DISTINCT B.id) count FROM ("
            "SELECT task_id,cron_id,DATE_FORMAT(created_at,'%{0}') {1} "
            "FROM job_sessions {2}) A JOIN ("
            "SELECT DISTINCT id,task_id FROM task_vulns) B ON A.task_id=B.task_id GROUP BY A.{1}"
        )
        db_session = sessionmaker(bind=cve_db)
        cursor = db_session()
        weekly_title = "应用漏洞扫描数据/周"
        monthly_title = "全部的月度扫描漏洞数/aliuid数"
        monthly_aliuid_result = fetch_data(cursor, aliuid_sql.format(*monthly_condition))
        monthly_vulns_result = fetch_data(cursor, vuln_sql.format(*monthly_condition))
        weekly_aliuid_result = fetch_data(cursor, aliuid_sql.format(*weekly_condition))
        weekly_vulns_result = fetch_data(cursor, vuln_sql.format(*weekly_condition))
        m_aliuid, m_name = result_construct(monthly_description_str, monthly_aliuid_result)
        w_aliuid, w_name = result_construct(weekly_description_str, weekly_aliuid_result)
        monthly_response = {
            "title": monthly_title,
            "aliuid": m_aliuid,
            "name": m_name,
            "data": [j[1] for j in monthly_vulns_result]
        }
        weekly_response = {
            "title": weekly_title,
            "aliuid": w_aliuid,
            "name": w_name,
            "data": [j[1] for j in weekly_vulns_result]
        }
        response.append(weekly_response)
        response.append(monthly_response)
    else:
        sql = (
            "SELECT DATE_FORMAT(release_time,'%m') months,count(1) "
            "count FROM vul_new_pre {0} GROUP BY months;")
        year_condition = (f"WHERE YEAR(release_time)={today.year} ",)
        monthly_description_str = f"{today.year}年%d月"
        cursor = db.session
        year_title = "月度爬取漏洞数"
        result = fetch_data(cursor, sql.format(*year_condition))
        count, name = result_construct(monthly_description_str, result)
        response.append({})
        response.append({"title": year_title, "name": name, "data": count})
    return jsonify(response)


def get_img_urls(s):
    j = []
    [j.extend(i) for i in re.findall(img_src_pattern, s)]
    groups = [k for k in j if k]
    return groups


def img_to_bs64(url_list):
    url_bs64_map = {}
    for url in url_list:
        if url:
            response = requests.get(url, timeout=30)
            base64_data = base64.b64encode(response.content)
            url_bs64_map[url] = "data:image/png;base64," + base64_data.decode("utf8")
    return url_bs64_map


def translated_filter(model, query, has_translated):
    if has_translated == "1":
        query = query.filter(model.is_translated == True)
    else:
        query = query.filter(model.is_translated == False)
    return query


def get_vul_new_data():
    new_db = db_con()
    ol_db = db_con(
        host=OL_DB_CONFIG.get("host"),
        port=OL_DB_CONFIG.get("port"),
        user=OL_DB_CONFIG.get("user"),
        password=OL_DB_CONFIG.get("password"),
        db=OL_DB_CONFIG.get("db")
    )
    new_adv_list = set([tuple(i.values()) for i in new_db.list("vul_advisory", ["aid", "gmt_modified"])])
    old_adv_list = set([tuple(i.values()) for i in ol_db.list("vul_usn_advisory", ["aid", "gmt_modified"])])
    new_cve_title = set([tuple(i.values()) for i in new_db.list("vul_new", ["cve_id", "gmt_modified"])])
    old_cve_title = set([tuple(i.values()) for i in ol_db.list("vul_cve_title", ["cve_id", "gmt_modified"])])
    new_rule_aid = set(
        [tuple(i.values()) for i in
         new_db.list("vul_rule_usn_aid", ["rule_name", "aid", "alias_name", "cve_id"])])
    old_rule_aid = set(
        [tuple(i.values()) for i in
         ol_db.list("vul_rule_usn_aid", ["rule_name", "aid", "alias_name", "cve_id"])])
    update_advs = list(new_adv_list - old_adv_list)
    insert_advs = {j[0] for j in update_advs} - {i[0] for i in old_adv_list}
    modify_advs = {j[0] for j in update_advs} & {i[0] for i in old_adv_list}
    update_cves = list(new_cve_title - old_cve_title)
    insert_cves = {j[0] for j in update_cves} - {i[0] for i in old_cve_title}
    modify_cves = {j[0] for j in update_cves} & {i[0] for i in old_cve_title}
    update_rules = list(new_rule_aid - old_rule_aid)
    insert_rules = {j[0] for j in update_rules} - {i[0] for i in old_rule_aid}
    modify_rules = {j[0] for j in update_rules} & {i[0] for i in old_rule_aid}
    result = {
        "advisory": {
            "update": list(modify_advs),
            "insert": list(insert_advs)
        },
        "cves": {
            "update": list(modify_cves),
            "insert": list(insert_cves)
        },
        "rules": {
            "update": list(modify_rules),
            "insert": list(insert_rules)
        }}
    return result


def make_result(result, field, data):
    ol_db = db_con(
        host=OL_DB_CONFIG.get("host"),
        port=OL_DB_CONFIG.get("port"),
        user=OL_DB_CONFIG.get("user"),
        password=OL_DB_CONFIG.get("password"),
        db=OL_DB_CONFIG.get("db")
    )
    dict_map = {
        "advisory": ol_db.count("vul_usn_advisory", condition={"aid": data[0]}),
        "cves": ol_db.count("vul_cve_title", condition={"cve_id": data[0]}),
        "rules": ol_db.count("vul_rule_usn_aid", condition={"aid": data[0], "rule_name": data[1]})
    }
    if dict_map.get(field):
        result[field]["update"].append(data)
    else:
        result[field]["insert"].append(data)


def syn_execute(update_data):
    # "advisory": {"update": [...], "insert": [...]}, "cves":...}
    conn = online_db_con()
    cursor = conn.cursor()
    import traceback
    try:
        # rule 同步
        rules = update_data.get("rules", {})
        update_rules_names = [item for item in rules.get("update")]
        insert_rules_names = [item for item in rules.get("insert")]
        update_rules_queries = RuleUsnAid.query.filter(RuleUsnAid.rule_name.in_(update_rules_names)).all()
        insert_rules_queries = RuleUsnAid.query.filter(RuleUsnAid.rule_name.in_(insert_rules_names)).all()
        for update_rule in update_rules_queries:
            rule_dict = {
                "aid": update_rule.aid,
                "type": update_rule.type,
                "cve_id": update_rule.cve_id,
                "rule_name": update_rule.rule_name,
                "alias_name": update_rule.alias_name
            }
            params = list(rule_dict.values())
            params.extend((update_rule.rule_name, update_rule.aid))
            sql = (
                "UPDATE vul_rule_usn_aid SET aid=%s,`type`=%s,cve_id=%s,rule_name=%s,alias_name=%s WHERE rule_name=%s;")
            if sql:
                cursor.execute(sql, (
                    update_rule.aid, update_rule.type, update_rule.cve_id, update_rule.rule_name,
                    update_rule.alias_name,
                    update_rule.rule_name))
        # cursor.execute("update vul_rule_usn_aid set {values} where rule_name=%s and aid=%s;".format(
        #     values=",".join(['{field}=%s'.format(field=field) for field in rule_dict.keys()])
        # ), params)
        sql = ""
        for insert_rule in insert_rules_queries:

            rule_dict = {
                "aid": insert_rule.aid if insert_rule.aid else "",
                "type": insert_rule.type,
                "cve_id": insert_rule.cve_id if insert_rule.cve_id else "",
                "rule_name": insert_rule.rule_name,
                "alias_name": insert_rule.alias_name if insert_rule.alias_name else ""
            }
            sql = "INSERT INTO vul_rule_usn_aid(aid,`type`,cve_id,rule_name,alias_name) VALUES (%s,%s,%s,%s,%s);"
            if sql:
                cursor.execute(sql, (
                    insert_rule.aid, insert_rule.type, insert_rule.cve_id, insert_rule.rule_name,
                    insert_rule.alias_name))

        # end

        # advisory 同步
        advisory = update_data.get("advisory", {})
        update_id_list = [item for item in advisory.get("update")]
        insert_id_list = [item for item in advisory.get("insert")]
        update_data_queries = Advisory.query.filter(Advisory.aid.in_(update_id_list)).all()
        insert_data_queries = Advisory.query.filter(Advisory.aid.in_(insert_id_list)).all()
        for new_data in update_data_queries:
            adv_dict = {
                "aid": new_data.aid,
                "title": new_data.title,
                "link": new_data.link,
                "description": new_data.description,
                "translation": new_data.translation,
                "translated_title": new_data.translated_title,
                "cves": new_data.cves,
                "pub_date": new_data.pub_date.strftime("%Y-%m-%d"),
                "record_time": new_data.record_time.strftime("%Y-%m-%d %H:%M:%S"),
                "gmt_modified": new_data.gmt_modified.strftime("%Y-%m-%d %H:%M:%S"),
                "advisory_body": new_data.advisory_body,
                "tags": new_data.tags,
                "tags_en": new_data.tags_en
            }
            params = list(adv_dict.values())
            params.append(new_data.aid)
            cursor.execute("update vul_usn_advisory set {values} where aid=%s".format(
                values=",".join(['{field}=%s'.format(field=field) for field in adv_dict.keys()])
            ), params)
            # cursor.execute("update vul_usn_advisory set {values} where aid=%s".format(
            #     values=",".join(["=".join(items) for items in adv_dict.items()])
            # ), (new_data.aid,))
        for insert_data in insert_data_queries:
            adv_dict = {
                "aid": insert_data.aid,
                "title": insert_data.title,
                "link": insert_data.link,
                "description": insert_data.description,
                "translation": insert_data.translation,
                "translated_title": insert_data.translated_title,
                "cves": insert_data.cves,
                "pub_date": insert_data.pub_date.strftime(
                    "%Y-%m-%d") if insert_data.pub_date else insert_data.record_time.strftime("%Y-%m-%d %H:%M:%S"),
                "record_time": insert_data.record_time.strftime("%Y-%m-%d %H:%M:%S"),
                "gmt_modified": insert_data.gmt_modified.strftime("%Y-%m-%d %H:%M:%S"),
                "advisory_body": insert_data.advisory_body,
                "tags": new_data.tags,
                "tags_en": new_data.tags_en
            }
            cursor.execute("SELECT * FROM vul_usn_advisory WHERE aid=%s", (insert_data.aid,))
            cursor.execute(
                "insert into vul_usn_advisory ({fields}) values ({values})".format(
                    fields=",".join(adv_dict.keys()), values=",".join(["%s"] * len(adv_dict))
                ), tuple(adv_dict.values()))
        # end

        # vul_new -> vul_cve_title 同步
        # cve = update_data.get("cves", {})
        # update_cve_ids = [item for item in cve.get("update")]
        # insert_cve_ids = [item for item in cve.get("insert")]
        # update_cve_queries = VulNewTest.query.filter(VulNewTest.cve_id.in_(update_cve_ids)).all()
        # insert_cve_queries = VulNewTest.query.filter(VulNewTest.cve_id.in_(insert_cve_ids)).all()
        # for cve_obj in update_cve_queries:
        #     if cve_obj.cve_id:
        #         cve_dict = {
        #             "cve_id": cve_obj.cve_id,
        #             "cvss3_score": cve_obj.cvss3_score,
        #             "title_cn": cve_obj.title_cn,
        #             "title_en": cve_obj.title_en,
        #             "gmt_modified": cve_obj.gmt_modified.strftime("%Y-%m-%d %H:%M:%S")
        #         }
        #         params = list(cve_dict.values())
        #         params.append(cve_obj.cve_id)
        #         cursor.execute("update vul_cve_title set {values} where cve_id=%s".format(
        #             values=",".join(['{field}=%s'.format(field=field) for field in cve_dict.keys()])
        #         ), params)
        #         # cursor.execute("update vul_cve_title set {values} where cve_id=%s".format(
        #         #     values=",".join(["=".join(items) for items in cve_dict.items()])
        #         # ), (cve_obj.cve_id,))
        # for new_obj in insert_cve_queries:
        #     if new_obj.cve_id:
        #         cve_dict = {
        #             "cve_id": new_obj.cve_id,
        #             "cvss3_score": new_obj.cvss3_score,
        #             "title_cn": new_obj.title_cn,
        #             "title_en": new_obj.title_en,
        #             "gmt_modified": new_obj.gmt_modified.strftime("%Y-%m-%d %H:%M:%S")
        #         }
        #         cursor.execute(
        #             "insert into vul_cve_title ({fields}) values ({values})".format(
        #                 fields=",".join(cve_dict.keys()), values=",".join(["%s"] * len(cve_dict))
        #             ), tuple(cve_dict.values()))
        # end
        conn.commit()
    except Exception as e:
        conn.rollback()
        traceback.print_exc()
        conn.commit()
        conn.close()
        raise ValueError("同步过程中发生错误：%s" % e)


def online_db_con():
    connection = pymysql.connect(
        host=OL_DB_CONFIG.get("host"),
        port=OL_DB_CONFIG.get("port"),
        user=OL_DB_CONFIG.get("user"),
        password=OL_DB_CONFIG.get("password"),
        db=OL_DB_CONFIG.get("db"),
        charset="utf8",
        cursorclass=pymysql.cursors.DictCursor
    )
    return connection


@bp.app_template_filter()
def relative_time(abs_time):
    if isinstance(abs_time, datetime.datetime):
        duration = datetime.datetime.now() - abs_time
        days, hours = duration.days, duration.seconds // 3600
        if days and hours:
            return "%d天 %d小时" % (days, hours)
        else:
            if days:
                return "%d 天" % days
            elif hours:
                return "%d 小时" % hours
            else:
                return "1 小时"
    else:
        raise TypeError("Only datetime object accepted")
