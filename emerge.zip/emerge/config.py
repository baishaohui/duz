# -*- coding: utf-8 -*-
import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
# DB_CONFIG = {
#         "host": "47.97.46.232",
#         # "host": "localhost",
#         "port": 8443,
#         "user": "root",
#         "password": "!&akUfznGd",
#         "db": "ti_db_test",
#     }
DB_CONFIG = {
    "host": "rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com",
    "port": 5656,
    "user": "shaohui",
    "password": "gha96gzTK&jm#",
    "db": "vul_db",
}
OL_DB_CONFIG = {
    "host": "47.97.46.232",
    # "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "!&akUfznGd",
    "db": "ti_db",
}
LOG_LEVEL = "info"

DING_TEMPLATE = {
    "msgtype": "markdown",
    "markdown": {
        "title": "漏洞情报",
        "text": "%s"
    },
    "at": {
        "isAtAll": False
    }
}
ACCESS_KEY_ID = "LTAI3EI5rmg8Kyvn"
ACCESS_KEY_SECRET = "Ql5US6HGeSjiGoRiXWDhtLKgcqtLnY"
NLP_REGION = 'cn-shanghai'
NLP_DOMAIN = "nlp.cn-shanghai.aliyuncs.com"
NLP_API_PATH = "/nlp/api/translate/general"
ADVISORY_TAG_CHOICES = {
    "需要重启": "Restart Required",
    "远程利用": "Remotely Exploitable",
    "存在EXP": "Exploit Exists",
    "本地提权": "Elevation of Privilege",
    "代码执行": "Code Execution"
}


class Config:
    BABEL_DEFAULT_LOCALE = 'zh'
    BABEL_DEFAULT_TIMEZONE = 'CST'
    SECRET_KEY = "mV5bHPJPDn7k"
    PER_PAGE = 30
    SCHEDULE_SECONDS = 5
    # Schduler config
    # JOBS = [
    #     {
    #         'id': 'monitor_job',
    #         'func': 'schedule:schedule_job',
    #         'args': None,
    #         'trigger': 'interval',
    #         'seconds': SCHEDULE_SECONDS
    #         # 'seconds': 1
    #     },
    #     {
    #         'id': 'remove_job',
    #         'func': 'schedule:check_tactic',
    #         'args': None,
    #         'trigger': 'interval',
    #         'seconds': SCHEDULE_SECONDS
    #     }
    # ]
    SQLALCHEMY_POOL_TIMEOUT = 300
    SQLALCHEMY_POOL_SIZE = 15
    SQLALCHEMY_POOL_RECYCLE = 300
    SQLALCHEMY_MAX_OVERFLOW = 100
    SCHEDULER_API_ENABLED = True


class DevelopmentConfig(Config):
    DEBUG = True
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    # SQLALCHEMY_DATABASE_URI = "mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/ti_db"
    # SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:!&akUfznGd@localhost/ti_db_test"   # local
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:!&akUfznGd@47.97.46.232/ti_db_test"  # remote
    # DB_CONFIG = {
    #     "host": "rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com",
    #     "port": 5656,
    #     "user": "shaohui",
    #     "password": "gha96gzTK&jm#",
    #     "db": "ti_db",
    # }
    DB_CONFIG = {
        "host": "127.0.0.1",
        "port": 8443,
        "user": "root",
        # "password": "W6cO1G@YO36XYLva", # local
        "password": "!&akUfznGd",  # remote
        "db": "ti_db_test",
    }


class ProductConfig(Config):
    DEBUG = False
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/vul_db"
    SQLALCHEMY_BINDS = {
        "cva": "mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/cva_db"
    }
    # SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:W6cO1G@YO36XYLva@localhost:8443/ti_db_test"    # local
    # SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:!&akUfznGd@47.97.46.232:8443/ti_db_test"    # remote


config = {
    'development': DevelopmentConfig,
    'production': ProductConfig,
    'default': DevelopmentConfig
}
# W6cO1G@YO36XYLva
JSON_SORT_KEYS = False
VUL_LEVEL = {
    "low": "低危",
    "medium": "中危",
    "high": "高危",
    "serious": "严重",
    "critical": "危急"
}

CLASSIFY_MAP = {
    'impact:elevation_of_privilege': {'cn': '权限提升', 'en': 'Privilege Escalation'},
    'impact:remote_code_execution': {'cn': '代码执行', 'en': 'Code Execution'},
    'impact:remote_denial_of_service': {'cn': '拒绝服务', 'en': 'Denial of Service'},
    'impact:information_disclosure': {'cn': '信息泄露', 'en': 'Information Disclosure'},
    'impact:security_feature_bypass': {'cn': '安全绕过', 'en': 'Security Bypass'},
    'impact:spoofing': {'cn': '欺骗', 'en': 'Spoofing'}, 'impact:tampering': {'cn': '篡改', 'en': 'Tampering'},
    'impact:xss': {'cn': '跨站脚本', 'en': 'Cross-Site Scripting (XSS)'},
    'impact:csrf': {'cn': '跨站请求伪造', 'en': 'Cross-Site Request Forgery (CSRF)'},
    'via:remote': {'cn': '远程', 'en': 'Remote'},
    'via:limited_remote': {'cn': '有限远程', 'en': 'Limited Remote'},
    'via:local': {'cn': '本地', 'en': 'Local'}, 'via:physical': {'cn': '物理', 'en': 'Physical'},
    'impact:unspecified': {'cn': '未指明', 'en': 'Unspecified'},
    'impact:sql_injection': {'cn': 'SQL注入', 'en': 'SQL Injection'},
    'impact:arbitrary_file_read': {'cn': '任意文件读取', 'en': 'Arbitrary File Read'},
    'impact:arbitrary_file_overwrite': {'cn': '任意文件写入', 'en': 'Arbitrary File Overwrite'},
    'impact:xxe': {'cn': 'XML实体注入', 'en': 'XML External Entity Injection'},
    'impact:session_fixation': {'cn': '会话固定', 'en': 'Session Fixation'},
    'impact:ssrf': {'cn': '服务端请求伪造', 'en': 'Server-Side Request Forgery'},
    'impact:directory_traversal': {'cn': '目录遍历', 'en': 'Directory Traversal'},
    'impact:unserialize': {'cn': '反序列化', 'en': 'Unserialize'},
    'flaw:buffer_overflow': {'cn': '缓冲区溢出', 'en': 'Buffer Overflow'},
    'flaw:memory_corruption': {'cn': '内存破坏', 'en': 'Memory Corruption'},
    'flaw:out_of_bounds_access': {'cn': '越界访问', 'en': 'Out of Bounds Access'},
    'flaw:use_after_free': {'cn': '释放后重用', 'en': 'UAF'},
    'flaw:weak_configuration': {'cn': '弱配置', 'en': 'Weak Configuration'},
    'flaw:crypto': {'cn': '加密', 'en': 'Crypto'},
    'flaw:side_channel': {'cn': '边信道', 'en': 'Side Channel'}
}
