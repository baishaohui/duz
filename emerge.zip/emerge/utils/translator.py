# -*- coding: utf8 -*-
import re
import uuid
import json
from bs4 import BeautifulSoup as bs
from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.request import CommonRequest
from aliyunsdkcore.http import method_type
from py_translator import TEXTLIB, Translator as translator
from config import ACCESS_KEY_ID, ACCESS_KEY_SECRET, NLP_REGION, NLP_DOMAIN, NLP_API_PATH

BLANK_REGEX = re.compile("</?(\s?)(p|li|br|ul|P|LI|BR|UL|Li|Br|Ul|lI|bR|uL)(\s?)>")


class Translator:
    client = AcsClient(ACCESS_KEY_ID, ACCESS_KEY_SECRET, NLP_REGION)

    def __init__(self, general=True):
        self.uri = NLP_API_PATH if general else "/nlp/api/translate/standard"
        self.request = CommonRequest()
        self._response = None
        self.response = None
        self.request_initial()

    def request_initial(self):
        self.request.set_domain(NLP_DOMAIN)
        self.request.set_uri_pattern(self.uri)
        self.request.set_method(method_type.POST)
        self.request.add_header("x-acs-signature-method", "HMAC-SHA1")
        self.request.add_header("x-acs-signature-nonce", uuid.uuid4().hex)
        self.request.add_header("x-acs-signature-version", "1.0")
        self.request.set_content_type("application/json;chrset=utf-8")
        self.request.set_accept_format("application/json;chrset=utf-8")
        self.request.set_version('2018-04-08')
        self.request.set_action_name("None")

    def _make_request(self):
        try:
            self._response = self.client.do_action_with_exception(self.request)
        except Exception as e:
            print(e)
            pass

    def set_text(self, text, source, target, format_type="text"):
        if not isinstance(text, str):
            raise ValueError("Text takes strings only")
        text = {
            "q": text,
            "source": source,
            "target": target,
            "format": format_type
        }
        self.request.set_content(json.dumps(text))

    def translate(self, text, source="en", target="zh", format_type="text"):
        if not text:
            return ""
        self.set_text(text, source, target, format_type=format_type)
        self._make_request()
        if self._response:
            self.response = json.loads(str(self._response, "utf-8"))
            if isinstance(self.response, dict):
                return self.response.get("data").get("translated_text")


def google_translate(text, des="zh-cn"):
    if text:
        text = text.replace("<br/>", " ")
        google_tran = translator()
        s = bs(text, "lxml")
        p_list = s.find_all("p")
        li_list = s.find_all("li")
        text = s.prettify(formatter=None)
        for p in p_list:
            t = p.get_text().strip()
            tran_t = google_tran.translate(t, dest=des).text
            text = text.replace(t, tran_t)
        for li in li_list:
            t = li.get_text().strip()
            if t:
                repl = google_tran.translate(t, dest=des).text
                text = text.replace(t.strip(), repl)
        result = re.sub(BLANK_REGEX, lambda x: x.group().replace(" ", ""), text)
        return result.replace("（", "(").replace("）", ")")
    return ""


if __name__ == '__main__':
    # raw_sentence = """
    # php: Off-by-one error in phar_parse_pharfile when loading crafted phar archive (CVE-2016-10160)
    # php: Wrong calculation in exif_convert_any_to_int function (CVE-2016-10158)
    # oniguruma: Out-of-bounds stack read in match_at() during regular expression searching (CVE-2017-9224)
    # """
    # raw_sentence = """
    # <p>PHP is an HTML-embedded scripting language commonly used with the Apache HTTP Server.<br/></p><p>The following packages have been upgraded to a later upstream version: rh-php70-php (7.0.27). (BZ#1518843)<br/></p><p>Security Fix(es):<br/></p><ul><li> php: Heap overflow in mysqlnd when not receiving UNSIGNED_FLAG in BIT field (CVE-2016-7412)<br/></li><li> php: Use after free in wddx_deserialize (CVE-2016-7413)<br/></li><li> php: Out of bounds heap read when verifying signature of zip phar in phar_parse_zipfile (CVE-2016-7414)<br/></li><li> php: Stack based buffer overflow in msgfmt_format_message (CVE-2016-7416)<br/></li><li> php: Missing type check when unserializing SplArray (CVE-2016-7417)<br/></li><li> php: Null pointer dereference in php_wddx_push_element (CVE-2016-7418)<br/></li><li> php: Use-after-free vulnerability when resizing the 'properties' hash table of a serialized object (CVE-2016-7479)<br/></li><li> php: Invalid read when wddx decodes empty boolean element (CVE-2016-9935)<br/></li><li> php: Use After Free in unserialize() (CVE-2016-9936)<br/></li><li> php: Wrong calculation in exif_convert_any_to_int function (CVE-2016-10158)<br/></li><li> php: Integer overflow in phar_parse_pharfile (CVE-2016-10159)<br/></li><li> php: Off-by-one error in phar_parse_pharfile when loading crafted phar archive (CVE-2016-10160)<br/></li><li> php: Out-of-bounds heap read on unserialize in finish_nested_data() (CVE-2016-10161)<br/></li><li> php: Null pointer dereference when unserializing PHP object (CVE-2016-10162)<br/></li><li> gd: DoS vulnerability in gdImageCreateFromGd2Ctx() (CVE-2016-10167)<br/></li><li> gd: Integer overflow in gd_io.c (CVE-2016-10168)<br/></li><li> php: Use of uninitialized memory in unserialize() (CVE-2017-5340)<br/></li><li> php: Buffer over-read from unitialized data in gdImageCreateFromGifCtx function (CVE-2017-7890)<br/></li><li> oniguruma: Out-of-bounds stack read in match_at() during regular expression searching (CVE-2017-9224)<br/></li><li> oniguruma: Heap buffer overflow in next_state_val() during regular expression compilation (CVE-2017-9226)<br/></li><li> oniguruma: Out-of-bounds stack read in mbc_enc_len() during regular expression searching (CVE-2017-9227)<br/></li><li> oniguruma: Out-of-bounds heap write in bitset_set_range() (CVE-2017-9228)<br/></li><li> oniguruma: Invalid pointer dereference in left_adjust_char_head() (CVE-2017-9229)<br/></li><li> php: Incorrect WDDX deserialization of boolean parameters leads to DoS (CVE-2017-11143)<br/></li><li> php: Incorrect return value check of OpenSSL sealing function leads to crash (CVE-2017-11144)<br/></li><li> php: Out-of-bounds read in phar_parse_pharfile (CVE-2017-11147)<br/></li><li> php: Stack-based buffer over-read in msgfmt_parse_message function (CVE-2017-11362)<br/></li><li> php: Stack based 1-byte buffer over-write in zend_ini_do_op() function Zend/zend_ini_parser.c (CVE-2017-11628)<br/></li><li> php: heap use after free in ext/standard/var_unserializer.re (CVE-2017-12932)<br/></li><li> php: heap use after free in ext/standard/var_unserializer.re (CVE-2017-12934)<br/></li><li> php: reflected XSS in .phar 404 page (CVE-2018-5712)<br/></li><li> php, gd: Stack overflow in gdImageFillToBorder on truecolor images (CVE-2016-9933)<br/></li><li> php: NULL Pointer Dereference in WDDX Packet Deserialization with PDORow (CVE-2016-9934)<br/></li><li> php: wddx_deserialize() heap out-of-bound read via php_parse_date() (CVE-2017-11145)<br/></li><li> php: buffer over-read in finish_nested_data function (CVE-2017-12933)<br/></li><li> php: Out-of-bound read in timelib_meridian() (CVE-2017-16642)<br/></li><li> php: Denial of Service (DoS) via infinite loop in libgd gdImageCreateFromGifCtx function in ext/gd/libgd/gd_gif_in.c (CVE-2018-5711)<br/></li></ul><p>For more details about the security issue(s), including the impact, a CVSS score, and other related information, refer to the CVE page(s) listed in the References section.<br/></p><p>Additional Changes:<br/></p><p>For details, see the Red Hat Software Collections 3.1 Release Notes linked from the References section.</p><p></p>
    # """
    # print(google_translate(raw_sentence))
    # obj = Translator()
    # print(obj.translate("MySQL拒绝服务漏洞", source="zh", target="en"))
    print(google_translate("that's it"))

