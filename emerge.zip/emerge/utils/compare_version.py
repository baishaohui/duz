# -*- coding: utf-8 -*-
import re


def compare(v, l):
    if l == v:
        return True
    if l in v:
        return False
    if v in l:
        return True
    seps = re.compile("[-.~]")
    v_list = seps.split(v)
    l_list = seps.split(l)
    for r, la in zip(v_list, l_list):
        if la.isdigit() and r.isdigit():
            la = int(la)
            r = int(r)
        if la > r:
            return True
        if la < r:
            return False


def v_compare(rule: str, latest):
    if latest is None:
        return
    if rule in latest:
        return True
    versions = rule.split(",")
    if ":" in latest:
        latest = latest.split(":")[1]
    for version in versions:
        if ":" in version:
            version = version.split(":")[1]
        if not compare(version, latest):
            return False
    return True


if __name__ == '__main__':
    v = "5.5.52-0ubuntu0.14.04.1"
    l = "1.0.0-4ubuntu0.14.04.11"
    print(v_compare(v, l))
