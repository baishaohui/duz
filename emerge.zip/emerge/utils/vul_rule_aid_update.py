from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import re
import json

Base = declarative_base()
metadata = Base.metadata

db = create_engine('mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/vul_db')
# db = create_engine('mysql+pymysql://root:!&akUfznGd@47.97.46.232:8443/ti_db_test')


def rule_aid_related(target=None):
    DBSession = sessionmaker(bind=db)
    session = DBSession()
    if not target:
        # result1 = session.execute(
        #     "select distinct rule_name,alias_name from vul_oval_rule"
        #     " where type='oval' and (system_name like '%ubuntu%' or system_name like '%redhat%') and rule_name not in "
        #     "(select distinct rule_name from vul_rule_usn_aid)"
        # ).fetchall()
        result1 = session.execute(
            "select distinct rule_name,alias_name from vul_oval_rule"
            " where type='oval' and (system_name like 'ubuntu%' or system_name like '%redhat%') and "
            " gmt_create > '2019-04-01 00:00:00'"
            " and rule_name not in (select distinct rule_name from vul_rule_usn_aid) and  lower(rule_detail) not like "
            "'%firefox%' and lower(rule_detail) not like '%thunderbird%' and lower(rule_detail) not like '%nvidia%' "
        ).fetchall()
    else:
        if isinstance(target, list):
            result1 = target
        else:
            result1 = [target]
    online_rules = session.execute(
        "select repo_id, `status` from vul_oval_rule where `status` in (2,3) and `type`='oval';").fetchall()
    unmatched_rules = []
    try:
        online_cve_list = []
        online_cves = []
        # 将已上线状态的rule status同步到vul_new表
        for rule in online_rules:
            if rule[0]:
                online_cves.extend(["'" + j + "'" for j in rule[0].strip(",").split(",")])
                online_cve_list.extend([j for j in rule[0].strip(",").split(",")])
        session.execute("update vul_new set rule_status=3 where cve_id in ({cves})".format(
            cves=",".join(set(online_cves))
        ))
        session.commit()
        ######
        # 找出rule表中有，而vul_new表中不存在的cve
        exist_cves = session.execute(
            "select cve_id from vul_new where cve_id in ({cves})".format(cves=",".join(online_cves))).fetchall()
        exist_cve_set = set([cve[0] for cve in exist_cves])
        non_exist_cves = list(set(online_cve_list) - exist_cve_set)
        ######
        for r in result1:
            if all(match_ubuntu(r[1])):
                match1, match2 = match_ubuntu(r[1])
                cve_id = match1.group(1).lower()
                version_type = match2.group(1).lower()
                aid_list = session.execute(
                    "select aid,title from vul_advisory where affect_versions like '%{type}%' and (cves like '%{cve_id},%' "
                    "or cves like '%{cve_id}')".format(type=version_type, cve_id=cve_id)).fetchall()
                if len(aid_list) == 0:
                    session.execute(
                        'insert into vul_rule_usn_aid (rule_name, alias_name,cve_id,type,aid) '
                        'value("{rname}","{aname}","{cve_id}","{type}","")'.format(
                            rname=r[0], aname=r[1], cve_id=cve_id, type=version_type))
                elif len(aid_list) == 1:
                    session.execute(
                        'insert into vul_rule_usn_aid (rule_name, alias_name,cve_id,type,aid) '
                        'value("{rname}","{aname}","{cve_id}","{type}","{aid}")'.format(
                            rname=r[0], aname=r[1], cve_id=cve_id, type=version_type, aid=aid_list[0][0]))
                elif len(aid_list) > 1:
                    # 将匹配公告数大于1的规则返回
                    num = 0
                    num_v = 0
                    matched_aid = ""
                    matched_vul = ""
                    for aid in aid_list:
                        # aid格式：(aid字段，title字段）
                        if not re.search(r"\(.*\)", aid[1]):
                            if re.search(r"vulnerabilities", aid[1]):
                                num_v += 1
                                matched_vul = aid[0]
                            num += 1
                            matched_aid = aid[0]
                    if num == 1:
                        session.execute(
                            'insert into vul_rule_usn_aid (rule_name, alias_name,cve_id,type,aid) '
                            'value("{rname}","{aname}","{cve_id}","{type}","{aid}")'.format(
                                rname=r[0], aname=r[1], cve_id=cve_id, type=version_type, aid=matched_aid))
                    else:
                        if num_v == 1:
                            session.execute(
                                'insert into vul_rule_usn_aid (rule_name, alias_name,cve_id,type,aid) '
                                'value("{rname}","{aname}","{cve_id}","{type}","{aid}")'.format(
                                    rname=r[0], aname=r[1], cve_id=cve_id, type=version_type, aid=matched_vul))
                        else:
                            aids = [aid.values()[0] for aid in aid_list]
                            existed_flag = False
                            for a in aids:
                                existed = session.execute(
                                    "select count(aid) from vul_rule_usn_aid where aid='{aid}'".format(aid=a)).fetchall()
                                if existed[0][0]:
                                    session.execute(
                                        'insert into vul_rule_usn_aid (rule_name, alias_name,cve_id,type,aid) '
                                        'value("{rname}","{aname}","{cve_id}","{type}","{aid}")'.format(
                                            rname=r[0], aname=r[1], cve_id=cve_id, type=version_type, aid=a))
                                    existed_flag = True
                                    break
                            if not existed_flag:
                                unmatched_rules.append({r[0]: aids})
            elif match_redhat(r[1]):
                aid = match_redhat(r[1]).group()
                session.execute(
                    'insert into vul_rule_usn_aid (rule_name, alias_name, `type`, aid)  '
                                'VALUE("{rname}","{aname}","{type}","{aid}")'.format(
                    rname=r[0], aname=r[1], type="redhat", aid=aid
                ))
        session.commit()
        session.close()
        return unmatched_rules, non_exist_cves
    except Exception as e:
        session.rollback()
        session.close()
        return e.__str__()


def match_redhat(rule_name):
    return re.search('(RHSA-\d\d\d\d:\d\d\d\d)', rule_name)


def match_ubuntu(rule_name):
    match1 = re.search('(CVE-\d\d\d\d-\d+)', rule_name)
    match2 = re.search('(Ubuntu\W\d\d\.\d\d\WLTS)', rule_name)
    return match1, match2


