# -*- coding: utf-8 -*-
import datetime
import logging
import pymysql

from utils.error_hunter import ding_reporter

db_config = {
    "host": "rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com",
    "port": 5656,
    "user": "shaohui",
    "password": "gha96gzTK&jm#",
    "db": "vul_db",
    "charset": "utf8"
}
con = pymysql.connect(**db_config)


def get_classify(cve_id: str):
    sql = "SELECT classify FROM vul_new WHERE cve_id=%s"
    cur = con.cursor(pymysql.cursors.SSDictCursor)
    cur.execute(sql, (cve_id,))
    return cur.fetchone()


def logger():
    log = logging.basicConfig(
        level=logging.INFO,
        filename='new.log',
        filemode='a',
        format='%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s'
    )
    return log


def get_poc(cves: str):
    sql_temp = "SELECT poc FROM vul_new WHERE cve_id=%s"
    cursor = con.cursor(pymysql.cursors.SSDictCursor)
    for cve in cves.split(","):
        cursor.execute(sql_temp, (cve.upper(),))
        data = cursor.fetchall()
        if data and data[0].get("poc"):
            return True


def include_kernel(title):
    if title.count("kernel") or title.count("Kernel"):
        return True


def pack_tag(classify: str, tags: list, tags_en: list):
    if classify.count("via:remote") and not tags_en.count("Remotely Exploitable"):
        tags.append("远程利用")
        tags_en.append("Remotely Exploitable")
    if classify.count("impact:elevation_of_privilege") and not tags_en.count("Elevation of Privilege"):
        tags.append("本地提权")
        tags_en.append("Elevation of Privilege")
    if classify.count("impact:remote_code_execution") and not tags_en.count("Code Execution"):
        tags.append("代码执行")
        tags_en.append("Code Execution")
    return tags, tags_en


def fetch_tags():
    sql = (
        "SELECT vul_advisory.aid AS aid , vul_advisory.title AS title, vul_advisory.cves AS cves, vul_advisory.tags AS "
        "tags, vul_advisory.tags_en AS tags_en FROM( SELECT vul_rule_usn_aid.aid AS aid ,"
        " vul_rule_usn_aid.rule_name AS rule_name , vul_oval_rule.`status` AS `status` FROM vul_rule_usn_aid LEFT "
        "JOIN vul_oval_rule ON vul_oval_rule.rule_name = vul_rule_usn_aid.rule_name HAVING `status` IN(2 , 3)) T LEFT "
        "JOIN vul_advisory ON vul_advisory.aid = T.aid GROUP BY aid HAVING aid IS NOT NULL "
    )
    log = logger()
    update_sql = "UPDATE vul_advisory SET tags=%s, tags_en=%s, gmt_modified=%s WHERE aid=%s"
    cursor = con.cursor(pymysql.cursors.SSDictCursor)
    cursor.execute(sql)
    all_data = cursor.fetchall()
    try:
        c = 0
        n = 0
        for item in all_data:
            c += 1
            print(c)
            tags = []
            tags_en = []
            aid = item.get("aid")
            title = item.get("title")
            cves = item.get("cves", "") or ""
            if include_kernel(title):
                tags.append("需要重启")
                tags_en.append("Restart Required")

            if aid.startswith("CVE"):
                cls = get_classify(aid.upper())
                if get_poc(aid):
                    tags.append("存在EXP")
                    tags_en.append("Exploit Exists")
                if cls:
                    classify = cls.get("classify", "")
                    tags, tags_en = pack_tag(classify, tags, tags_en)
                else:
                    n += 1
            else:
                if get_poc(cves):
                    tags.append("存在EXP")
                    tags_en.append("Exploit Exists")
                for cve in cves.upper().split(","):
                    cls = get_classify(cve)
                    if cls:
                        classify = cls.get("classify")
                        tags, tags_en = pack_tag(classify, tags, tags_en)
            tags = ",".join(tags)
            tags_en = ",".join(tags_en)
            if tags != item.get("tags", "") or tags_en != item.get("tags_en"):
                cursor.execute(update_sql, (tags, tags_en, datetime.datetime.now(), aid))
                con.commit()
    except Exception as e:
        con.rollback()
        log.error(str(e))


def future_pre_to_new(update_list):
    from run import app
    from app import db
    from app.web.models import VulNew
    with app.app_context():
        action = "「预发 > 漏洞库数据同步」"
        cve_list = ",".join(["'" + i + "'" for i in update_list])
        data_list = db.session.execute(
            "select * from vul_new_pre WHERE cve_id IN ({cve_list})".format(cve_list=cve_list)).fetchall()
        n = 0
        for data in data_list:
            # if data.cve_id == "CVE-2017-5715":
            #     print("got it !")
            if (data.title_en is not None and data.title_en.strip()) and \
                    data.cvss3_score and (data.summary_en or data.summary_en.strip()) and data.release_time:
                n += 1
                new_obj = VulNew()
                for field, value in data.items():
                    if hasattr(new_obj, field) and field != "id":
                        if field == "gmt_create" or field == "gmt_modified":
                            value = datetime.datetime.now()
                        setattr(new_obj, field, value)
                try:
                    db.session.add(new_obj)
                    db.session.commit()
                except Exception as e:
                    ding_reporter(error_msg=str(e), action=action)
                    db.session.rollback()
                    print(e)
        ding_reporter(action=action)