# -*- coding: utf-8 -*-
import json

import requests

# test
DING_URL = \
    "https://oapi.dingtalk.com/robot/send?access_token=e0ff8260309dcbf818336dc5722475e7ef2d037501ae64587d7b6eb6776962b7"

# notice
# DING_URL = \
#     "https://oapi.dingtalk.com/robot/send?access_token=411bbde3d4c7aa76b383354c2f24aa5d46efc8795b8a303b387c7cb87efe6364"
DING_TEMPLATE = {
    "msgtype": "text",
    "text": {
        "content": ""
    },
    "at": {
        "isAtAll": False
    }
}


def ding_reporter(ding_url=None, error_msg=None, action=None):
    if ding_url is None:
        ding_url = DING_URL
    if error_msg is None:
        error_msg = "%s 操作回调消息：更新成功！" % action or ""
    else:
        error_msg = f"{action}操作出错：\n{error_msg}"
    try:
        DING_TEMPLATE["text"]["content"] = error_msg
        response = send_msg(DING_TEMPLATE, ding_url)
    except Exception as e:
        print(e)


def send_msg(template, robot):
    header = {"Content-Type": "application/json; charset=utf-8"}
    msg = json.dumps(template, ensure_ascii=False)
    response = requests.post(robot, data=msg.encode("utf-8"), headers=header)
    return json.loads(response.text)
