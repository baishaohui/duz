# -*- coding: utf-8 -*-
import json
import datetime
from sqlalchemy.orm.dynamic import AppenderMixin


class JSONEncoder(json.JSONEncoder):

    def default(self, o):
        if isinstance(o, datetime.datetime):
            return str(o)
        if AppenderMixin in o.__class__.__bases__:
            return ""
        return json.JSONEncoder.default(self, o)