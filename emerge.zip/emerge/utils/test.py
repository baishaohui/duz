DB_CONFIG = {
    "host": "rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com",
    "port": 5656,
    "user": "shaohui",
    "password": "gha96gzTK&jm#",
    "db": "vul_db",
}


import pymysql


con  = pymysql.connect(**DB_CONFIG)


def update_status():
    cursor = con.cursor(pymysql.cursors.SSDictCursor)
    sql = "SELECT cve_id,title_cn,summary_cn FROM vul_new WHERE cve_id IN (SELECT cve_id FROM vul_new_running) AND is_translated=1"
    update_sql = "update vul_new_running set is_translated=1, summary_cn=%s, title_cn=%s WHERE cve_id=%s"
    cursor.execute(sql)
    cves = cursor.fetchall()
    print(len(cves))
    for cve in cves:
        print(cve)
        cursor.execute(update_sql, (cve.get("summary_cn"), cve.get("title_cn"), cve.get("cve_id")))
        con.commit()


if __name__ == '__main__':
    update_status()