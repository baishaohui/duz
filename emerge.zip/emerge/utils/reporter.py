# -*- coding: utf-8 -*-
import os
import json
import requests

from utils.logger import LogUtil
from config import DING_TEMPLATE

logger_obj = LogUtil("error", file_name=os.path.join("..", "error", "task.log"))


def ding_reporter(tactic_obj, error_msg):
    try:
        msg_template = tactic_obj.ding_msg
        if isinstance(error_msg, dict):
            if not msg_template:
                error_msg = "#### 监控警告：%s\n\n#### 查询结果：%s" % (
                    tactic_obj.name, " and ".join(["%s='%s'" % (k, str(v)) for k, v in error_msg.items()]))
            else:
                error_msg = msg_template.format(**error_msg)
        elif isinstance(error_msg, tuple) or isinstance(error_msg, list):
            if msg_template:
                separator = "\n\n &nbsp;  \n\n *** \n\n &nbsp;  \n\n "
                msg_list = []
                for item in error_msg:
                    if sum([len(msg) for msg in msg_list]) + len(separator) * (len(msg_list) - 1) > 5800:
                        break
                    msg_list.append(msg_template.format(**item).strip())
                msg = separator.join(msg_list)
            else:
                msg = "\n\n &nbsp;  \n\n *** \n\n #### ".join([json.dumps(item) for item in error_msg[:50]])
            title = "# " + tactic_obj.name + "\n\n &nbsp; \n\n"
            error_msg = title + msg + "\n\n &nbsp; \n\n > 共%d条记录" % len(error_msg)
    except Exception as e:
        print(e)
        error_msg = "#### 钉钉消息模板渲染出错，请检查：%s\n\n #### 错误详情：%s" % (tactic_obj.name, e)
    DING_TEMPLATE["markdown"]["title"] = tactic_obj.name
    DING_TEMPLATE["markdown"]["text"] = error_msg if error_msg.startswith("#") or error_msg.startswith(
        "*") else "#### " + error_msg
    if "@all " in error_msg:
        DING_TEMPLATE["at"]["isAtAll"] = True
    send_msg(DING_TEMPLATE, tactic_obj.ding_robot)


def send_msg(template, robot):
    try:
        header = {"Content-Type": "application/json; charset=utf-8"}
        msg = json.dumps(template, ensure_ascii=False)
        response = requests.post(robot, data=msg.encode("utf-8"), headers=header)
        return json.loads(response.text)
    except Exception as e:
        logger = logger_obj.get_logger()
        logger.info(e)
        raise ValueError(e)


def shorten_url(link):
    SHORT_URL = "https://api.weibo.com/2/short_url/shorten.json"
    SHORT_URL_SOURCE = "202088835"
    params = {"url_long": link, "source": SHORT_URL_SOURCE}
    res = requests.get(SHORT_URL, params=params)
    res_dict = res.json()
    if res_dict.get("urls"):
        short_urls = []
        for url in res_dict.get("urls"):
            short_urls.append({"url_short": url.get("url_short"), "url_long": url.get("url_long")})
        return short_urls
