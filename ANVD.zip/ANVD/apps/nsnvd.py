# -*- coding: utf-8 -*-
"""
    针对绿盟漏洞库的爬虫
    cve 列表网址：
    http://www.nsfocus.net/index.php?act=sec_bug
    cve 详情网址：
    http://www.nsfocus.net/vulndb/{nsfocus_id}
"""
import re
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from bs4 import BeautifulSoup as bs
from lib.constants import NS_DETAIL_URI, NS_LIST_URI, NS_QUERYSTRING
from apps import BaseSpider
from models import NSFocusCVEModel


class NsFocusSpider(BaseSpider):
    list_uri = NS_LIST_URI
    detail_uri = NS_DETAIL_URI
    list_params = NS_QUERYSTRING
    model_pk = "ns_id"
    model_class = NSFocusCVEModel
    page_kwarg = "page"
    load_history = True

    def parse_list(self, body):
        soup = bs(body, "lxml")
        vul_section = soup.find("ul", "vul_list")
        a_list = vul_section.find_all("a")
        id_list = [a["href"] for a in a_list]
        page_tag = soup.find("div", "page")
        page = page_tag.find("span", "arial")
        total = self.fetch_page(page)
        return total, id_list

    def parse_detail(self, body):
        soup = bs(body, "lxml")
        try:
            content = soup.find("div", "vulbar")

            date_title = content.find_all("b")
            title = date_title[0].get_text(strip=True)
            title = re.sub("\s*\(.*\)$", "", title)
            title = re.sub("\s*（.*）$", "", title)
            date = date_title[1].next_sibling.string
            product_tag = content.find("blockquote")
            string = str(content)
            cve_id = re.search(
                "http://www\.cve.mitre\.org/cgi-bin/cvename\.cgi\?name=(CVE-\d+-\d+)", string)
            if cve_id:
                cve_id = cve_id.group(1)
            else:
                cve_id = re.search("CVE-\d+-\d+", string)
                if cve_id:
                    cve_id = cve_id.group()
            if product_tag:
                product = product_tag.get_text(strip=True).split("<")[0]
            else:
                product = ""
            a_list = content.find_all("a")
            if a_list:
                summary_cn = self.parse_summary(a_list)
            else:
                summary_cn = self.parse_summary_plan_b(content)
            solution_cn, ref = self.parse_solution(content)
            value_dict = {
                "cve_id": cve_id, "release_time": date, "product": product,
                "summary_cn": summary_cn, "references": ref,
                "solution_cn": solution_cn, "title_cn": title
            }
            return value_dict
        except Exception as e:
            print(e)

    @staticmethod
    def parse_summary(a_list):
        summary_cn = ""
        cve_link = a_list.pop(0)
        tag_list = [i.string.strip() for i in cve_link.next_siblings if i.string]
        for i in tag_list:
            if i.startswith("CVE"):
                continue
            if "<*" in i or "建议" in i or "参考" in i:
                break
            summary_cn += i
        return summary_cn

    @staticmethod
    def parse_summary_plan_b(content):
        head_tags = content.find_all("b")
        tag = None
        summary_cn = ""
        for b in head_tags:
            if b.get_text(strip=True).startswith("描述："):
                tag = b
                break
        if tag is None:
            return ""
        tag_list = [i.string.strip() for i in tag.next_siblings if i.string]
        for i in tag_list:
            if i.startswith("CVE"):
                continue
            if "<*" in i or "建议" in i or "参考" in i:
                break
            summary_cn += i
        return summary_cn

    @staticmethod
    def parse_solution(content):
        b_list = content.find_all("b")
        solution_head = None
        for b_tag in b_list:
            if b_tag.get_text(strip=True) != "建议：":
                continue
            solution_head = b_tag
        if solution_head is None:
            return "", ""
        solution_list = [i.string.strip() for i in solution_head.next_siblings if i.string]
        start = False
        is_ref = False
        solution = ""
        refs = ""
        for sol in solution_list:
            if not sol:
                continue
            if sol.strip() == "浏览次数：":
                break
            if sol.strip() == "参考：":
                start = False
                is_ref = True
            if start:
                solution += sol
            if is_ref:
                refs += sol if not refs else "," + sol

            if not start and sol.strip().startswith("--"):
                start = True
                continue
        return solution, refs

    @staticmethod
    def fetch_page(page):
        text = page.get_text(strip=True)
        current, total = text.split("/")
        return total


if __name__ == '__main__':
    # _ = "/vulndb/45108"
    ns_obj = NsFocusSpider()
    print(ns_obj.job())