# -*- coding: utf-8 -*-
"""

"""
import time, os, sys
from urllib.parse import quote_plus, urljoin

import re

from models import Model

import requests

from logger import logger

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class BaseSpider:
    list_uri = None
    detail_uri = None
    model_class = None
    model_pk = "cve_id"
    list_params = {}
    detail_params = {}
    page_kwarg = "p"
    per_page = 100
    end_page = 3
    order_kwarg = "sort"
    load_history = False

    def _format_url(self, id_):
        if not isinstance(self.detail_uri, str):
            raise NotImplementedError(
                "class property base_uri class should be overwritten.")
        if "/" not in id_:
            url = self.detail_uri.format(id=id_)
        else:
            url = urljoin(self.detail_uri, id_)
        return url

    @staticmethod
    def get(url, **params):
        header = params.pop("headers", None)
        # params = {k: quote_plus(v) for k, v in params.items()}
        response = requests.get(url, params=params, headers=header)
        response.encoding = "utf-8"
        if not response.status_code == 200:
            logger.error("%s returns code %d" % (url, response.status_code))
            return
        return response.text

    def get_list(self, page):
        self.__reset_params(page)
        body = self.get(self.list_uri, **self.list_params)
        return self.parse_list(body)

    def get_detail(self, id_):
        url = self._format_url(id_)
        body = self.get(url, **self.detail_params)
        return self.parse_detail(body)

    @classmethod
    def paginate(cls, num):
        return num // cls.per_page + 1 if num % cls.per_page else 0

    def parse_list(self, body):
        raise NotImplementedError("parse_list method should be overwritten")

    def parse_detail(self, body):
        raise NotImplementedError("parse_detail method should be overwritten")

    @classmethod
    def __reset_params(cls, p):
        if "start" in cls.list_params:
            print("start")
            cls.list_params["start"] = str((p-1) * cls.per_page)
        cls.list_params[cls.page_kwarg] = str(p)
        print(cls.list_params)

    def insert(self, data):
        if self.model_class is None or not issubclass(self.model_class, Model):
            raise NotImplementedError("model_class property should be overwritten")
        if not hasattr(self.model_class, self.model_pk):
            raise KeyError(f"{self.model_class.__name__} does not have attribute {self.model_pk}")
        if not self.model_class.select().where(getattr(self.model_class, self.model_pk) == data.get("cve_id")).count():
            self.model_class.insert(**data).on_conflict_replace().execute()
            logger.info(f"Insert {data.get('cve_id')} into database")
        else:
            logger.warning(f"{data.get('cve_id')} is existed, ignore")

    def job(self):
        pages, id_list = self.get_list(1)
        if self.load_history:
            end = int(pages) + 1
        else:
            end = self.end_page + 1
        for page in range(1493, end):
            print(page, len(id_list))
            _, id_list = self.get_list(page)
            for id_ in id_list:
                data = self.get_detail(id_)
                if "cve_id" in data:
                    id_regx = re.search("\d+", id_)
                    id_ = int(id_regx.group())
                data.setdefault(self.model_pk, id_)
                try:
                    self.insert(data)
                except Exception as e:
                    logger.error(f"{data.get(self.model_pk)} got an exception: {str(e)}")
            logger.info(f"page {str(page)} has been inserted")
            # time.sleep(3)


