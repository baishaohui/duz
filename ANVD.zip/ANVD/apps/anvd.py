# -*- coding: utf-8 -*-
"""
    ANVD 的功能主要用于聚合数据，从go-cve-dictionary、redhat、nsfocus获取的数据中，
    查询相应字段值，并通过VulnerabilityModel存入vul_new_pre表中。
"""
from models.anvd import (
    VulnerabilityModel, NvdCpeModel, NvdCvss3Model, NvdCweModel,
    NvdDescriptionModel, NvdJsonModel, NvdReferenceModel)


class ANVD(object):
    rh_included_fields = []
    ns_included_fields = []

    def __init__(self):
        pass

    def get_data_from_rh_db(self):
        pass

    def get_data_from_ns_db(self):
        pass

    @staticmethod
    def select_from_model(model_cls, *fields, **options):
        where_is = [getattr(model_cls, option) for option in options]
        model_cls.select()
