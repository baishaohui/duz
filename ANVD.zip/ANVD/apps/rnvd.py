# -*- coding: utf-8 -*-
"""
    针对红帽漏洞库的爬虫。
    cve 列表网址：
    https://access.redhat.com/security/security-updates/#/cve?q=&p=1&sort=cve_publicDate%20desc&rows=100&documentKind=Cve
    cve 详情网址：
    https://access.redhat.com/security/cve/{cve_id.lower()}
"""
import json
from urllib.parse import quote_plus

import datetime
import requests

from apps import BaseSpider
from models import RedHatCVEModel
from lib.constants import RH_QUERYSTRING, RH_LIST_URI, RH_DETAIL_URI


class RedHatSpider(BaseSpider):
    list_uri = RH_LIST_URI
    detail_uri = RH_DETAIL_URI
    list_params = RH_QUERYSTRING.copy()
    model_class = RedHatCVEModel
    load_history = True

    def parse_detail(self, body):
        """
        解析详情页内容
        :param body: 详情页HTML
        :return: dict
        """
        body = json.loads(body)
        title = self.detail_value(body, "field_cve_bugzilla_text")
        detail = self.detail_value(body, "field_cve_details_text")
        references = self.detail_value(body, "field_cve_references_text")
        severity = self.detail_value(body, "field_cve_threat_severity_text") or ""
        cwe = self.detail_value(body, "field_cve_cwe_text")
        cvss3_vector = self.detail_value(body, "field_cve_cvss3_base_metrics")
        cvss3_score = self.detail_value(body, "field_cve_cvss3_base_score")
        pub_date = self.detail_value(body, "field_cve_public_date")
        return dict(
            title_en=title, summary_en=detail, release_time=self.utc_to_local(pub_date),
            references=references, cvss3_score=cvss3_score, cvss3_vector=cvss3_vector,
            cwe=cwe, vul_level=severity.lower()
        )

    def parse_list(self, body):
        body = json.loads(body)
        list_info = body.get("response")
        total = list_info.get("numFound")
        pages = self.paginate(total)
        cve_list = [cve.get("allTitle", "").lower() for cve in list_info.get("docs")]
        return pages, cve_list

    @staticmethod
    def detail_value(detail, key):
        field_dict = detail.get(key, None)
        if field_dict:
            value_list = field_dict.get("und", [])
            return "\n".join([value.get("value") for value in value_list])

    @staticmethod
    def utc_to_local(time_str):
        time_obj = datetime.datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S")
        time_obj += datetime.timedelta(hours=8)
        return time_obj


if __name__ == '__main__':
    rh_obj = RedHatSpider()
    print(rh_obj.job())