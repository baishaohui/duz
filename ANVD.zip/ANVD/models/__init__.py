# -*- coding: utf-8 -*-
from peewee import *

from config import RDS_CONFIG


def init_db():
    config = RDS_CONFIG.copy()
    db = config.pop("db")
    db_connection = MySQLDatabase(db, **config)
    return db_connection


connection = init_db()


class BaseModel(Model):

    class Meta:
        database = connection


from .anvd import *
from .extra import *
