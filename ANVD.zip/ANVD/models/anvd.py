# -*- coding: utf-8 -*-
import datetime
from peewee import *

from . import connection


class VulnerabilityModel(Model):
    avd_id = CharField(unique=True, index=True, verbose_name="aliyun id")
    cve_id = CharField(unique=True, index=True, verbose_name="cve id")
    gmt_create = DateTimeField(default=datetime.datetime.now, verbose_name="创建时间")
    gmt_modified = DateTimeField(default=datetime.datetime.now, verbose_name="更新时间")
    cwe_id = CharField(null=True, verbose_name="cwe id")
    release_time = DateTimeField(null=True, verbose_name="发布时间")
    cvss3_score = FloatField(null=True, verbose_name="cvss3 分数")
    cvss3_vector = CharField(null=True, verbose_name="cvss3 矢量")
    product_type = CharField(null=True, choices=(
        ("OS", "OS"), ("Application", "Application"), ("Hardware", "Hardware")
    ), verbose_name="产品类型")
    vendor = CharField(null=True, verbose_name="厂商")
    product = CharField(null=True, verbose_name="产品")
    cpe = CharField(null=True)
    authentication = SmallIntegerField(null=True, choices=((0, 0), (1, 1)))
    gained_privilege = SmallIntegerField(null=True, choices=((0, 0), (1, 1)))
    title_en = CharField(max_length=512, null=True, verbose_name="英文标题")
    title_cn = CharField(max_length=512, null=True, verbose_name="中文标题")
    summary_en = TextField(null=True, verbose_name="英文描述")
    summary_cn = TextField(null=True, verbose_name="中文描述")
    vul_level = CharField(null=True, choices=(
        ("low", "low"), ("medium", "medium"), ("high", "high"),
        ("serious", "serious")), verbose_name="漏洞等级")
    poc = TextField(null=True)
    poc_disclosure_time = DateTimeField(null=True, verbose_name="poc公开日期")
    solution_en = TextField(null=True, verbose_name="英文修复方案")
    solution_cn = TextField(null=True, verbose_name="中文修复方案")
    reference = TextField(null=True, verbose_name="参考链接")
    rule_status = SmallIntegerField(default=1, choices=((1, 1), (2, 2), (3, 3)))
    classify = CharField(max_length=512, null=True, verbose_name="漏洞类型分类")
    is_translated = BooleanField(default=False, verbose_name="人工审核")

    class Meta:
        database = connection
        table_name = "vul_new_pre"

    def __str__(self):
        return self.cve_id


class NvdJsonModel(Model):
    cve_id = CharField()

    class Meta:
        database = connection
        table_name = "nvd_jsons"

    def __str__(self):
        return self.cve_id


class NvdDescriptionModel(Model):
    nvd_json_id = IntegerField()
    value = TextField()

    class Meta:
        database = connection
        table_name = "descriptions"

    def __str__(self):
        return self.nvd_json_id


class NvdCweModel(Model):
    nvd_json_id = IntegerField()
    cwe_id = CharField()

    class Meta:
        database = connection
        table_name = "cwes"

    def __str__(self):
        return self.nvd_json_id


class NvdCvss3Model(Model):
    nvd_json_id = IntegerField()
    vector_string = CharField(null=True)
    attack_vector = CharField(null=True)
    attack_complexity = CharField(null=True)
    privileges_required = CharField(null=True)
    user_interaction = CharField(null=True)
    confidentiality_impact = CharField(null=True)
    integrity_impact = CharField(null=True)
    availability_impact = CharField(null=True)
    base_score = FloatField(null=True)
    base_severity = CharField()

    class Meta:
        database = connection
        table_name = "cvss3"

    def __str__(self):
        return self.nvd_json_id


class NvdReferenceModel(Model):
    nvd_json_id = IntegerField()
    link = CharField(max_length=512)

    class Meta:
        database = connection
        table_name = "references"

    def __str__(self):
        return self.nvd_json_id


class NvdCpeModel(Model):
    nvd_json_id = IntegerField()
    formatted_string = CharField()
    part = CharField()
    vendor = CharField()
    product = CharField()
    version_start_excluding = CharField()
    version_start_including = CharField()
    version_end_excluding = CharField()
    version_end_including = CharField()

    class Meta:
        database = connection
        table_name = "cpes"

    def __str__(self):
        return self.nvd_json_id