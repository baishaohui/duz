# -*- coding: utf-8 -*-
import datetime

from peewee import *

from . import connection
from lib.constants import LEVEL_CHOICES


class RedHatCVEModel(Model):
    cve_id = CharField(max_length=56, index=True, unique=True)
    release_time = DateField(null=True)
    gmt_created = DateTimeField(default=datetime.datetime.now)
    gmt_modified = DateTimeField(default=datetime.datetime.now)
    cwe = CharField(null=True)
    title_en = CharField(max_length=1024, null=True)
    summary_en = TextField(null=True)
    vul_level = CharField(choices=LEVEL_CHOICES, null=True)
    cvss3_score = FloatField(null=True)
    cvss3_vector = CharField(null=True)
    # view_uri = CharField()    # 废弃，现在用api采集
    references = TextField(null=True)

    class Meta:
        database = connection
        table_name = "vul_rh_cve"


class NSFocusCVEModel(Model):
    ns_id = IntegerField(unique=True, index=True)
    cve_id = CharField(max_length=56, null=True)
    release_time = DateField(null=True)
    gmt_created = DateTimeField(default=datetime.datetime.now)
    gmt_modified = DateTimeField(default=datetime.datetime.now)
    title_cn = CharField(max_length=512)
    summary_cn = TextField(null=True)
    references = TextField(null=True)
    solution_cn = TextField(null=True)
    product = CharField(null=True, default=None)
    view_uri = CharField()

    class Meta:
        database = connection
        table_name = "vul_ns_cve"