# -*- coding: utf-8 -*-

ACCESS_KEY_ID = "LTAI3EI5rmg8Kyvn"
ACCESS_KEY_SECRET = "Ql5US6HGeSjiGoRiXWDhtLKgcqtLnY"
NLP_REGION = 'cn-shanghai'
NLP_DOMAIN = "nlp.cn-shanghai.aliyuncs.com"
NLP_API_PATH = "/nlp/api/translate/general"

CLASSIFY_MAP = {
    'impact:elevation_of_privilege': {'cn': '权限提升', 'en': 'Privilege Escalation'},
    'impact:remote_code_execution': {'cn': '代码执行', 'en': 'Code Execution'},
    'impact:remote_denial_of_service': {'cn': '拒绝服务', 'en': 'Denial of Service'},
    'impact:information_disclosure': {'cn': '信息泄露', 'en': 'Information Disclosure'},
    'impact:security_feature_bypass': {'cn': '安全绕过', 'en': 'Security Bypass'},
    'impact:spoofing': {'cn': '欺骗', 'en': 'Spoofing'}, 'impact:tampering': {'cn': '篡改', 'en': 'Tampering'},
    'impact:xss': {'cn': '跨站脚本', 'en': 'Cross-Site Scripting (XSS)'},
    'impact:csrf': {'cn': '跨站请求伪造', 'en': 'Cross-Site Request Forgery (CSRF)'},
    'via:remote': {'cn': '远程', 'en': 'Remote'},
    'via:limited_remote': {'cn': '有限远程', 'en': 'Limited Remote'},
    'via:local': {'cn': '本地', 'en': 'Local'}, 'via:physical': {'cn': '物理', 'en': 'Physical'},
    'impact:unspecified': {'cn': '未指明', 'en': 'Unspecified'},
    'impact:sql_injection': {'cn': 'SQL注入', 'en': 'SQL Injection'},
    'impact:arbitrary_file_read': {'cn': '任意文件读取', 'en': 'Arbitrary File Read'},
    'impact:arbitrary_file_overwrite': {'cn': '任意文件写入', 'en': 'Arbitrary File Overwrite'},
    'impact:xxe': {'cn': 'XML实体注入', 'en': 'XML External Entity Injection'},
    'impact:session_fixation': {'cn': '会话固定', 'en': 'Session Fixation'},
    'impact:ssrf': {'cn': '服务端请求伪造', 'en': 'Server-Side Request Forgery'},
    'impact:directory_traversal': {'cn': '目录遍历', 'en': 'Directory Traversal'},
    'flaw:buffer_overflow': {'cn': '缓冲区溢出', 'en': 'Buffer Overflow'},
    'flaw:memory_corruption': {'cn': '内存破坏', 'en': 'Memory Corruption'},
    'flaw:out_of_bounds_access': {'cn': '越界访问', 'en': 'Out of Bounds Access'},
    'flaw:use_after_free': {'cn': '释放后重用', 'en': 'UAF'},
    'flaw:weak_configuration': {'cn': '弱配置', 'en': 'Weak Configuration'},
    'flaw:crypto': {'cn': '加密', 'en': 'Crypto'},
    'flaw:side_channel': {'cn': '边信道', 'en': 'Side Channel'}
}

VUL_DB = {
    "host": "rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com",
    "port": 5656,
    "user": "shaohui",
    "password": "gha96gzTK&jm#",
    "db": "vul_db",
    "charset": "utf8"
}

CVE_PATH = "./cve.sqlite3"