# -*- coding: utf-8 -*-

COMMON_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36")

RH_HEADERS = {
    'accept': "application/vnd.redhat.solr+json",
    'accept-encoding': "gzip, deflate, br",
    'accept-language': "zh-CN,zh;q=0.9",
    'connection': "keep-alive",
    'host': "api.access.redhat.com",
    'origin': "https://access.redhat.com",
    'referer': "https://access.redhat.com/security/security-updates/",
    'sec-fetch-mode': "cors",
    'sec-fetch-site': "same-site",
    'user-agent': COMMON_UA,
    # 'x-omit': "WWW-Authenticate",
    'cache-control': "no-cache",
}

RH_LIST_URI = "https://api.access.redhat.com/rs/search"
NS_LIST_URI = "http://www.nsfocus.net/index.php"

RH_DETAIL_URI = "https://access.redhat.com/api/redhat_node/{id}.json"
NS_DETAIL_URI = "http://www.nsfocus.net/vulndb/{id}"

# RH_REFER_URI = "https://access.redhat.com/security/cve/{id}"

RH_QUERYSTRING = {
    "facet": "true",
    "facet.field": "cve_threatSeverity",
    "facet.mincount": "1",
    "facet.range": "{!ex=ate}cve_publicDate",
    "facet.range.end": "NOW",
    "facet.range.gap": "+1YEAR",
    "facet.range.start": "NOW/YEAR-15YEARS",
    "fl": "id,cve_threatSeverity,cve_publicDate,view_uri,allTitle,cve_details",
    # "fq": "documentKind:(\"Cve\")",
    "fq": "{!tag=ate}cve_publicDate:([2015-01-01T00:00:00.000Z TO 2015-01-01T00:00:00.000Z+1YEAR]) AND documentKind:(\"Cve\")",
    "hl": "true",
    "hl.fl": "abstract",
    "hl.simple.post": "</mark>",
    "hl.simple.pre": "<mark>",
    "p": "1",
    "q": "*:*",
    "rows": "100",
    "sort": "cve_publicDate desc",
    "start": "0",
    "headers": RH_HEADERS
}

NS_QUERYSTRING = {
    "act": "sec_bug",
    "type_id": "",
    "os": "",
    "keyword": "",
    "page": 1
}

LEVELS = {
    "low": "low",
    "moderate": "medium",
    "important": "high",
    "critical": "serious"
}
LEVEL_CHOICES = [level for level in LEVELS]