# -*- coding: utf-8 -*-
import os
import logging
import logging.handlers

BASEDIR = os.path.abspath(os.path.dirname(__file__))


class Logger:
    def __init__(self, name="root"):
        self._logger = logging.getLogger(name)
        formatter = logging.Formatter(
            '[%(asctime)s] [%(levelname)s] - %(filename)s(line:%(lineno)d) - %(message)s',
            '%Y-%m-%d %H:%M:%S')

        handler_info = logging.handlers.TimedRotatingFileHandler(
            os.path.join(BASEDIR, "logs", "info", "info.log"), when='D', interval=3)
        handler_warn = logging.handlers.TimedRotatingFileHandler(
            os.path.join(BASEDIR, "logs", "warn", "warn.log"), when='D', interval=3)
        handler_error = logging.handlers.TimedRotatingFileHandler(
            os.path.join(BASEDIR, "logs", "error", "error.log"), when='D', interval=3)

        handler_info.setFormatter(formatter)
        handler_warn.setFormatter(formatter)
        handler_error.setFormatter(formatter)

        # 当handler的log level高于logger本身的log level时，此设置才会生效
        handler_info.setLevel(logging.INFO)
        handler_warn.setLevel(logging.WARN)
        handler_error.setLevel(logging.ERROR)

        self._logger.addHandler(handler_info)
        self._logger.addHandler(handler_warn)
        self._logger.addHandler(handler_error)

        # 默认情况下，logger本身的log level是warn，为了让info handler的level等级生效，所以调低logger本身的level
        self._logger.setLevel(logging.INFO)

    def getLogger(self):
        return self._logger


logger = Logger().getLogger()
