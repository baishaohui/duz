# -*- coding: utf-8 -*-
import os
import sys
import subprocess

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def file_to_md5(path, file):
    result = subprocess.Popen("md5 %s" % os.path.join(path, file), shell=True, stdout=subprocess.PIPE)
    if result.stderr:
        print("fail to hash file: %s" % file)
        return
    with open(os.path.join(path, file), "rb") as f:
        _, md5 = result.stdout.read().decode("utf8").split(" = ", 1)
        with open(os.path.join(path, f"{file}.md5"), "w") as wf:
            wf.write(md5)


def main():
    try:
        path = sys.argv[1]
    except IndexError:
        path = BASE_DIR
    for file in os.listdir(path):
        if file == __file__ or file.endswith(".md5"):
            continue
        file_to_md5(path, file)


if __name__ == '__main__':
    main()
