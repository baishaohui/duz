# -*- coding: utf-8 -*-
import re
import requests

from logger import logger
from models import KBModel


def reg_sp(product, document, sp_type=1):
    if sp_type == 1:
        sp_product = f'"{product.strip()} SP1"'
        sp_product_full = f'"{product.strip()} Service Pack 1"'
    elif sp_type == 2:
        sp_product = f'"{product.strip()} SP2"'
        sp_product_full = f'"{product.strip()} Service Pack 2"'
    else:
        sp_product = sp_product_full = f'"{product.strip()}"'
    sp = re.search(sp_product, document) or re.search(sp_product_full, document)
    return sp


def reg_product(title, html):
    """
    通过标题匹配出产品名，通过
    :param title:
    :param html:
    :return:
    """
    product = re.search("Windows Server (\d\d\d\d)( R2)?", title).group()
    sp1 = reg_sp(product, html, sp_type=1)
    sp2 = reg_sp(product, html, sp_type=2)
    sp = reg_sp(product, html, sp_type=0)
    return {"product": product, "sp1": sp1, "sp2": sp2, "sp":  sp}


def retrieve_products(data):
    reference = data.get("reference")
    title = data.get("title")
    response = requests.get(reference)
    regs = reg_product(title, response.text)
    return regs


if __name__ == '__main__':
    retrieve_products()
