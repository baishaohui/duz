# -*- coding: utf-8 -*-
import re

import requests
from peewee import *

from logger import logger

DB_CONFIG = {
    "host": "rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com",
    "port": 5656,
    "user": "shaohui",
    "password": "gha96gzTK&jm#",
    "db": "vul_db",
}
db = MySQLDatabase(DB_CONFIG.pop("db"), **DB_CONFIG)


class KBModel(Model):
    kb = CharField(verbose_name="KB")
    product = CharField(null=True, verbose_name="影响产品")
    title = CharField(null=True, verbose_name="KB 标题")
    release_time = DateField(null=True, verbose_name="时间")
    size = CharField(max_length=16, null=True, verbose_name="文件大小")
    description = TextField(null=True, verbose_name="描述")
    severity = CharField(null=True, verbose_name="微软等级")
    reference = CharField(null=True, verbose_name="参考链接")
    replaced_by = TextField(null=True, verbose_name="replaced by")
    replace = TextField(null=True, verbose_name="replace")
    architecture = CharField(choices=(("x86", "x86"), ("x64", "x64")))
    files = TextField(null=True, verbose_name="补丁链接")
    download_from = TextField(null=True)
    update_id = TextField(null=True, verbose_name="update id")
    monthly_rollup = BooleanField(default=False, verbose_name="月度KB")
    security_kb = CharField(verbose_name="安全KB")
    all_security_kb = TextField(verbose_name="子安全KB")
    is_top = BooleanField(default=False, verbose_name="顶级")

    def __str__(self):
        return self.title

    class Meta:
        database = db
        table_name = "vul_kb_bak"

    # @property
    # def is_top(self):
    #     return KBModel.select().where(KBModel.replace.contains(self.kb), KBModel.architecture == self.architecture,
    #                                   KBModel.product == self.product).count() == 0

    @classmethod
    def get_not(cls):
        return cls.select().where(~cls.title.iregexp("x64|x86"))

    def fetch_top(self):
        if KBModel.select().where(
                KBModel.replace.contains(self.kb), KBModel.architecture == self.architecture,
                KBModel.product == self.product).count() == 0:
            KBModel.update(is_top=True).where(KBModel.id == self.id).execute()

    @classmethod
    def fetch_product(cls):
        kbs = [
            "KB3138612",
            "KB3109560",
            "KB3108664",
            "KB3108371",
            "KB3101722",
            "KB3075220",
            "KB3060716",
            "KB3046269",
            "KB3042058",
            "KB3031432",
            "KB3030377",
            "KB3004375",
            "KB2984972",
            "KB2977292",
            "KB2928120",
            "KB2900986",
            "KB2884256",
            "KB2871997",
            "KB2868038",
            "KB2864202",
            "KB2862335",
            "KB2862330",
            "KB2813430",
            "KB2807986",
            "KB2786081",
            "KB2770660",
            "KB2765809",
            "KB2758857",
            "KB2705219",
            "KB2698365",
            "KB2690533",
            "KB2685939",
            "KB2667402",
            "KB2654428",
            "KB2653956",
            "KB2643719",
            "KB2621440",
            "KB2620704",
            "KB2585542",
            "KB2564958",
            "KB2560656",
            "KB2552343",
            "KB2506212",
            "KB2506014"
        ]
        for kb in kbs:
            products = [p.product for p in cls.select().where(cls.kb == kb)]
            if "Windows Server 2008 R2 SP1" in products and "Windows Server 2008 R2" in products:
                print("both")
                continue
            if "Windows Server 2008 R2" in products:
                print("sp:", kb)
                not_opsite_product = "Windows Server 2008 R2 SP1"
                opsite_product = "Windows Server 2008 R2"
            elif "Windows Server 2008 R2 SP1" in products:
                print(kb)
                not_opsite_product = "Windows Server 2008 R2"
                opsite_product = "Windows Server 2008 R2 SP1"
            obj = cls.select().where(cls.kb == kb, cls.product == opsite_product).first()
            print(obj.__data__)
            data = obj.__data__.copy()
            data.pop("id")
            data["product"] = not_opsite_product
            cls.insert(**data).execute()

    @classmethod
    def recent_month(cls):
        obj = cls.select().group_by(cls.release_time).order_by(cls.release_time.desc()).first()
        if obj and obj.release_time:
            return obj.release_time.month

    def fetch_all_sec(self, all_sec=None):
        if all_sec is None:
            all_sec = set()
        all_sec.add(self.security_kb)
        children = self.replace.split(",")
        sec = KBModel.select().where(
            KBModel.monthly_rollup == True,
            KBModel.kb.in_(children),
            KBModel.kb != self.security_kb,
            KBModel.release_time <= self.release_time)
        count = sec.count()
        if not count:
            security_kb = "|".join(all_sec)
            return security_kb
        for s in sec:
            all_sec.add(s.security_kb)
            return s.fetch_all_sec(all_sec)
        # self.fetch_all_sec(all_sec)
        # targets = KBModel.select().where(
        # KBModel.release_time <= self.release_time,
        # KBModel.monthly_rollup == True)
        # for t in targets:
        #     if t.security_kb in self.replace or t == self:
        #         all_sec.add(t.security_kb)
        # self.all_security_kb = "|".join(all_sec) or None
        # self.save()

    @property
    def top_status(self):
        return KBModel.select().where(
            KBModel.replace.contains(self.kb),
            KBModel.architecture == self.architecture,
            KBModel.product == self.product
        ).count() == 0

    @classmethod
    def fresh_top(cls):
        """全量更新kb顶级状态"""
        for kb in cls.select():
            if kb.is_top != kb.top_status:
                kb.is_top = kb.top_status
                kb.save()
        logger.info("KB top status updated.")

    @classmethod
    def fresh_sec(cls):
        """更新月度kb下的sec列表"""
        monthly = cls.select().order_by(
            cls.release_time.asc()).where(
            cls.monthly_rollup == True)
        for month in monthly:
            month.all_security_kb = month.fetch_all_sec()
            month.save()
        logger.info("Monthly kb updated.")


def create(*args):
    """
    创建数据库表
    :param args: Model对象组成的列表
    :return:
    """
    db.create_tables(args)


def update():
    kb_list = KBModel.select().where(KBModel.product == None)
    for kb in kb_list:
        # product = re.search("Windows Server (\d\d\d\d)( R2)?", kb.title).group()
        product = kb.product
        detail = kb.reference
        print(detail)
        response = requests.get(detail)
        sp_product = product.strip() + " SP1"
        # sp_product_full = product.strip() + " Service Package 1"
        sp2_ = product.strip() + " SP2"
        # sp2_full = product.strip() + " Service Package 2"
        sp = re.search(sp_product, response.text)
        # sp_product_full = re.search(sp_product_full, response.text)
        sp2 = re.search(sp2_, response.text)
        # sp2_full = re.search(sp2_full, response.text)
        if sp and sp.group() in response.text and "SP1" not in product:
            KBModel.update(product=sp.group()).where(KBModel.id == kb.id).execute()
        elif sp2 and sp2.group() in response.text and "SP2" not in product:
            KBModel.update(product=sp2.group()).where(KBModel.id == kb.id).execute()
        # architecture = None
        # if "x86" in kb.title:
        #     architecture = "x86"
        # elif "x64" in kb.title:
        #     architecture = "x64"
        # else:
        #     if "2012" in product or "2019" in product or "2016" in product:
        #         architecture = "x64"
        #     elif "2003" in product or "2008" in product:
        #         architecture = "x86"


if __name__ == '__main__':
    # update()
    # insert_2003()
    # l = [i.download_from for i in KBModel.select() if i.is_top]
    # with open("download.json", "w") as f:
    #     f.write(json.dumps(l))
    # print(l)
    # print(len(l))

    # print(KBModel.get_not())
    # print(",".join(list(KBModel.select("replace").where(KBModel.replace != None))))
    # print(KBModel.recent_month())
    # monthly = KBModel.select().order_by(KBModel.release_time.asc()).where(KBModel.monthly_rollup == True)
    # for month in monthly:
        # print(month.title)
        # print(month.fetch_all_sec())
        # month.all_security_kb = month.fetch_all_sec()
        # month.save()
    KBModel.fresh_top()