# -*- coding: utf-8 -*-
import json
import datetime

import os
import requests

from logger import logger

product_id_mapping = {
    "2012": [19, 27, 31, 12],
    "2016": [142, 143, 522, 353],
    "2019": [661, 663],
    "2008": [543, 189, 10, 21, 123, 190, 191, 14, 20, 109, 11, 193, 29]
}
from_history_published_date = "01/02/2016"
# from_published_date = "10/01/2016"
page_size = 100

payload = {"familyIds": [100000010], "productIds": [661, 663],
           "severityIds": [1, 2, 3, 4, 5],
           "impactIds": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], "pageNumber": 1, "pageSize": page_size,
           "includeCveNumber": True,
           "includeSeverity": True, "includeImpact": True, "orderBy": "publishedDate", "orderByMonthly": "releaseDate",
           "isDescending": True, "isDescendingMonthly": True, "queryText": None, "isSearch": False, "filterText": "",
           "fromPublishedDate": None, "toPublishedDate": None}
api = "https://portal.msrc.microsoft.com/api/security-guidance/en-us"
url = "https://portal.msrc.microsoft.com/en-us/security-guidance"

headers = {
    "Accept": "application/json, text/plain, */*",
    "Origin": "https://portal.msrc.microsoft.com",
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36",
    "Content-Type": "application/json;charset=UTF-8",
    "Referer": "https://portal.msrc.microsoft.com/en-us/security-guidance",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "zh-CN,zh;q=0.9"
}


def paginate(count):
    return count // page_size + (1 if count % page_size else 0)


def fetch_cookie():
    response = requests.get(url)
    cookies = response.cookies
    return cookies


def strip_json(json_):
    details = json_.get("details", [])
    url_list = []
    current_month = datetime.date.today().month
    for detail in details:
        pub_date = detail["publishedDate"]
        target_month = datetime.datetime.strptime(pub_date, "%Y-%m-%dT%H:%M:%S").month
        # if target_month < current_month:  # KB发布月小于当前月，不做记录
        #     break
        if detail.get("downloadUrl3") is not None:
            # 带url3的为security update
            url_list.append(detail.get("downloadUrl1"))
            url_list.append(detail.get("downloadUrl2"))
            url_list.append(detail.get("downloadUrl3"))
        elif detail.get("downloadUrl1") and detail.get("downloadUrl2"):
            url_list.append((detail.get("downloadUrl1"), detail.get("downloadUrl2")))
        elif detail.get("downloadUrl1") and not detail.get("downloadUrl2"):
            url_list.append(detail.get("downloadUrl1"))
        elif not detail.get("downloadUrl1") and detail.get("downloadUrl2"):
            url_list.append(detail.get("downloadUrl2"))
    return url_list


def write_to_file(filename, data):
    with open(filename, "w") as f:
        f.write(json.dumps(data))


def fetch_data(product_id, cookies):
    urls_to_store = []
    count, urls = make_post(product_id, cookies, 1)
    urls_to_store.extend(urls)
    pages = paginate(count)
    logger.info("Total %d pages" % pages)
    if pages:
        for page in range(2, pages + 1):
            logger.info("Crawling page %d" % page)
            payload["pageNumber"] = page
            _, kb_json = make_post(product_id, cookies, page)
            if _ == 0:  # 等于0时，说明剩下的数据为历史数据，不再处理
                break
            urls_to_store.extend(kb_json)
    return urls_to_store


def fetch_api(history=False):
    cookies = fetch_cookie()
    to_published_date = datetime.datetime.now().strftime("%m/%d/%Y")
    payload["toPublishedDate"] = to_published_date
    if history:
        payload["fromPublishedDate"] = from_history_published_date
    else:
        payload["fromPublishedDate"] = datetime.datetime.now().replace(day=1).strftime("%m/%d/%Y")
    for year, product_id in product_id_mapping.items():
        logger.info("Start crawling %s" % year)
        urls_to_store = fetch_data(product_id, cookies)
        logger.info("%s got %d items" % (year, len(urls_to_store)))
        write_to_file(os.path.join("urls", "{}_kb_urls.json".format(year)), urls_to_store)
        logger.info("%s has been stored" % year)


def make_post(product_id, cookies, page_num):
    payload["productIds"] = product_id
    payload["pageNumber"] = page_num
    res = requests.post(api, json=payload, cookies=cookies, headers=headers)
    ext = res.json()
    urls = strip_json(ext)
    if not urls:
        return 0, urls
    return ext.get("count"), urls


if __name__ == '__main__':
    fetch_api()
