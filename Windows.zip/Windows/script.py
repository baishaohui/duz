# -*- coding: utf-8 -*-
import json
import requests
from xml.etree import ElementTree

# with open("window_2008_all_kbs.json", "r") as f:
#     data = json.loads(f.read())
#     print(len(data))
# urls = []
# for i in data:
#     url = i.get("downloadUrl2") or i.get("downloadUrl1")
#     urls.append(url)
#
# with open("2008_kb_urls.json", "w") as w:
#     w.write(json.dumps(urls))
# headers = {
#     "Accept-Language": "zh-CN,zh;q=0.9"
# }

# print(", ".join(["\"https://catalog.update.microsoft.com/v7/site/Search.aspx?q=%s\"" % kb for kb in extra_kbs]))
# for kb in extra_kbs:
# response = requests.get("https://catalog.update.microsoft.com/v7/site/Search.aspx?q=%s", headers=headers)
# print(response.status_code)
# print(response.text)
from models import KBModel

# kbs = KBModel.select().where(KBModel.files.contains("|"), KBModel.files.contains("chs"))
from urllib.parse import urlparse, parse_qs

# with open("month/2012.json", "r") as f:
#     kbs = json.load(f)
# kbs = KBModel.select().where(KBModel.monthly_rollup==True, KBModel.security_kb == None)
# print(len(kbs))
# for kb in kbs:
#     KBModel.update(monthly_rollup=False).where(KBModel.id==kb.id).execute()

# for kb in kbs:
#     month, security = kb
#     month = urlparse(month).query
#     security = urlparse(security).query
#     month_dict = parse_qs(month)
#     security_dict = parse_qs(security)
#     try:
#         month = month_dict["q"][0]
#         security = security_dict["q"][0]
#     except KeyError:
#         print(month)
#         continue
#     KBModel.update(security_kb=security).where(KBModel.kb == month, KBModel.monthly_rollup == True).execute()

url = "https://nvd.nist.gov/vuln/detail/{cve_id}"

sql = """
    SELECT cve_id
FROM vul_new_pre
WHERE vendor IS NOT NULL
	AND vendor <> ""
	AND product IS NOT NULL
	AND product <> ""
	AND product IS NOT NULL
	AND product <> ""
	AND gmt_create BETWEEN "2019-10-01" AND "2019-11-08"
ORDER BY gmt_create DESC
"""

import pymysql
DB_CONFIG = {
    "host": "rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com",
    "port": 5656,
    "user": "shaohui",
    "password": "gha96gzTK&jm#",
    "db": "vul_db",
}

conn = pymysql.connect(**DB_CONFIG)
cursor = conn.cursor(pymysql.cursors.SSDictCursor)
cursor.execute(sql)
data = cursor.fetchall()
print(len(data))

for d in data:
    u = url.format(cve_id=d.get("cve_id"))
    res = requests.get(u)
    if res.status_code != 200:
        print(u)
    print(res.text)
    tree = ElementTree.parse(res.text)
    cvss = tree.xpath("//[@class='tooltipCvss3NistMetrics']//text()")
    print(cvss)
