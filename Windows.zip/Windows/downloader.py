# -*- coding: utf-8 -*-
import re
import os
import json
import time

import datetime
import requests
from lxml import etree

from common import execute_util_success
from models import KBModel
from product import retrieve_products
from logger import logger

system_name = ["Windows Server 2003", "Server 2003", "Windows Server 2008",
               "Server 2008", "Windows Server 2012", "Server 2012",
               "Windows Server 2016", "Server 2016", "Windows Server 2019", "Server 2019"]
allowed_domain = ("https://catalog.update.microsoft.com", "https://www.catalog.update.microsoft.com")
excluded_keyword = ["Itanium", "Microsoft .NET Framework"]
include_languages = ["English"]
detail_uri = "https://www.catalog.update.microsoft.com/ScopedViewInline.aspx?updateid=%s"
download_uri = "https://www.catalog.update.microsoft.com/DownloadDialog.aspx"
title_xpath = "//*[@id='ctl00_catalogBody_updateMatches']//tr/td[2]"
file_lang_pattern = re.compile("\.longLanguages = '(.*)';")
filename_pattern = re.compile("\.fileName = '(.*)';")
file_download_pattern = re.compile("\.url = '(.*)';")
id_xpath = "//*[@id='ctl00_catalogBody_updateMatches']//tr/td[2]/a/href"
kb_xpath = "//*[@id='ctl00_catalogBody_searchString']/text()"
detail_title_xpath = "//*[@id='ScopedViewHandler_titleText']/text()"
detail_date_xpath = "//*[@id='ScopedViewHandler_date']/text()"
detail_size_xpath = "//*[@id='ScopedViewHandler_size']/text()"
detail_arch_xpath = "//*[@id='archDiv']/text()"
detail_description_xpath = "//*[@id='ScopedViewHandler_desc']/text()"
detail_severity_xpath = "//*[@id='ScopedViewHandler_msrcSeverity']/text()"
detail_support_xpath = "//*[@id='moreInfoDiv']//a/@href"
replaced_by_xpath = "//*[@id='supersededbyInfo']//a/text()"
replace_xpath = "//*[@id='supersedesInfo']/div/text()"
kb_pattern = re.compile("\(?（?(KB\d+)\)?）?")
update_id = '[{"size": 0,"languages": "zh-cn","uidInfo": "%s","updateID": "%s"}]'
headers = {
    "Accept-Language": "zh-CN,zh;q=0.9"
}
post_headers = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Cache-Control": "max-age=0",
    "Connection": "keep-alive",
    "Content-Type": "application/x-www-form-urlencoded",
    "Host": "www.catalog.update.microsoft.com",
    "Origin": "https://www.catalog.update.microsoft.com",
    "Referer": "https://www.catalog.update.microsoft.com/DownloadDialog.aspx",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36"
}


def download(url):
    logger.info("Downloading from %s" % url)
    response = requests.get(url)
    html = response.text
    return relative(html)


def get_lang_index(langs):
    indexes = []
    for index, lang in enumerate(langs):
        if lang in include_languages:
            indexes.append(index)
    return indexes


def search_from_architecture(arch):
    if "64" in arch:
        architecture = "x64"
        return architecture
    if "86" in arch:
        architecture = "x86"
        return architecture


def find_replaced(replaces):
    replace_list = []
    for replace in replaces:
        if "n/a" in replace:
            break
        else:
            k = kb_pattern.search(replace)
            if k:
                replace_list.append(k.group(1))
    return replace_list


def find_replace_by(replaced_by):
    replaced_by_list = []
    for by in replaced_by:
        if "n/a" in by:
            break
        else:
            k = kb_pattern.search(by)
            if k:
                replaced_by_list.append(k.group(1))
    return replaced_by_list


def retrieve_detail(html):
    selector = etree.HTML(html)
    description = selector.xpath(detail_description_xpath)
    title = selector.xpath(detail_title_xpath)[0]
    date = selector.xpath(detail_date_xpath)[0]
    size = selector.xpath(detail_size_xpath)[0]
    severity = selector.xpath(detail_severity_xpath)[0]
    support = selector.xpath(detail_support_xpath)[0]
    architecture = "".join(selector.xpath(detail_arch_xpath))
    replaces = selector.xpath(replace_xpath)
    replaced_by = selector.xpath(replaced_by_xpath)
    replace_list = find_replaced(replaces)
    replaced_by_list = find_replace_by(replaced_by)
    architecture = search_from_architecture(architecture) or architecture

    result = {"title": title, "description": ",".join(description),
              "release_time": datetime.datetime.strptime(date, "%Y/%m/%d"), "size": size, "severity": severity,
              "reference": support.replace(",", "|"), "replace": ",".join(replace_list),
              "replaced_by": ",".join(replaced_by_list), "architecture": architecture
              }
    return result


def retrieve_file(html):
    lang_list = file_lang_pattern.findall(html)
    file_list = filename_pattern.findall(html)
    link_list = file_download_pattern.findall(html)
    if (lang_list and lang_list[0] == "all") or not lang_list:
        file_name = ",".join([file for file in file_list])
        download_links = ",".join([link for link in link_list])
    else:
        indexes = get_lang_index(lang_list)
        file_name = ",".join([file for index, file in enumerate(file_list) if index in indexes])
        download_links = ",".join([link for index, link in enumerate(link_list) if index in indexes])
    return {"files": file_name, "download_from": download_links}


def get_detail(id_):
    detail_url = detail_uri % id_
    try:
        detail_response = requests.get(
            detail_url, headers=headers)
        return detail_response
    except Exception as e:
        logger.error(f"{detail_url} error: {str(e)}")


def post_file_page(id_):
    payload = {
        "updateIDs": update_id % (id_, id_),
        "updateIDsBlockedForImport": "",
        "wsusApiPresent": "",
        "contentImport": "",
        "sku": "",
        "serverName": "",
        "ssl": "",
        "portNumber": "",
        "version": ""
    }
    file_response = requests.post(
        download_uri, data=payload, headers=post_headers)
    return file_response


def retrieve_detail_forever(id_):
    detail_response = get_detail(id_)  # 获取详情页

    detail = retrieve_detail(detail_response.text)
    # except Exception as e:
    #     logger.error(f"{id_} got error: {str(e)}")
    #     time.sleep(2)  # 停顿2秒再爬一次
    #     continue
        # detail_response = get_detail(id_)  # 获取详情页
        # detail = retrieve_detail(detail_response.text)
    # try:
    file_response = post_file_page(id_)
    return detail, file_response
    # except Exception as e:
    #     logger.error(f"{id_} got error: {str(e)}")
    #     continue


def relative(html):
    selector = etree.HTML(html)
    titles = selector.xpath(title_xpath)
    kb = selector.xpath(kb_xpath)
    kb = kb[0].strip('"')
    for index, title in enumerate(titles):
        if index == 0:
            continue
        d = title.getchildren()[0]
        text = d.text
        id_list = set()
        if text:
            if any([system in text for system in system_name]) and all(
                    [keyword not in text for keyword in excluded_keyword]):
                href = d.get("id")
                href, *_ = href.rsplit("_", 1)
                id_list.add(href)
        for id_ in id_list:
            responses = execute_util_success(retrieve_detail_forever, id_)
            if responses is None:
                continue
            detail, file_response = responses
            file = retrieve_file(file_response.text)
            detail.update(file)
            detail["update_id"] = id_
            detail["kb"] = kb
            if KBModel.select().where(
                    KBModel.kb == kb, KBModel.title == detail["title"]).count():
                detail.pop("kb")
                title = detail.pop("title")
                KBModel.update(**detail).where(
                    KBModel.kb == kb, KBModel.title == title).execute()
                continue
            products = retrieve_products(detail)
            product = products.pop("product")
            if not any(products.values()):
                detail["product"] = product
                KBModel.insert(**detail).on_conflict_ignore().execute()
                continue
            for key, value in products.items():
                if value is None:
                    continue
                if key == "sp":
                    detail["product"] = product
                elif key == "sp1":
                    detail["product"] = product + " SP1"
                elif key == "sp2":
                    detail["product"] = product + " SP2"
                KBModel.insert(**detail).on_conflict_ignore().execute()


def main():
    for file in os.listdir("urls"):
        with open(os.path.join("urls", file), "r") as f:
            urls = json.load(f)
        if not file.startswith(("2008", "2012")):
            urls = set(urls)
        logger.info("%s got %d urls" % (file, len(urls)))
        has_fetched = []
        for url in urls:
            sec = None
            monthly_rollup = False
            if isinstance(urls, (list, tuple)):
                try:
                    target, sec = url
                    monthly_rollup = True
                except ValueError:
                    target = url[0]
            else:
                target = url
            if not target or not target.startswith(
                    allowed_domain) or target in has_fetched:
                continue
            download(target)
            has_fetched.append(target)
            if sec is not None:
                download(sec)
                has_fetched.append(sec)
                update_kb = kb_pattern.search(target).group()
                security_kb = kb_pattern.search(sec).group()
                KBModel.update(
                    monthly_rollup=monthly_rollup,
                    security_kb=security_kb).where(
                    KBModel.kb == update_kb).execute()
    KBModel.fresh_top()
    KBModel.fresh_sec()


if __name__ == '__main__':
    main()


    # storage()
    # print(l)
    # print(len(d))
    # f = open("kb_id/2003_detail.json", "w")
    # f.write(json.dumps(d))
    # f.close()
