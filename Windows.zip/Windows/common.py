# -*- coding: utf-8 -*-
import time

import requests

from logger import logger

base_robot = "https://oapi.dingtalk.com/robot/send?access_token={token}"

product_token = ""

test_token = "4a88a0060e3c49a4e65197967530ab63419e26f2339544e98055c0cf70aab4fe"


def execute_util_success(func, *args, **kwargs):
    """
    Execute a callable object with or without arguments,
    util the callable is success executed.
    it will stop util retry 10 times.
    :param func: callable
    :param args: position arguments for func
    :param kwargs: keyword arguments for func
    :return: what the callable object returns
    """
    retry = 0
    while True:
        try:
            result = func(*args, **kwargs)
            if retry:
                logger.info(f"{args[0]} execute successfully")
            return result
        except Exception as e:
            retry += 1
            if retry == 10:
                logger.error(f"{args[0]} retried over 10 times, please check it manually")
                break
            time.sleep(2)


def ding_robot(robot, message, alert=False):
    """
    发送消息至robot，发送出错上报给test robot.
    :param robot: 机器人链接
    :param message: 发送的消息
    :param alert: 防止递归出错的flag
    :return:
    """
    template = {
        "msgtype": "text",
        "text": {
            "content": message
        },
        "at": {
            "atMobiles": [],
            "isAtAll": False
        }
    }
    robot_response = requests.post(robot, json=template).json()
    if alert:
        logger.error(f"Ding robot {robot} error happened: {robot_response.get('errmsg')}")
        return
    print(robot_response)
    if robot_response["errcode"] != 0:
        error_msg = f"钉钉机器人访问出错，回调结果：{robot_response.get('errmsg')}"
        ding_robot(
            base_robot.format(token=test_token),
            error_msg,
            alert=True
        )


def update_report(old, new):
    """
    新增月度、新增安全、新增顶级、减少顶级。。。
    :param old: 旧记录，包括月度kb、安全kb、顶级kb
    :param new: 新纪录，包括月度kb、安全kb、顶级kb
    :return:

    """
    new_top = new["top"] - old["top"]    # 新增顶级kb
    old_top = old["top"] - new["top"]    # 减少顶级kb
    monthly = new["monthly"] - old["monthly"]    # 新增月度kb
    sec = new["sec"] - old["sec"]    # 新增安全kb
    title = "------ 本月KB更新汇总 ------ \n\n"
    report_part1 = f"新增顶级KB: \n{'、'.join(new_top)}"
    report_part2 = f"减少顶级KB: \n{'、'.join(old_top)}"
    report_part3 = f"新增月度KB: \n{'、'.join(monthly)}"
    report_part4 = f"新增安全KB: \n{'、'.join(sec)}"
    message = title + report_part1 + "\n\n" +report_part2 + "\n\n" + report_part3 + "\n\n" + report_part4
    ding_robot(
        base_robot.format(token=test_token), message
    )


if __name__ == '__main__':
    ding_robot(base_robot.format(token=test_token), "test")