# -*- coding: utf-8 -*-
import datetime
from apscheduler.schedulers.blocking import BlockingScheduler

from api import fetch_api
from common import update_report
from downloader import main
from logger import logger
from models import KBModel

job_config = {
    "trigger": "cron",
    "month": "1-12",
    "day": "2nd wed",    # 每月第二个周三
    "hour": "8-14"       # 8点到14点每到整点执行一次
}

job_config_test = {
    "trigger": "interval",
    "hours": 1,
    # "next_run_time":  datetime.datetime.now()
    # "minutes": "1"
}


class Engine(object):
    scheduler_class = BlockingScheduler

    def __init__(self):
        self.schedule_config = job_config

    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, "instance"):
            cls.instance = super(Engine, cls).__new__(cls)
            return cls.instance

    def job(self):
        if KBModel.recent_month() != datetime.date.today().month:
            # 当最近记录月份不等于当前月份时，说明本月补丁信息还没记录
            logger.info(f"Job start at {datetime.datetime.now()}")
            old = self.fetch_all()
            try:
                fetch_api()
                main()
            except Exception as e:
                logger.error(str(e))
            finally:
                new = self.fetch_all()
                update_report(old, new)
        else:
            logger.info("KB has been updated, ignored")

    @staticmethod
    def fetch_top():
        """获取当前状态下的顶级KB"""
        return {kb.kb for kb in KBModel.select().where(KBModel.is_top == True)}

    @staticmethod
    def fetch_monthly():
        """获取所有月度KB"""
        return {kb.kb for kb in KBModel.select().where(KBModel.monthly_rollup == True)}

    @staticmethod
    def fetch_sec():
        """非月度KB，即为安全KB"""
        return {kb.kb for kb in KBModel.select().where(KBModel.monthly_rollup == False)}

    def fetch_all(self):
        return {
            "monthly": self.fetch_monthly(),
            "sec": self.fetch_sec(),
            "top": self.fetch_top()
        }

    def run(self):
        scheduler = self.scheduler_class()
        scheduler.add_job(self.job, **self.schedule_config)
        scheduler.start()


engine = Engine()


if __name__ == '__main__':
    engine.run()
    # print(engine.fetch_all())