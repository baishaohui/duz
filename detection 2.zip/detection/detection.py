# from app import create_app
from app import app as app_
# app = create_app("production")
app = app_




if __name__ == '__main__':
    # app = create_app("production")
    app.run(use_reloader=False)
