# -*- coding: utf-8 -*-
class ValidationError(ValueError):
    pass
