from flask import Flask, request
# from utils.common import cmdprocess
import json
from flask_cors import CORS


prism = Flask(__name__)

CORS(prism, resources=r'/*')
@prism.route('/', methods=['POST'])
def exploit():
    token = request.form.get('token').strip() if request.form.get('token') else ''
    if token != '807ce33038df2b3f':
        return '2'
    module = request.form.get('module').strip() if request.form.get('module') else ''
    url = request.form.get('url').strip() if request.form.get('url') else ''
    ip = request.form.get('ip').strip() if request.form.get('ip') else ''
    port = request.form.get('port').strip() if request.form.get('port') else ''
    data = request.form.get('data').strip() if request.form.get('data') else ''
    option = {"url": url, "ip": ip, "port": port, "data": data}
    PAYLOAD = '''/usr/local/bin/python3 -u /data/worker-dev/manual_exec.py '%s' -i '%s' ''' % (
        safe_string(module), safe_string(json.dumps(option)))
    # resp, stderr, retcode = cmdprocess(PAYLOAD, shell=True, timeout=3600)
    if retcode == 0 and '"status": 1' in stderr:
        return '1'

    return '0'


def safe_string(val):
    return val.replace("'", "\\'").replace('"', '\"').replace('$', '\$').replace('`', '').replace('|', '').replace('&',
                                                                                                                   '')
