# -*- coding: utf-8 -*-
from collections import OrderedDict
from datetime import datetime
from enum import Enum

from flask_login import UserMixin, current_user
from sqlalchemy import or_, and_
from werkzeug.security import check_password_hash, generate_password_hash
from exceptions import ValidationError
from . import db


def _get_fields_dict(cls):
    # return OrderedDict(**{field: getattr(cls, field).comment for field in cls.__public__})
    return [(field, getattr(cls, field).comment) for field in cls.__public__]


class BaseModelAbstract(db.Model):
    __abstract__ = True
    __public__ = []
    id = db.Column(db.Integer, primary_key=True, comment="id")
    create_time = db.Column(db.DateTime, default=datetime.now, comment="创建时间")

    def convert_to_json(self):
        return [
            ("pk", self.id)
        ]

    @classmethod
    def find(cls, kw, date):
        conditions = [getattr(cls, name).contains(kw) for name in cls.__public__ if name.endswith("name")]
        if not date:
            return cls.query.filter(or_(*conditions))
        date = date.replace("/", "-")
        return cls.query.filter(
            and_(or_(*conditions), cls.create_time.like(date + "%")))

    def ping(self):
        if hasattr(self, "last_modify_time"):
            self.last_modify_time = datetime.now()


class Permissions:
    SCAN = 1
    REPORT = 2
    ADMIN = 4


class UserProfile(UserMixin, BaseModelAbstract):
    __tablename__ = "user"
    __public__ = ["username", "role"]
    username = db.Column(db.String(32), nullable=False, comment="用户名")
    _password = db.Column("password", db.String(256), nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey("role.id"), comment="角色")
    access_log = db.relationship("AccessLog", backref="user", lazy="dynamic")
    last_login = db.Column(db.DateTime(), default=datetime.now)
    comment = "用户信息"

    def __init__(self, **kwargs):
        super(UserProfile, self).__init__(**kwargs)
        if self.role is None:
            self.role = Role.query.filter_by(default=True).first()

    @property
    def password(self):
        raise AttributeError("Password is not readable!")

    # @classmethod
    # def find(cls, kw):
    #     return cls.query.filter(cls.username.contains(kw))

    @password.setter
    def password(self, raw_password):
        self._password = generate_password_hash(raw_password)

    def verify_password(self, input_password):
        return check_password_hash(self._password, input_password)

    def can(self, action):
        return self.role is not None and self.role.has_permission(action)

    @property
    def is_admin(self):
        return self.can(Permissions.ADMIN)

    @property
    def is_staff(self):
        if self.role.permissions == 2:
            # 说明是日报编辑者，可以访问日报管理页面
            return True
        return False

    def ping(self):
        self.last_login = datetime.now()
        db.session.add(self)
        db.session.commit()

    @property
    def readonly(self):
        return True

    def convert_to_json(self):
        return [
            ("pk", self.id),
            ("account", self.username),
            ("role", self.role.role_name)
        ]

    @classmethod
    def cn_fields_names(cls):
        # return {
        #     "username": cls.username.comment,
        #     "role": cls.role_id.comment
        # }
        return [
            ("username", cls.username.comment),
            ("role", cls.role_id.comment)
        ]


class Role(BaseModelAbstract):
    __tablename__ = "role"
    __public__ = ["role_name"]
    role_name = db.Column("name", db.String(32), nullable=False, unique=True, comment="角色名")
    default = db.Column(db.Boolean, default=False, index=True, comment="默认身份")
    permissions = db.Column(db.Integer, comment="权限")
    users = db.relationship("UserProfile", backref="role", lazy="dynamic")

    def __init__(self, **kwargs):
        super(Role, self).__init__(**kwargs)
        if self.permissions is None:
            self.permissions = 0

    def __repr__(self):
        return "<%s>" % self.role_name

    @staticmethod
    def initial_roles():
        roles = {
            "User": [Permissions.SCAN],
            "Reporter": [Permissions.REPORT],
            "Administrator": [Permissions.ADMIN, Permissions.SCAN, Permissions.REPORT]
        }
        default_role = "User"
        for role_name in roles:
            role = Role.query.filter_by(role_name=role_name).first()
            if not role:
                role = Role(role_name=role_name)
            role.clear_permission()
            for permission in roles[role_name]:
                role.add_permissions(permission)
            role.default = (role.role_name == default_role)
            db.session.add(role)
        db.session.commit()

    def add_permissions(self, permission):
        if not self.has_permission(permission):
            self.permissions += permission

    def remove_permissions(self, permission):
        if self.has_permission(permission):
            self.permissions -= permission

    def clear_permission(self):
        self.permissions = 0

    def has_permission(self, permission):
        return self.permissions & permission == permission


class ModuleConfig(BaseModelAbstract):
    __tablename__ = "module"
    name = db.Column(db.String(256), nullable=False, comment="模块名")
    module_name = db.Column(db.String(256), nullable=True, comment="插件名")
    description = db.Column(db.Text, comment="模块详情")
    port = db.Column(db.Integer, default=80, comment="端口号")
    placeholder = db.Column(db.String(128), comment="输入提示内容")
    visible = db.Column(db.Boolean, default=True, comment="启用状态")
    pub_date = db.Column(db.Date, comment="模块发布日期")
    last_modify_time = db.Column(db.DateTime, comment="最后更新时间")
    comment = "扫描配置"

    def update_modify_time(self):
        self.last_modify_time = datetime.now()

    @classmethod
    def cn_fields_names(cls):
        # return OrderedDict(**{
        #     "name": cls.name.comment,
        #     "description": cls.description.comment,
        #     "module_name": cls.module_name.comment,
        #     "placeholder": cls.placeholder.comment,
        #     # "port": cls.port.comment,
        #     "pub_date": cls.pub_date.comment,
        #     "visible": cls.visible.comment
        # })
        return [
            ("name", cls.name.comment),
            ("description", cls.description.comment),
            ("module_name", cls.module_name.comment),
            ("placeholder", cls.placeholder.comment),
            # "port": cls.port.comment,
            ("pub_date", cls.pub_date.comment),
            ("visible", cls.visible.comment)
        ]

    def convert_to_json(self):
        # module_in_json = OrderedDict(**{
        #     "pk": self.id,
        #     "module": self.name,
        #     "summary": self.description,
        #     "module_name": self.module_name,
        #     "tip": self.placeholder,
        #     # "port": self.port,
        #     "date": self.pub_date.strftime("%Y-%m-%d"),
        #     "show": self.visible
        # })
        module_in_json = [
            ("pk", self.id),
            ("module", self.name),
            ("summary", self.description),
            ("module_name", self.module_name),
            ("tip", self.placeholder),
            # "port": self.port,
            ("date", self.pub_date.strftime("%Y-%m-%d")),
            ("show", self.visible)
        ]
        return module_in_json

    @classmethod
    def convert_from_json(cls, json_data):
        name = json_data.get("module")
        if not name:
            raise ValidationError("请填写模块名")
        obj = cls(
            name=json_data.get("module"),
            description=json_data.get("summary"),
            placeholder=json_data.get("tip"),
            visible=json_data.get("show"),
            pub_date=json_data.get("date")
        )
        obj.update_modify_time()
        return obj


class AccessLog(BaseModelAbstract):
    __tablename__ = "log"
    __public__ = ["module_name", "user", "remote_address", "url", "time"]
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), comment="用户")
    module_name = db.Column("module", db.String(256), comment="模块名")
    uri = db.Column("uri", db.String(512), comment="url")
    params = db.Column(db.String(512))
    remote_address = db.Column(db.String(128), nullable=True, comment="访问ip")
    access_time = db.Column(db.DateTime, default=datetime.now, comment="执行时间")
    comment = "扫描日志"

    def record_log(self, module_id, uri, ip, params=None):
        module = ModuleConfig.query.filter_by(id=module_id).first()
        self.user_id = current_user.id
        self.module_name = module.name if module else None
        self.uri = uri
        self.params = params
        self.remote_address = ip
        db.session.add(self)
        db.session.commit()

    # @classmethod
    # def find(cls, kw):
    #     if kw:
    #         query = cls.query.filter(cls.module_name.contains(kw))
    #     else:
    #         query = cls.query
    #     return query

    @property
    def readonly(self):
        return False

    @classmethod
    def cn_fields_names(cls):
        # return {
        #     "module": cls.module_name.comment,
        #     "user": cls.user_id.comment,
        #     "remote_address": "登录ip",
        #     "uri": cls.module_name.comment,
        #     "time": cls.access_time.comment
        # }
        return [
            ("module", cls.module_name.comment),
            ("user", cls.user_id.comment),
            ("remote_address", "登录ip"),
            ("uri", cls.module_name.comment),
            ("time", cls.access_time.comment)
        ]

    def convert_to_json(self):
        # return {
        #     "pk": self.id,
        #     "module": self.module_name,
        #     "user": self.user.username,
        #     "remote_ip": self.remote_address,
        #     "url": self.uri,
        #     "time": self.access_time.strftime("%Y-%m-%d"),
        # }
        return [
            ("pk", self.id),
            ("module", self.module_name),
            ("user", self.user.username),
            ("remote_ip", self.remote_address),
            ("url", self.uri),
            ("time", self.access_time.strftime("%Y-%m-%d"))
        ]


class DailyReporter(BaseModelAbstract):
    __tablename__ = "daily_reporter"
    __public__ = ["fake_name", "reporter_content", "create_time", "report_date"]
    fake_name = db.Column(db.String(8), comment="花名")
    reporter_content = db.Column(db.Text, comment="日报内容")
    report_date = db.Column(db.Date, default=datetime.now, comment="日期")
    comment = "日报"

    @classmethod
    def find(cls, kw, date):
        if date:
            return cls.query.filter(
                and_(
                    or_(cls.fake_name.contains(kw), cls.reporter_content.contains(kw))),
                cls.report_date == date)
        return cls.query.filter(or_(cls.fake_name.contains(kw), cls.reporter_content.contains(kw)))

    def convert_to_json(self):
        report_in_json = [
            ("pk", self.id),
            ("fake_name", self.fake_name),
            ("reporter_content", self.reporter_content),
            ("report_date", self.report_date.strftime("%Y-%m-%d"))
        ]
        # report_in_json = OrderedDict(**{
        #     "pk": self.id,
        #     "fake_name": self.fake_name,
        #     "reporter_content": self.reporter_content,
        #     "report_date": self.report_date.strftime("%Y-%m-%d")
        # })
        return report_in_json

    @classmethod
    def cn_fields_names(cls):
        return [
            ("fake_name", cls.fake_name.comment),
            ("reporter_content", cls.reporter_content.comment),
            ("report_date", cls.report_date.comment)
        ]
        # return OrderedDict(**{
        #     "fake_name": cls.fake_name.comment,
        #     "reporter_content": cls.reporter_content.comment,
        #     "report_date": cls.report_date.comment
        # })

    @classmethod
    def convert_from_json(cls, json_data):
        name = json_data.get("fake_name")
        if not name:
            raise ValidationError("请填写花名")
        obj = cls(
            fake_name=json_data.get("fake_name"),
            report_date=json_data.get("report_date"),
            reporter_content=json_data.get("reporter_content")
        )
        return obj


class DingRobotConfig(BaseModelAbstract):
    __tablename__ = "ding_robot"
    __public__ = ["name", "robot_url", "robot_type", "robot_template", "cron_time", "weekend", "enabled"]
    name = db.Column(db.String(64), index=True, unique=True, nullable=False, comment="配置名")
    robot_url = db.Column(db.String(256), nullable=False, comment="机器人链接")
    robot_type = db.Column(db.Enum("notification", "report"), nullable=False, comment="机器人类型")
    robot_template = db.Column(db.Text, nullable=True, comment="通知模板")
    cron_time = db.Column(db.Time, default=datetime.now().replace(hour=17, minute=45).time(), comment="发送时间")
    weekend = db.Column(db.BOOLEAN, default=False, comment="周末执行")
    last_modify_time = db.Column(db.DateTime, comment="更新时间")
    enabled = db.Column(db.BOOLEAN, default=True, comment="启用")
    comment = "钉钉机器人"

    # @classmethod
    # def find(cls, kw):
    #     return cls.query.filter(or_(cls.name.contains(kw), cls.robot_type.contains(kw)))

    def convert_to_json(self):
        # report_in_json = OrderedDict(**{
        #     "pk": self.id,
        #     "name": self.name,
        #     "robot_url": self.robot_url,
        #     "robot_type": self.robot_type,
        #     "robot_template": self.robot_template,
        #     "cron_time": self.cron_time.strftime("%H:%M:%S"),
        #     "weekend": self.weekend,
        #     "enabled": self.enabled
        # })
        report_in_json = [
            ("pk", self.id),
            ("name", self.name),
            ("robot_url", self.robot_url),
            ("robot_type", self.robot_type),
            ("robot_template", self.robot_template),
            ("cron_time", self.cron_time.strftime("%H:%M:%S")),
            ("weekend", self.weekend),
            ("enabled", self.enabled)
        ]
        return report_in_json

    @classmethod
    def cn_fields_names(cls):
        return _get_fields_dict(cls)

    @classmethod
    def convert_from_json(cls, json_data):
        name = json_data.get("name")
        if not name:
            raise ValidationError("请填写配置名")
        obj = cls(
            fake_name=json_data.get("name"),
            robot_url=json_data.get("robot_url"),
            robot_type=json_data.get("robot_type"),
            robot_template=json_data.get("robot_template"),
            cron_time=json_data.get("cron_time"),
            weekend=json_data.get("weekend"),
            enabled=json_data.get("enabled")
        )
        return obj


class VulNew(db.Model):
    __bind_key__ = 'vul'
    __tablename__ = "vul_new"
    id = db.Column(db.Integer, primary_key=True, comment="主键")
    avd_id = db.Column(db.String(128), nullable=False, comment="avd-id")
    gmt_create = db.Column(db.DateTime, nullable=False, default=datetime.now, comment="创建时间")
    gmt_modified = db.Column(db.DateTime, nullable=False, default=datetime.now, comment="修改时间")
    cwe_id = db.Column(db.String(50), nullable=True, default=None, comment="cwe-id")
    release_time = db.Column(db.DateTime, nullable=True, default=None, comment="发现/披露时间")
    cvss3_vector = db.Column(db.String(255), nullable=True, comment="cvss3打分串")
    product_type = db.Column(db.String(50), nullable=True, comment="产品类型\n（OS/Application/硬件）")
    vendor = db.Column(db.String(500), nullable=True, comment="漏洞厂商")
    product = db.Column(db.Text, nullable=True, comment="影响产品")
    cpe = db.Column(db.Text, nullable=True, comment="CPE")
    authentication = db.Column(db.String(5), nullable=True, comment="是否需要身份认证,\n1需要,0不需要")
    gained_privilege = db.Column(db.String(5), nullable=True, comment="是否能获取服务权限,\n1可以,0不可以")
    vul_level = db.Column(db.String(10), nullable=True, comment="漏洞等级严重、高危、中危、低危")
    summary_en = db.Column(db.Text, nullable=True, comment="漏洞简介-en")
    summary_cn = db.Column(db.Text, nullable=True, comment="漏洞简介-cn")
    poc = db.Column(db.Text, nullable=True, comment="poc利用脚本")
    poc_disclosure_time = db.Column(db.DateTime, nullable=True, comment="poc公开日期")
    solution_en = db.Column(db.Text, nullable=True, comment="修复方案-en")
    solution_cn = db.Column(db.Text, nullable=True, comment="修复方案-cn")
    reference = db.Column(db.Text, nullable=True, comment="参考链接")
    classify = db.Column(db.String(512), nullable=True, comment="漏洞类型分类")
    cve_id = db.Column(db.String(50), nullable=False, comment="cveid")
    cvss3_score = db.Column(db.String(50), nullable=False, comment="cvss3评分")
    title_cn = db.Column(db.String(50), nullable=False, comment="中文标题")
    title_en = db.Column(db.String(50), nullable=False, comment="英文标题")
    rule_status = db.Column(db.Integer, default=1, nullable=False, comment="状态")  # 1=未上线 2=灰度中 3=已上线
    is_translated = db.Column(db.Boolean, default=False, comment="人工审核")
    # gmt_modified = db.Column(db.DateTime, default=datetime.now, nullable=False, comment="更新时间")
    # comment = "漏洞信息"
    # __mapper_args__ = {
    #     "order_by": gmt_modified.desc()
    # }


model_cls_dict = {
    "module": ModuleConfig,
    "user": UserProfile,
    "log": AccessLog,
    "daily_reporter": DailyReporter,
    "ding_robot": DingRobotConfig
}
