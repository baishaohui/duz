# -*- coding: utf-8 -*-
from itertools import groupby
import datetime

import copy
import requests
from sqlalchemy import create_engine

SQLALCHEMY_URI = "mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/scan_db?charset=utf8&binary_prefix=true"
REPORT_DEADLINE = datetime.time(hour=20, minute=0)
# TEAMS = {
#     '冰云': ('冰云', '先知与渗透测试', '13805769160'),
#     '泡泡': ('泡泡', '先知与渗透测试', '18710829799'),
#     '毛儿': ('毛儿', '先知与渗透测试', '13020022323'),
#     '密文': ('密文', '先知与渗透测试', '18867101790'),
#     '宸毅': ('宸毅', '先知与渗透测试', '15880900281'),
#     '宣义': ('宣义', '先知与渗透测试', '18143476746'),
#     '流殇': ('流殇', '先知与渗透测试', '15006100085'),
#     '凌林': ('凌林', '先知与渗透测试', '18959264164'),
#
#     '零日': ('零日', '蓝军与云平台保障', '17816872785'),
#     '更酌': ('更酌', '蓝军与云平台保障', '19906712853'),
#     '路郁': ('路郁', '蓝军与云平台保障', '15110250062'),
#
#     '刺痛': ('刺痛', '漏洞管理和基线检查', '18576785823'),
#     '维驹': ('维驹', '漏洞管理和基线检查', '18817719828'),
#
#     '天铖': ('天铖', '漏洞扫描', '18613820018'),
#     '曜晖': ('曜晖', '漏洞扫描', '18500398404'),
# }

TEAMS = {
    '冰云': ('冰云', '商业化', '13805769160'),
    '泡泡': ('泡泡', '商业化', '18710829799'),
    '毛儿': ('毛儿', '商业化', '13020022323'),
    '密文': ('密文', '商业化', '18867101790'),
    '天铖': ('天铖', '商业化', '18613820018'),
    '宣义': ('宣义', '商业化', '18143476746'),
    '流殇': ('流殇', '商业化', '15006100085'),
    '凌林': ('凌林', '商业化', '18959264164'),
    '毛盾': ('毛盾', '商业化', '18157120796'),

    '零日': ('零日', '内部保障', '17816872785'),
    '更酌': ('更酌', '内部保障', '19906712853'),
    '路郁': ('路郁', '内部保障', '15110250062'),
    '贤唐': ('贤唐', '内部保障', '18667156596'),
    '观行': ('观行', '内部保障', '18268167882'),
    '杜乔': ('杜乔', '内部保障', '13376832974'),

    '刺痛': ('刺痛', '业务支撑', '18576785823'),
    '维驹': ('维驹', '业务支撑', '18817719828'),
    '宸毅': ('宸毅', '业务支撑', '15880900281'),
    '曜晖': ('曜晖', '业务支撑', '18500398404'),

}

# DEPARTMENTS = {
#     "先知与渗透测试": [
#         ("冰云", "13805769160"),
#         ("泡泡", "18710829799"),
#         ("毛儿", "13020022323"),
#         ("密文", "18867101790"),
#         ("宸毅", "15880900281"),
#         ("宣义", "18143476746"),
#         ("流殇", "15006100085"),
#         ("凌林", "18959264164"),
#     ],
#     "蓝军与云平台保障": [
#         ('零日', '17816872785'),
#         ('更酌', '19906712853'),
#         ('路郁', '15110250062')
#     ],
#     "漏洞管理和基线检查": [
#         ('刺痛', '18576785823'),
#         ('维驹', '18817719828')
#     ],
#     "漏洞扫描": [
#         ('天铖', '18613820018'),
#         ('曜晖', '18500398404')
#     ]
# }

DEPARTMENTS = {
    "商业化": [
        ("冰云", "13805769160"),
        ("泡泡", "18710829799"),
        ("毛儿", "13020022323"),
        ("密文", "18867101790"),
        ('天铖', '18613820018'),
        ("宣义", "18143476746"),
        ("流殇", "15006100085"),
        ("凌林", "18959264164"),
        ('毛盾', '18157120796')
    ],
    "内部保障": [
        ('零日', '17816872785'),
        ('更酌', '19906712853'),
        ('路郁', '15110250062'),
        ('贤唐', '18667156596'),
        ('观行', '18268167882'),
        ('杜乔', '13376832974')
    ],
    "业务支撑": [
        ('刺痛', '18576785823'),
        ('维驹', '18817719828'),
        ("宸毅", "15880900281"),
        ('曜晖', '18500398404')
    ]
}


def _fetchall(sql, param=None):
    db = create_engine(SQLALCHEMY_URI)
    result = db.execute(sql, param) if param else db.execute(sql)
    return result.fetchall()


def get_reports(today):
    sql = "SELECT fake_name,reporter_content FROM daily_reporter WHERE report_date=%s"
    param = today.strftime("%Y-%m-%d")
    return _fetchall(sql, param)


def get_robot():
    sql = "SELECT robot_url FROM ding_robot WHERE enabled=1 LIMIT 1"
    return _fetchall(sql)


def send(robot, message):
    header = {"Content-Type": "application/json; charset=utf-8"}
    response = requests.post(robot, json=message, headers=header, timeout=30)
    assert response.status_code == 200, response.status_code
    assert response.json()['errcode'] == 0, response.json()
    assert response.json()['errmsg'] == 'ok', response.json()


def send_message(text=None, markdown=None, mobiles=None):
    message_dict = {}
    if text is not None:
        message_dict.update({
            "msgtype": "text",
            "text": {"content": text}
        })
        if isinstance(mobiles, list):
            message_dict.update({
                "at": {
                    "atMobiles": mobiles,
                    "isAtAll": False
                }})
    if markdown is not None:
        message_dict.update({
            "msgtype": "markdown",
            "markdown": {
                "title": "日报",
                "text": markdown
            },
            "at": {
                "atMobiles": [],
                "isAtAll": True
            }
        })
    if not markdown and not text:
        return False
    robots = get_robot()
    for robot in robots:
        url = robot["robot_url"]
        send(url, message_dict)
    return True


def build_message(today):
    content = f"### 莱因团队日报 \n\n [{today}](http://47.97.46.232/daily/report/today '工作日报')"
    return content


# def build_message(today):
#     report_text = f'# 莱因团队日报 {today}\n  &nbsp; \n'
#     reports = get_reports(today)
#     reports = {row['fake_name']: row for row in reports}
#     # for depart, people in groupby(TEAMS.values(), key=lambda x: x[1]):
#     for depart, people in DEPARTMENTS.items():
#         if report_text:
#             report_text += "&nbsp; \n\n"
#         report_text += f'## {depart}\n\n  &nbsp; \n\n -----\n\n  &nbsp; \n\n'
#         report_text += "\n\n".join(
#             ('**' + person[0] + "**" + '\n\n' + reports[person[0]]['reporter_content'].strip() + "\n\n&nbsp;\n\n")
#             for person in people
#             if person[0] in reports)
#         # report_text += '&nbsp; \n\n'
#     return report_text.rsplit("&nbsp; \n\n", 1)[0]


def build_notification(today: datetime.date, text=None):
    reports = get_reports(today)
    missing = list(set(TEAMS).difference(x['fake_name'] for x in reports))
    mobiles = [TEAMS[missed][2] for missed in missing if missed in TEAMS]
    if text is None:
        text = f'亲们写日报啦!\n\n人齐或者截止{str(REPORT_DEADLINE)}时会自动发送\n' \
               f'晨会内容录入系统：http://47.97.46.232/hardtoguessadmin/daily_reporter\n' \
               f'登录账号：aliyun/9ZsVKChiEjNB\n' \
               f'公网也能访问\n' \
               f'超时请交罚款RMB100给零日作为团队零食经费:) 实习生由师兄代劳'
    return text, mobiles


if __name__ == '__main__':
    t = build_message(datetime.date.today().replace(day=12))
    m = {
        "msgtype": "markdown",
        "markdown": {
            "title": "日报",
            "text": t
        },
        "at": {
            "atMobiles": [],
            "isAtAll": True
        }
    }
    send(
        "https://oapi.dingtalk.com/robot/send?access_token=411bbde3d4c7aa76b383354c2f24aa5d46efc8795b8a303b387c7cb87efe6364",
        m
    )
    # t = build_notification(datetime.date.today())
    # send_message(t, text=t)
