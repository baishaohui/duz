# -*- coding: utf-8 -*-
import datetime
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, DateField
from wtforms.validators import DataRequired, Length, InputRequired
from flask_pagedown.fields import PageDownField


class DailyReportForm(FlaskForm):
    name = StringField("花名",
                       validators=[InputRequired("花名必填"),
                       Length(min=2, max=4, message="长度介于2~4个字符")],
                       render_kw={"placeholder": "请输入花名"})
    date = DateField("日期", validators=[InputRequired("日期必填")], default=datetime.date.today)
    report = TextAreaField("日报", validators=[InputRequired("日报内容不能为空")],
                           render_kw={"placeholder": "请输入周报内容，如：\n1. xxx...\n2. xxx..."})
