# -*- coding: utf-8 -*-
import datetime

import re
import requests
from flask import request, render_template, jsonify, redirect, url_for, current_app
from flask_login import current_user, login_required
from sqlalchemy import or_

from app.db.extra_db import find_vendor, find_cve, find_type, find_product, find_version
from app.decorators import scan_required, reporter_required
from app.reporter import get_reports, DEPARTMENTS
from app.web.forms import DailyReportForm
from . import web
from .. import db
from app.models import AccessLog, ModuleConfig, DailyReporter, Permissions, VulNew


@web.route("/", endpoint="index")
@login_required
def index():
    if current_user.can(Permissions.SCAN):
        return redirect(url_for("web.scanning"))
    if current_user.can(Permissions.REPORT):
        return redirect(url_for("admin.table", table_name="daily_reporter"))


@web.route("/scanning", endpoint="scanning", methods=["GET"])
@login_required
@scan_required
def scanning():
    keyword = request.args.get("q", "").strip()
    date = request.args.get("d", "").strip()
    page = request.args.get("p", 1, type=int)
    module_list = ModuleConfig.find(keyword, date).visible().order_by(
        ModuleConfig.pub_date.desc()).paginate(page=page, per_page=15, error_out=False)
    return render_template("web/modules.html", querysets=module_list.items, pagination=module_list, q=keyword)


@web.route("/scan", endpoint="scan", methods=["POST"])
@login_required
@scan_required
def scan():
    module_id = request.form.get("pk", type=int)
    module = ModuleConfig.query.filter_by(id=module_id).first()
    if not module:
        return jsonify({"success": 0, "code": 404, "msg": "not found"})
    response = requests.post(
        current_app.config["SCAN_URL"],
        data={
            "token": current_app.config["TOKEN"],
            "url": request.form.get("url") or "",
            "module": module.module_name
        }
    )
    return jsonify({"code": response.text})


@web.route("/daily/report/today", endpoint="daily_report", methods=["GET", "POST"])
@login_required
@reporter_required
def daily_report():
    today = datetime.date.today()
    reports = get_reports(today)
    reports = {row['fake_name']: row for row in reports}
    d = dict()
    for dp, detail in DEPARTMENTS.items():
        d[dp] = dict(detail)
    return render_template(
        "web/daily_report.html",
        objs=d,
        reports=reports,
        today=today.strftime("%Y-%m-%d")
    )


@web.route("/security/focus", endpoint="focus", methods=["GET"])
@login_required
def cpe_find():
    page = request.args.get("p", 1, type=int)
    product_type = request.args.get("type", "")
    vendor = request.args.get("vendor", "")
    product = request.args.get("product", "")
    version = request.args.get("version", "")
    cve_list = find_cve(part=product_type,
                        vendor=vendor,
                        product=product,
                        version=version)
    existed_cve = VulNew.query.with_entities(VulNew.cve_id).all()
    existed_cve_id = set([cve[0] for cve in existed_cve]) & set(cve_list)
    if not cve_list and not any(request.args.values()):
        queryset_list = VulNew.query.order_by(
            VulNew.release_time.desc()).with_entities(
            VulNew.cve_id, VulNew.release_time, VulNew.title_en,
            VulNew.title_cn, VulNew.summary_cn, VulNew.summary_en).paginate(
            page=1, per_page=20, error_out=False)
    else:
        queryset_list = VulNew.query.order_by(
            VulNew.release_time.desc()).with_entities(
            VulNew.cve_id, VulNew.release_time, VulNew.title_en,
            VulNew.title_cn, VulNew.summary_cn, VulNew.summary_en).filter(
            or_(VulNew.cve_id.in_(list(existed_cve_id)))).paginate(
            page=page, per_page=35, error_out=False)
    o = find_type()
    return render_template(
        "web/cpe.html",
        querysets=queryset_list.items,
        pagination=queryset_list,
        o=o,
        vendor=vendor,
        product=product,
        version=version
    )


@web.app_template_global(name="product_type")
def product_type():
    return {
        "a": "application",
        "o": "os",
        "h": "hardware"
    }


@web.app_template_filter(name="queries")
def queries(page):
    if "p" in request.args:
        return "?" + "&".join([f"{k}={v}" if k != "p" else f"{k}={page}" for k, v in request.args.items()])
    else:
        if not request.args:
            return f'?p={page}'
        else:
            return f'?p={page}&{request.query_string.decode("utf-8")}'
