# -*- coding: utf-8 -*-
from flask import request, url_for
from flask import Blueprint
from ..models import AccessLog

web = Blueprint("web", __name__)

from . import views, errors


@web.before_request
def record_log():
    if request.path == url_for("web.scan") and request.method == "POST":
        module_id = request.form.get("pk")
        uri = request.form.get("url")
        ip = request.remote_addr
        try:
            _ip = request.headers["X-Real-IP"]
            if _ip is not None:
                ip = _ip
        except KeyError as e:
            print("Not set X-Real-IP to header in nginx", e)
        log = AccessLog()
        log.record_log(module_id, uri, ip)



