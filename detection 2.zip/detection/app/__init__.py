# -*- coding: utf-8 -*-
from datetime import timedelta
from flask import Flask
from flask_bootstrap import Bootstrap
from flask_pagedown import PageDown
from flask_debugtoolbar import DebugToolbarExtension
from flask_apscheduler.scheduler import APScheduler
from flask_login import LoginManager
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy, BaseQuery

from app.bgscheduler import CuBackgroundScheduler
from config import config


class Query(BaseQuery):

    def visible(self):
        return self.filter_by(visible=True)


db = SQLAlchemy(query_class=Query)
login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.login_message = "请先登录"
toolbar = DebugToolbarExtension()
pagedown = PageDown()
# sche = APScheduler(CuBackgroundScheduler())
sche = APScheduler()


def register_blueprint(app):
    from .auth import auth
    from .admin import admin
    from .web import web
    from .api import api
    app.register_blueprint(auth)
    app.register_blueprint(web)
    app.register_blueprint(admin)
    app.register_blueprint(api)


# config_name = "production"
config_name = "development"
# def create_app(config_name="development"):
app = Flask(__name__)
app.config.from_object(config[config_name])
config[config_name].init_app(app)
login_manager.init_app(app)
bootstrap = Bootstrap(app)
app.permanent_session_lifetime = timedelta(days=7)
db.init_app(app)
pagedown.init_app(app)
register_blueprint(app)
sche.init_app(app)

sche.start()
Migrate(app, db)
# app.debug = True
# toolbar.init_app(app)
# return app
