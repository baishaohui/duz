# -*- coding: utf-8 -*-
from functools import wraps
from flask import abort, request
from flask_login import current_user

from app.models import Permissions


def permission_required(permission):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if current_user.is_staff and request.endpoint in (
                    "admin.table", "admin.delete", "admin.edit", "api.list", "web.daily_report"):
                if "daily_reporter" in request.view_args.values():
                    return f(*args, **kwargs)
            if not current_user.can(permission):
                abort(404)
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def admin_required(f):
    return permission_required(Permissions.ADMIN)(f)


def reporter_required(f):
    return permission_required(Permissions.REPORT)(f)


def scan_required(f):
    return permission_required(Permissions.SCAN)(f)