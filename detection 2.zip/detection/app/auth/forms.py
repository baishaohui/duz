# -*- coding: utf-8 -*-
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField, ValidationError
from wtforms.validators import DataRequired, Length, EqualTo

from ..models import UserProfile


class LoginForm(FlaskForm):
    username = StringField("", validators=[DataRequired(
        "用户名为必填字段"), Length(max=32, min=2, message="用户名长度介于2~32个字符")], render_kw={
        "placeholder": "用户名", "class": "form-control"})
    password = PasswordField("", validators=[DataRequired(
        "密码为必填字段")], render_kw={"placeholder": "密码", "class": "form-control"})


class RegistrationForm(FlaskForm):
    username = StringField("", validators=[DataRequired(
        "用户名为必填字段"), Length(max=32, min=2, message="用户名长度介于2~32个字符")], render_kw={
        "placeholder": "用户名", "class": "form-control"})
    password = PasswordField('', validators=[
        DataRequired(), EqualTo('password2', message='两次输入的密码不一致')], render_kw={
        "placeholder": "输入密码", "class": "form-control"
    })
    password2 = PasswordField('', validators=[DataRequired("确认密码不能为空")], render_kw={
        "placeholder": "确认密码", "class": "form-control"
    })

    def validate_username(self, field):
        if UserProfile.query.filter_by(username=field.data).first():
            raise ValidationError("用户名「%s」已存在！" % field.data)

