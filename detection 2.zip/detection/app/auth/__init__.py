# -*- coding: utf-8 -*-
from flask import Blueprint
from flask_login import current_user

auth = Blueprint("auth", __name__)

from . import views


@auth.before_request
def before_request():
    if current_user.is_authenticated:
        current_user.ping()
