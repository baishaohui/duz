# -*- coding: utf-8 -*-
from flask import request, url_for, redirect, flash, render_template
from flask_login import login_user, current_user, logout_user, login_required
from . import auth
from .forms import LoginForm, RegistrationForm
from ..models import db, UserProfile
from .. import login_manager
from ..decorators import admin_required


@auth.route("/login", endpoint="login", methods=["GET", "POST"])
def login():
    title = "登录"
    form = LoginForm()
    remembered = None
    if form.validate_on_submit():
        user = UserProfile.query.filter_by(username=form.username.data).first()
        remembered = request.form.get("remember_me")
        if user and user.verify_password(form.password.data):
            login_user(user, remember=remembered)
            redirect_url = request.args.get("next", "")
            if not redirect_url or not redirect_url.startswith("/"):
                if user.is_staff:
                    redirect_url = url_for("admin.table", table_name="daily_reporter")
                else:
                    redirect_url = url_for("web.scanning")
            return redirect(redirect_url)
        flash("用户名或密码错误！")
    return render_template("auth/login.html", form=form, title=title, remembered=remembered)


@auth.route("/reg", endpoint="register", methods=["GET", "POST"])
@login_required
@admin_required
def register():
    title = "注册"
    form = RegistrationForm()
    if form.validate_on_submit():
        user = UserProfile(username=form.username.data, password=form.password.data)
        db.session.add(user)
        db.session.commit()
        if request.form.get("login_after_reg"):
            if current_user.is_authenticated:
                logout_user()
            login_user(user)
        return redirect(url_for("web.scanning"))
    return render_template("auth/registration.html", form=form, title=title)


@auth.route('/logout')
@login_required
def logout():
    logout_user()
    flash('您已登出')
    return redirect(url_for('auth.login'))


@login_manager.user_loader
def load_user(id):
    return UserProfile.query.get(int(id))
