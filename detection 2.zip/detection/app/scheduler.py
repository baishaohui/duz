# -*- coding: utf-8 -*-
import json

import datetime
from itertools import groupby

import requests
from pytz import timezone
from flask.signals import Namespace
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app import sche

signal = Namespace()
schedule_signal = signal.signal("daily_report")
current_timezone = timezone('Asia/Shanghai')
TEAMS = {
    '冰云': ('冰云', '先知与渗透测试', '13805769160'),
    '泡泡': ('泡泡', '先知与渗透测试', '18710829799'),
    '毛儿': ('毛儿', '先知与渗透测试', '13020022323'),
    '密文': ('密文', '先知与渗透测试', '18867101790'),
    '宸毅': ('宸毅', '先知与渗透测试', '15880900281'),
    '宣义': ('宣义', '先知与渗透测试', '18143476746'),
    '流殇': ('流殇', '先知与渗透测试', '15006100085'),
    '凌林': ('凌林', '先知与渗透测试', '18959264164'),

    '零日': ('零日', '蓝军与云平台保障', '17816872785'),
    '更酌': ('更酌', '蓝军与云平台保障', '19906712853'),
    '路郁': ('路郁', '蓝军与云平台保障', '15110250062'),

    '刺痛': ('刺痛', '漏洞管理和基线检查', '18576785823'),
    '维驹': ('维驹', '漏洞管理和基线检查', '18817719828'),

    '天铖': ('天铖', '漏洞扫描', '18613820018'),
    '曜晖': ('曜晖', '漏洞扫描', '18500398404'),
}


def build_report(today, reports):
    report_text = f'# 莱因团队日报 {today}\n'
    reports = {row['fake_name']: row for row in reports}
    for depart, people in groupby(TEAMS.values(), key=lambda x: x[1]):
        report_text += f'## {depart}\n\n-----\n\n'
        report_text += "\n\n".join(
            '### ' + person[0] + '\n\n' + reports[person[0]]['reporter_content'].strip()
            for person in people
            if person[0] in reports)
        report_text += '\n\n'
    return report_text


def _ding_report(url, robot_type, tmp):
    # 发送钉钉消息
    template = {
        "msgtype": "text",
        "text": {
            "content": ""
        },
        "at": {
            "atMobiles": [],
            "isAtAll": True
        }
    }
    if robot_type == "notification":
        message = tmp if tmp else "今日日报不要忘记"
    else:
        db = create_engine(
            'mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/scan_db')
        DBSession = sessionmaker(bind=db)
        session = DBSession()
        result = session.execute(
            "SELECT fake_name,reporter_content, create_time FROM ("
            "select fake_name, reporter_content, create_time create_time "
            f"from daily_reporter where DATE (report_date)='{datetime.datetime.today().strftime('%Y-%m-%d')}' "
            "ORDER BY fake_name,create_time DESC)T GROUP BY fake_name;"
        )
        message = f"莱因团队晨会纪要  {datetime.date.today().strftime('%Y/%m/%d')}"
        result = result.fetchall()
        for r in result:
            if message:
                message += "\n\n"
            message += f"{r[0]} \n {r[1]} "
        message += "\n\n"
        if not result:
            message = ""
        session.close()
    if message:
        template["text"]["content"] = message
        header = {"Content-Type": "application/json; charset=utf-8"}
        msg = json.dumps(template, ensure_ascii=False)
        response = requests.post(url, data=msg.encode("utf-8"), headers=header)
        print(response.text)
        return json.loads(response.text)


class Reporter:
    reporter = sche

    # def __init__(self):
    #     self.load_jobs()

    @classmethod
    def pop(cls, job):
        if isinstance(job, int):
            job = str(job)
        has_job = cls.reporter.get_job(job)
        if has_job is not None:
            removed_job = cls.reporter.remove_job(job)
            return removed_job

    @classmethod
    def push(cls, job, callback_func, cron_time, weekend=True, *args):
        day_of_week = "0-6"
        if isinstance(cron_time, datetime.time):
            hour, minute, second = (cron_time.hour, cron_time.minute, cron_time.second)
        else:
            hour, minute, second = cron_time
        if not weekend:
            day_of_week = "0-4"
        the_job = cls.reporter.add_job(
            job,
            callback_func,
            trigger="cron",
            hour=hour, minute=minute, second=second,
            replace_existing=True,
            max_instances=10,
            args=args,
            misfire_grace_time=60,
            day_of_week=day_of_week)
        return the_job

    @classmethod
    def load_jobs(cls):
        db = create_engine(
            'mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/scan_db')
        DBSession = sessionmaker(bind=db)
        session = DBSession()
        all_jobs = session.execute("SELECT * FROM ding_robot WHERE enabled=1")
        for job in all_jobs:
            cron_time = job[6]
            cron_time = (
                int(cron_time.total_seconds() // 3600),
                int(cron_time.total_seconds() % 3600 // 60),
                int(cron_time.total_seconds() % 60))
            cls.push(str(job[0]), _ding_report, cron_time, job[7], *(job[3], job[4], job[5]))
        session.close()


reporter = Reporter()


def job_handler(*args, **kwargs):
    sender = kwargs.get("sender")
    pk = kwargs.get("pk")
    reporter = kwargs.get("reporter")
    if sender == "delete":
        reporter.pop(str(pk))
    elif sender == "add":
        reporter.push(str(pk), _ding_report, kwargs.get("cron_time"), kwargs.get("weekend"),
                      *(kwargs.get("url"), kwargs.get("type"), kwargs.get("template")))


# load_jobs(reporter)
schedule_signal.connect(job_handler)
