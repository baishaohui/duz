# -*- coding: utf-8 -*-
import re
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import os

basedir = os.path.abspath(os.path.abspath(os.path.dirname(__file__)))


# def create_conn():
#     engine = create_engine(f'sqlite:///{basedir}/cve.sqlite3', connect_args={'check_same_thread': False})
#     Database = sessionmaker(bind=engine)
#     conn = Database()
#     return conn


def create_mysql_engine():
    engine = create_engine(
        "mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/vul_db"
    )
    Database = sessionmaker(bind=engine)
    conn = Database()
    return conn


def find_anything_mysql(sql, **kwargs):
    conn = create_mysql_engine()
    cursor = conn.execute(sql, kwargs)
    result = cursor.fetchall()
    conn.close()
    return [{"id": item[0].replace("\\", ""), "text": item[1].replace("\\", "")}
            if len(item) > 1 else item[0] for item in result]


# def find_anything(sql, **kwargs):
#     conn = create_conn()
#     cursor = conn.execute(sql, kwargs)
#     result = cursor.fetchall()
#     conn.close()
#     return [{"id": item[0], "text": item[1].replace("\\", "")} if len(item) > 1 else item[0] for item in result]


def paginate(total, per_page):
    page = total // per_page
    rest = total % per_page
    return page if not rest else page + 1


def find_total(condition_str, field, limit=10, **kwargs):
    count_sql = (
        f"select count(DISTINCT {field}) as count from cpes {condition_str}"
    )
    # count = find_total(count_sql, limit=limit, **kwargs)
    conn = create_mysql_engine()
    cursor = conn.execute(count_sql, kwargs)
    count = cursor.fetchone()[0]
    if not count:
        return count
    return paginate(count, limit)


def find_vendor(o, page=0, limit=0, keyword=""):
    condition = {
        "part": f"%{o}%",
        "vendor": f"%{keyword}%",
    }
    params = {
        "limit": limit,
        "offset": (page - 1) * limit
    }
    condition_str = f"WHERE {' AND '.join(['{0} LIKE :{0}'.format(key) for key in condition])}"
    sql = (
        r"SELECT DISTINCT REPLACE(vendor, '\\', ''),REPLACE(vendor, '\\', '') from cpes "
        f"{condition_str} ORDER BY vendor ASC LIMIT :limit OFFSET :offset")
    params.update(condition)

    count = find_total(condition_str, "vendor", limit=limit, **condition)
    vendor_list = find_anything_mysql(sql, **params)
    return vendor_list, count


def find_cve(**kwargs):
    version = kwargs.pop("version")
    kw = [f'{k} like :{k}' for k, v in kwargs.items() if v]
    values = {k: f"%{re.escape(v)}%" for k, v in kwargs.items() if v}
    values["version"] = version
    values["escape_version"] = re.escape(version)
    version_condition = (' AND ((version_start_including <= :version '
                         'AND version_end_including >= :version) OR version=:escape_version)')
    if kw:
        condition = ('where ' + ' and '.join(kw)) if kw else ""
        if condition:
            condition += version_condition
        else:
            condition = "where " + version_condition
        sql = (
            f'SELECT nvd_jsons.cve_id FROM (SELECT nvd_json_id FROM cpes {condition})T '
            ' LEFT JOIN nvd_jsons ON T.nvd_json_id=nvd_jsons.id'
        )
        result = find_anything_mysql(sql, **values)
    else:
        result = []
    return result


def find_type():
    sql = "SELECT DISTINCT part FROM cpes ORDER BY part"
    type_list = find_anything_mysql(sql)
    return type_list


def find_product(pt, vendor, page=0, limit=0, keyword=""):
    condition = {
        "part": f"%{pt}%",
        "vendor": f"%{re.escape(vendor)}%",
        "product": f"%{re.escape(keyword)}%",
    }
    params = {
        "limit": limit,
        "offset": (page - 1) * limit
    }
    condition_str = f"WHERE {' AND '.join(['{0} LIKE :{0}'.format(key) for key in condition])}"

    sql = (r"SELECT DISTINCT REPLACE(product, '\\', ''), REPLACE(product, '\\', '') FROM cpes "
           f"{condition_str} ORDER BY product ASC LIMIT :limit OFFSET :offset")
    params.update(condition)
    count = find_total(condition_str, "product", limit=limit, **condition)
    product_list = find_anything_mysql(sql, **params)
    return product_list, count


def find_version(product, page=0, limit=0, keyword=""):
    keyword = re.escape(keyword)
    condition = {
        "product": f"%{re.escape(product)}%",
        "version": f"%{re.escape(keyword)}%",
    }
    params = {
        "limit": limit,
        "offset": (page - 1) * limit
    }
    condition_str = f"WHERE {' AND '.join(['{0} LIKE :{0}'.format(key) for key in condition])}"
    sql = (r"SELECT DISTINCT REPLACE(version,'\\', ''), REPLACE(version,'\\', '') FROM cpes"
           f" {condition_str} ORDER BY version ASC LIMIT :limit OFFSET :offset")
    params.update(condition)
    count = find_total(condition_str, "version", limit=limit, **condition)
    version_list = find_anything_mysql(sql, **params)
    return count, version_list


def find_cpes(cve_id):
    con = create_mysql_engine()
    sql = ("SELECT nvd_jsons.cve_id AS cve_id, cpes.formatted_string "
           "AS cpe, cpes.product AS `product`, cpes.version_start_including AS `include_from`, "
           "cpes.created_at as published_date,"
           "cpes.version_end_including AS `include_end`, cpes.version_start_excluding "
           "AS exclude_from, cpes.version_end_excluding AS exclude_end FROM cpes "
           "LEFT JOIN nvd_jsons ON cpes.nvd_json_id=nvd_jsons.id "
           "HAVING cve_id=:cve_id")
    result = con.execute(sql, {"cve_id": cve_id})
    data = result.fetchall()
    data = {"data": [{"cveId": d.cve_id, "cpe": d.cpe,
                      "product": d.product,
                      "includeFrom": d.include_from,
                      "includeUpto": d.include_end,
                      "excludeFrom": d.exclude_from,
                      "excludeUpto": d.exclude_end,
                      "published_date": d.published_date.strftime("%Y-%m-%d %H:%M:%S")}
                     for d in data], "count": len(data)}
    return data
