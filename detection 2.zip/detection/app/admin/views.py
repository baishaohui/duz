# -*- coding: utf-8 -*-
from flask import render_template, abort, request, url_for, jsonify, redirect
from flask_login import login_required, current_user

from app import db
from app.decorators import admin_required
from app.scheduler import schedule_signal, _ding_report, reporter
from . import admin
from app.models import model_cls_dict, DingRobotConfig
from .forms import form_dict


@admin.route("/", endpoint="dashboard")
@login_required
@admin_required
def dashboard():
    if current_user.is_staff:
        return redirect(url_for("admin.table", table_name="daily_reporter"))
    return redirect(url_for("admin.table", table_name="module"))


@admin.route("/<string:table_name>", endpoint="table", methods=["GET", "POST"])
@login_required
@admin_required
def data_list(table_name):
    model_cls = model_cls_dict.get(table_name)
    if not model_cls:
        abort(404)
    title = model_cls.comment
    form_cls = form_dict.get(table_name)
    form = form_cls() if form_cls else None
    if request.method == "POST" and form:
        if form.validate_on_submit():
            new_obj = model_cls()
            daily_content = []
            blank = 1
            for name, data in request.form.items():
                data = data.strip()
                if name.startswith("reporter_content") and data:
                    daily_content.append(f"{str(blank)}. {data}")
                    blank += 1
            for field, value in form.__dict__.items():
                if field != "meta" and not field.startswith("_"):
                    vd = value.data
                    if field == "reporter_content":
                        # if len(daily_content) == 1:
                        #     vd = daily_content[0].strip("1. ")
                        # else:
                        vd = "\n".join(daily_content)
                    setattr(new_obj, field, vd)
            db.session.add(new_obj)
            db.session.commit()

            return redirect(url_for("admin.table", table_name=table_name))
    return render_template("admin/data-table.html", title=title, cls=model_cls, form=form or None,
                           query_string=str(request.query_string, encoding="utf8"))


@admin.route("/<string:table_name>/edit/<int:pk>", endpoint="edit", methods=["GET", "POST"])
@login_required
@admin_required
def data_edit(table_name, pk):
    form_cls = form_dict.get(table_name)
    if not form_cls:
        abort(404)
    model_cls = model_cls_dict.get(table_name)
    obj = model_cls.query.filter_by(id=pk).first_or_404()
    title = model_cls.comment
    form = form_cls(obj=obj)
    if form.validate_on_submit():
        form.populate_obj(obj)
        obj.ping()
        db.session.add(obj)
        db.session.commit()
        return redirect(url_for("admin.table", table_name=table_name))
    return render_template("admin/data-form.html", title=title, form=form, obj=obj)


@admin.route("/<string:table_name>/delete", endpoint="delete", methods=["POST"])
@login_required
@admin_required
def data_delete(table_name):
    model_cls = model_cls_dict.get(table_name)
    pk = request.form.get("pk", "")
    if not model_cls:
        abort(404)
    obj = model_cls.query.filter_by(id=pk).first_or_404()
    db.session.delete(obj)
    db.session.commit()
    # if obj.__tablename__ == "ding_robot":
    #     schedule_signal.send(sender="delete", reporter=reporter, pk=obj.id)
    return jsonify({"success": 1})


@admin.route("/test/ding/<int:pk>", endpoint="test_ding", methods=["GET"])
@login_required
@admin_required
def test_ding(pk):
    response = {"code": 200, "msg": ""}
    obj = DingRobotConfig.query.filter_by(id=pk).first()
    if not obj:
        response["code"] = 404
        response["msg"] = "target not found"
        return jsonify(response)
    else:
        res = _ding_report(obj.robot_url, obj.robot_type, obj.robot_template)
        if res is None:
            response["code"] = 401
            response["msg"] = "no message"
        elif res.get("errcode", 1) == 0:
            response["msg"] = "success"
        else:
            response["code"] = 500
            response["msg"] = res.get("errmsg")
    return jsonify(response)
