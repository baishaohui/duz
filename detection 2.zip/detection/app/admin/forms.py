# -*- coding: utf-8 -*-
from datetime import datetime

from flask_pagedown.fields import PageDownField
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, BooleanField, IntegerField, DateField, TimeField, SelectField, \
    SubmitField
from wtforms.validators import DataRequired, Length, NumberRange, ValidationError, InputRequired

from ..models import ModuleConfig


DATA_REQUIRED_MESSAGE = "该字段为必填字段"
LENGTH_LIMIT_MESSAGE = "字段长度介于%d~%d之间"
NUMBER_RANGE_LIMIT = "请输入%d~%d范围内数字"
EXISTED_ERROR_MESSAGE = "该数据已存在，请勿存入重复数据"


class ModuleConfigForm(FlaskForm):
    name = StringField("模块名", validators=[DataRequired(DATA_REQUIRED_MESSAGE), Length(
        max=256, min=1, message=LENGTH_LIMIT_MESSAGE % (1, 256))])
    module_name = StringField("插件名", validators=[DataRequired(DATA_REQUIRED_MESSAGE), Length(
        max=256, min=1, message=LENGTH_LIMIT_MESSAGE % (1, 256))])
    # port = IntegerField("端口号", default=80, validators=[DataRequired(
    #     DATA_REQUIRED_MESSAGE), NumberRange(max=65535, min=1, message=NUMBER_RANGE_LIMIT % (1, 65535))])
    placeholder = StringField("输入提示", validators=[Length(max=128, min=1, message=LENGTH_LIMIT_MESSAGE % (1, 128))])
    pub_date = DateField("漏洞公布日期", default=datetime.today)
    description = TextAreaField("模块描述")
    visible = BooleanField("启用", default=True)

    # def validate_name(self, field):
    #     existed = ModuleConfig.query.filter_by(name=field.data).first()
    #     if existed:
    #         raise ValidationError(EXISTED_ERROR_MESSAGE)


class DingRobotForm(FlaskForm):
    name = StringField("配置名", validators=[DataRequired(DATA_REQUIRED_MESSAGE)])
    robot_url = StringField("机器人链接")
    robot_type = SelectField("消息类型", choices=[("notification", "通知"), ("report", "报告")], default="report")
    robot_template = TextAreaField("消息模板", render_kw={"placeholder": "仅限通知型消息使用"})
    cron_time = TimeField("执行时间", format='%H:%M:%S', default=datetime.now)
    weekend = BooleanField("周末执行", default=False)
    enabled = BooleanField("启用", default=True)


class DailyReportForm(FlaskForm):
    fake_name = StringField("花名",
                       validators=[InputRequired("花名必填"),
                       Length(min=2, max=4, message="长度介于2~4个字符")],
                       render_kw={"placeholder": "请输入花名"})
    report_date = DateField("日期", validators=[InputRequired("日期必填")], default=datetime.today)
    reporter_content = StringField("内容", validators=[InputRequired("日报内容不能为空")],
                           render_kw={"placeholder": "请输入周报内容(单条)，不需要写序号，请勿修改(影响格式)"})


form_dict = {
    "module": ModuleConfigForm,
    "ding_robot": DingRobotForm,
    "daily_reporter": DailyReportForm
}