# -*- coding: utf-8 -*-
import datetime
from flask import abort, request, jsonify, url_for
from flask_login import login_required
from sqlalchemy import or_

from app.db.extra_db import find_vendor, find_product, find_version, find_cve, find_cpes
from app.reporter import send_message, build_notification, build_message
from app.scheduler import _ding_report
from . import api
from app import db
from app.models import model_cls_dict, DingRobotConfig, VulNew
from ..decorators import admin_required, reporter_required

PRODUCT_TYPE = ["hardware", "os", "application"]


@api.route("/<string:table_name>", endpoint="list", methods=["GET"])
@login_required
@admin_required
def get_data_list(table_name):
    model_cls = model_cls_dict.get(table_name)
    if not model_cls:
        abort(404)
    page = request.args.get("p", 1, type=int)
    kw = request.args.get("q", "").strip()
    date = request.args.get("d", "").strip()
    query = model_cls.find(kw, date)
    pagination = query.order_by(model_cls.create_time.desc()).paginate(page, per_page=20, error_out=False)
    items = pagination.items
    prev_url = None
    next_url = None
    if pagination.has_prev:
        prev_url = url_for('api.list', table_name=table_name, p=page - 1)
    if pagination.has_next:
        next_url = url_for('api.list', table_name=table_name, p=page + 1)
    return jsonify({
        'data': [item.convert_to_json() for item in items],
        'prev': prev_url,
        'next': next_url,
        'count': pagination.total,
        "page": pagination.pages
    })


@api.route("/<string:table_name>", endpoint="new", methods=["POST"])
@login_required
@admin_required
def new_data(table_name):
    model_cls = model_cls_dict.get(table_name)
    if not model_cls:
        abort(404)
    new_obj = model_cls.convert_from_json(request.json)

    db.session.add(new_obj)
    db.session.commit()
    return jsonify(new_obj.convert_to_json()), 201, \
           {'Location': url_for('api.single', table_name=table_name, pk=new_obj.id)}


@api.route("/<string:table_name>/<int:pk>",
           endpoint="single", methods=["GET"])
@login_required
@admin_required
def get_data(table_name, pk):
    model_cls = model_cls_dict.get(table_name)
    if not model_cls:
        abort(404)
    obj = model_cls.query.filter_by(id=pk).first_or_404()
    return jsonify(obj.convert_to_json())


@api.route("/<string:table_name>/<int:pk>", endpoint="modify", methods=["PUT"])
@login_required
@admin_required
def modify_data(table_name, pk):
    model_cls = model_cls_dict.get(table_name)
    if not model_cls:
        abort(404)
    obj = model_cls.query.filter_by(id=pk).first_or_404()
    obj = obj.convert_from_json(request.json)
    db.session.add(obj)
    db.session.commit()
    return jsonify(obj.convert_to_json())


@api.route("/api/<string:table_name>/<int:pk>", endpoint="delete", methods=["DELETE"])
@login_required
@admin_required
def delete_data(table_name, pk):
    model_cls = model_cls_dict.get(table_name)
    if not model_cls:
        abort(404)
    obj = model_cls.query.filter_by(id=pk).first_or_404()
    db.session.delete(obj)
    db.session.commit()
    return jsonify()


@api.route("/ding/notify", endpoint="notify", methods=["GET"])
@login_required
@reporter_required
def notify():
    notify_type = request.args.get("type", "notification")
    response = {"code": 200, "msg": ""}
    obj = DingRobotConfig.query.filter_by(enabled=True).order_by(DingRobotConfig.id.asc()).first()
    if not obj:
        response["code"] = 404
        response["msg"] = "target not found"
        return jsonify(response)
    else:
        today = datetime.date.today()
        if notify_type == "notification":
            message, mobiles = build_notification(today)
            kwargs = {"text": message, "mobiles": mobiles}
        else:
            message = build_message(today)
            kwargs = {"markdown": message}
        success = send_message(**kwargs)
        if not success:
            response["code"] = 500
            response["msg"] = "钉钉消息发送失败"
        # res = _ding_report(obj.robot_url, notify_type, obj.robot_template)
        else:
            response["msg"] = "success"
    return jsonify(response)


# def find_vendor(pt):
#     from os import path
#     print(path.path.exists("../db/cve.sqlite3"))
#     engine = create_engine('sqlite:///../../../db/cve.sqlite3', echo=True)
#     Database = sessionmaker(bind=engine)
#     conn = Database()
#     c = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';")
#     return c.fetchall()


@api.route("/find/vendor", endpoint="api_vendor", methods=["GET"])
@login_required
def get_vendors():
    pt = request.args.get("type", "")
    page = request.args.get("page", 1, type=int)
    keyword = request.args.get("k", "", type=str)
    limit = request.args.get("size", 10, type=int)
    vendor_list, count = find_vendor(pt, page=page, limit=limit, keyword=keyword)
    return jsonify({"total": count, "data": vendor_list})


@api.route("/find/product", endpoint="api_product", methods=["GET"])
@login_required
def get_products():
    vendor = request.args.get("type", "")
    product_type = request.args.get("o", "")
    page = request.args.get("page", 1, type=int)
    keyword = request.args.get("k", "", type=str)
    limit = request.args.get("size", 10, type=int)
    product_list, count = find_product(product_type, vendor, page=page, limit=limit, keyword=keyword)
    return jsonify({"total": count, "data": product_list})


@api.route("/find/version", endpoint="api_version", methods=["GET"])
@login_required
def get_versions():
    product = request.args.get("type", "")
    if not product:
        return jsonify([])
    page = request.args.get("page", 1, type=int)
    keyword = request.args.get("k", "", type=str)
    limit = request.args.get("size", 10, type=int)
    count, version_list = find_version(product, page=page, limit=limit, keyword=keyword)
    return jsonify({"total": count, "data": version_list})


@api.route("/find/cve", endpoint="api_cve", methods=["GET"])
@login_required
def get_cves():
    product_type = request.args.get("type", "")
    vendor = request.args.get("vendor", "")
    product = request.args.get("product", "")
    version = request.args.get("version", "")
    page = request.args.get("page", 1, type=int)
    cve_list = find_cve(part=product_type,
                        vendor=vendor,
                        product=product,
                        version=version)
    existed_cve = VulNew.query.with_entities(VulNew.cve_id).all()
    existed_cve_id = set([cve[0] for cve in existed_cve]) & set(cve_list)
    if not cve_list and not any(request.args.values()):
        queryset_list = VulNew.query.order_by(
            VulNew.release_time.desc()).with_entities(
            VulNew.avd_id, VulNew.cve_id, VulNew.release_time).paginate(page=page, per_page=35, error_out=False)
    else:
        queryset_list = VulNew.query.order_by(
            VulNew.release_time.desc()).with_entities(
            VulNew.avd_id, VulNew.cve_id).filter(
            or_(VulNew.cve_id.in_(list(existed_cve_id)))).paginate(
            page=page, per_page=35, error_out=False)
    items = [{key: getattr(queryset, key) for key in queryset.keys()} for queryset in queryset_list.items]
    result = {
        "page_num": queryset_list.pages,
        "total": queryset_list.total,
        "current_page": page,
        "data": items
    }
    return jsonify(result)


@api.route("/find/cpe", endpoint="api_cpe", methods=["GET"])
@login_required
def get_cpes():
    cve_id = request.args.get("cve_id")
    if cve_id is None:
        return jsonify({"code": 400, "msg": "cve_id is required"})
    data = find_cpes(cve_id)
    return jsonify(data)
