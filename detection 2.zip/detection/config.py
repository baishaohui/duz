# -*- coding: utf-8 -*-


class Config:
    SECRET_KEY = "lK#UQWr%0YyJ"
    TOKEN = "807ce33038df2b3f"
    SCAN_URL = "http://116.62.132.146/"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_RECORD_QUERIES = True
    SQLALCHEMY_POOL_TIMEOUT = 300
    SQLALCHEMY_POOL_SIZE = 15
    SQLALCHEMY_POOL_RECYCLE = 300
    SQLALCHEMY_MAX_OVERFLOW = 100
    JSON_SORT_KEYS = False

    SCHEDULER_API_ENABLED = True
    # JOBS = [
    #     {
    #         "id": "job_interval",
    #         "func": test,
    #         "trigger": "interval",
    #         "seconds": 10
    #     }
    # ]

    def init_app(self):
        pass


class DevelopmentConfig(Config):
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = (
        "mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/scan_db"
    )
    SQLALCHEMY_BINDS = {
        'vul': "mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/vul_db",
        # "cpe": "sqlite:///db/cve.sqlite3"
    }


class ProductionConfig(Config):
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = (
        "mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/scan_db"
    )
    SQLALCHEMY_BINDS = {
        'vul': "mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/vul_db",
    }


config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': ProductionConfig
}
