# -*- coding: utf-8 -*-
import requests
import datetime
from urllib.parse import urljoin
from bs4 import BeautifulSoup as bs
from selenium.webdriver import PhantomJS


class WeChatMP(object):
    """微信公众号爬取"""
    def __init__(self, query):
        self.source = "http://weixin.sogou.com/weixin"
        self.query = query
        self.wxmp_link = None
        self.article_list = []

    def _make_search_soup(self, url=None, query=None):
        if url:
            response = requests.get(url, params=query)
        else:
            response = requests.get(self.source, params=query)
        sp = bs(response.text, "lxml")
        return sp

    def get_wxmp_link(self):
        query = {"query": self.query, "type": 1, "ie": "utf8", "s_from": "input"}
        soup = self._make_search_soup(query=query)
        link_tags = soup.select("#wrapper > #main .tit a")
        if link_tags:
            wxmp_link = link_tags[0]["href"]
            return wxmp_link.replace("amp;", "")

    @property
    def article_list_page(self):
        self.wxmp_link = self.get_wxmp_link()
        driver = PhantomJS()
        driver.get(self.wxmp_link)
        return driver.page_source

    def scan(self):
        soup = bs(self.article_list_page, "lxml")
        section = soup.select("#history")[0]
        item_list = section.find_all("div", "weui_msg_card")
        for item in item_list:
            title_link = item.find("h4", "weui_media_title")
            title = title_link.text.strip()
            link = title_link["hrefs"]
            date_str = item.find("p", "weui_media_extra_info").text.strip("原创")
            date = datetime.datetime.strptime(date_str, "%Y年%m月%d日").strftime("%Y-%m-%d")
            self.article_list.append({"title": title, "link": urljoin(self.wxmp_link, link),
                                      "pub_date": date, "source": self.source})
        print(self.article_list)


if __name__ == '__main__':
    obj = WeChatMP("玄武实验室")
    obj.scan()