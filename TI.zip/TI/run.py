# -*- coding: utf-8 -*-
import time, datetime
import schedule
from scheduler import Scheduler


if __name__ == '__main__':
    task = Scheduler()
    task.run_forever()
    print("beating...")
    schedule.every(60).seconds.do(task.run_forever)
    # 以秒为单位轮询任务
    while True:
        schedule.run_pending()
        time.sleep(1)