# -*- coding: utf-8 -*-
import datetime
from peewee import (
    MySQLDatabase, Model, CharField, AutoField, TextField, IntegerField, SmallIntegerField, BigIntegerField, DateTimeField)

from config import DB_CONFIG
db_config = DB_CONFIG.copy()

# vul_db, the db for vulnerability database
vul_db = db_config.pop("vul_db")

# ti_db, the db for ti
ti_db = db_config.pop("db")

db = MySQLDatabase(ti_db, **db_config)
db_ = MySQLDatabase(vul_db, **db_config)


class BaseModel(Model):

    class Meta:
        database = db


class InfoSource(BaseModel):
    id = AutoField()
    target = CharField(unique=True)
    script = CharField(null=True, default=None)
    type = IntegerField(default=0)
    reliable = SmallIntegerField(default=0)
    week = IntegerField()
    day = IntegerField()
    hour = IntegerField()
    minute = IntegerField()
    run_time = BigIntegerField()
    last_executed = DateTimeField(default=datetime.datetime.now)

    def __repr__(self):
        return f"<{self.target}>"

    def __str__(self):
        return self.target


class OriginModel(BaseModel):
    pass