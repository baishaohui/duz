# -*- coding: utf-8 -*-
"""
1. 检查数据库中有没有到期任务
2. 将任务push到任务队列中执行
3. 修改任务的执行时间，并计算出下次执行时间
"""
import datetime
from db import DBHandler
from db import db_con
from tasks import spider
from config import DOMAIN_FOR_SHORT


class Scheduler:

    def __init__(self):
        self.db = None
        self.initial = True
        self.domain = DOMAIN_FOR_SHORT

    def make_connection(self):
        self.db = db_con()

    def destroy_connection(self):
        if self.db:
            self.db = None

    def get_target(self, timestamp):
        """获取当前到达执行时间的任务"""
        self.make_connection()
        if self.initial:
            data = self.db.list(
                "info_source",
                ["`id`", "`target`", "`script`", "`type`", "`run_time`"],
                condition=self.condition
            )
            self.initial = False
        else:
            data = self.db.list(
                "info_source",
                ["`id`", "`target`", "`script`", "`type`", "`run_time`"],
                condition=self.condition + " and `run_time` between %s and %s" % (timestamp, timestamp + 60),
            )
        self.destroy_connection()
        return data

    @property
    def condition(self):
        if self.domain == "HK":
            return "`enable`=1 and `type`=2"
        else:
            return "`enable`=1 and `type` in (0, 1)"

    @staticmethod
    def item_handler(item):
        spider.delay(item.get("target"), item.get("type"), item.get("script"))

    def scan_tasks(self, timestamp):
        targets = self.get_target(timestamp)
        if targets:
            for item in targets:
                try:
                    self.item_handler(item)
                except Exception as e:
                    print(item, e)

    def run_forever(self):
        timestamp = int(datetime.datetime.now().timestamp())
        self.scan_tasks(timestamp)


if __name__ == '__main__':
    import time
    import schedule
    obj = Scheduler()
    schedule.every().minute.do(obj.run_forever)
    while True:
        time.sleep(1)
        schedule.run_pending()

