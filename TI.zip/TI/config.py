# -*- coding: utf-8 -*-
# THE INTERVAL OF INTELLIGENCE BY DAY
INTERVAL = 2
# ding-ding template
NON_INTELLEGENCE_WARNING = "暂未扫描到任何漏洞信息"
DING_TEMPLATE = {
    "msgtype": "markdown",
    "markdown": {
        "title": "漏洞情报",
        "text": NON_INTELLEGENCE_WARNING
    },
    "at": {

        "isAtAll": False
    }
}

DRIVER_EXECUTABLE_PATH = ""

USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv2.0.1) Gecko/20100101 Firefox/4.0.1"
# MySQL
DB_CONFIG = {
    "host": "rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com",
    "port": 5656,
    "user": "shaohui",
    "password": "gha96gzTK&jm#",
    "db": "ti_db",
    "vul_db": "vul_db"
}
# DB_CONFIG = {
#     "host": "47.97.46.232",
#     "port": 8443,
#     "user": "root",
#     "password": "!&akUfznGd",
#     "db": "ti_db_test",
# }
# MOBILE TEXT CONFIG
DYSMS_CONFIG = {
    "access_key": "LTAIMRRbHWFpJExa",
    "access_secret": "vXp3CPSi160RjBVD5GH9QSp5TxzTua",
    "region": "cn-hangzhou",
    "product_name": "Dysmsapi",
    "domain": "dysmsapi.aliyuncs.com",
    "template_code": "SMS_140726602"
}
# LOG LEVEL
LOG_LEVEL = "info"

# TIMEOUT OF REQUEST
TIMEOUT = 300
# THE DEFAULT INTERVAL FOR CRON JOB
DEFAULT_EXECUTE_INTERVAL = 30
# SHORT_URL = "https://api.weibo.com/2/short_url/shorten.json"
# SHORT_URL = "http://api.t.sina.com.cn/short_url/shorten.json"
# SHORT_URL = "http://api.suolink.cn/api.htm"
# SHORT_URL = "http://create.suolink.cn/pageHome/createByMulti.htm"
SHORT_URL = "http://www.mynb8.com/api2/urlcn"
APP_KEY = "ee02b42ef0c7f6345a1780bdffc4a04c"
# APP_KEY = "5d8c1fd58e676d74690e5656@73d8a93a1666709682e349faa995c88a"
# APP_KEY = "ee02b42ef0c7f6345a1780bdffc4a04c"
# SHORT_URL_SOURCE = "202088835"
SHORT_URL_SOURCE = "3271760578"
ACCESS_KEY_ID = "LTAI3EI5rmg8Kyvn"
ACCESS_KEY_SECRET = "Ql5US6HGeSjiGoRiXWDhtLKgcqtLnY"
NLP_REGION = 'cn-shanghai'
NLP_DOMAIN = "nlp.cn-shanghai.aliyuncs.com"
NLP_API_PATH = "/nlp/api/translate/general"


def get_host_ip():
    import socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
    finally:
        sock.close()
    return ip


HOST_IP = get_host_ip()
IP_MAPPING = {
    "47.91.196.40": "HK",
    # "192.168.31.242": "HK",
    "47.97.46.232": "ZH"
}
DOMAIN_FOR_SHORT = IP_MAPPING.get(HOST_IP)
