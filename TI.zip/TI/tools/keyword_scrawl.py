#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/8/7 下午3:26
# @Author  : Mr.White
vul_cat_url = "https://www.owasp.org/index.php/Category:Vulnerability"
att_cat_url = "https://www.owasp.org/index.php/Category:Attack"
import requests
import pymysql
from bs4 import BeautifulSoup as bs
tags = []
vul_res = requests.get(vul_cat_url)
att_res = requests.get(att_cat_url)
vul_bs = bs(vul_res.text, "lxml")
att_bs = bs(att_res.text, "lxml")
att_sub_tag = att_bs.find_all("a", "CategoryTreeLabel")
vul_sub_tag = vul_bs.find_all("a", "CategoryTreeLabel")
att_cat_tag = att_bs.select(".mw-category > .mw-category-group > ul > li > a")
vul_cat_tag = vul_bs.select(".mw-category > .mw-category-group > ul > li > a")
tags.extend([[tag.text] for tag in att_sub_tag])
tags.extend([[tag.text] for tag in vul_sub_tag])
tags.extend([[tag.text] for tag in att_cat_tag])
tags.extend([[tag.text] for tag in vul_cat_tag])
# print(len(tags))
print(tags)
# conn = pymysql.connect(host="localhost", port=3306, user="root", password="bsh890530", db="vul_sup")
sql = "insert into `keyword` (`word`) values (%s)"
# vales = ",".join(["(" + tag + ")" if tag else "" for tag in tags])
# print(vales)
from db import insert_data
# cur = pymysql.cursors.Cursor(conn)
insert_data(sql, tags)
# conn.commit()
# conn.close()