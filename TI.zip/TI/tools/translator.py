# -*- coding: utf8 -*-
import uuid
import json
from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.request import CommonRequest
from aliyunsdkcore.http import method_type
from config import ACCESS_KEY_ID, ACCESS_KEY_SECRET, NLP_REGION, NLP_DOMAIN, NLP_API_PATH


class Translator:
    client = AcsClient(ACCESS_KEY_ID, ACCESS_KEY_SECRET, NLP_REGION)

    def __init__(self):
        self.request = CommonRequest()
        self.request_initial()
        self._response = None
        self.response = None

    def request_initial(self):
        self.request.set_domain(NLP_DOMAIN)
        self.request.set_uri_pattern(NLP_API_PATH)
        self.request.set_method(method_type.POST)
        self.request.add_header("x-acs-signature-method", "HMAC-SHA1")
        self.request.add_header("x-acs-signature-nonce", uuid.uuid4().hex)
        self.request.add_header("x-acs-signature-version", "1.0")
        self.request.set_content_type("application/json;chrset=utf-8")
        self.request.set_accept_format("application/json;chrset=utf-8")
        self.request.set_version('2018-04-08')
        self.request.set_action_name("None")

    def _make_request(self):
        try:
            self._response = self.client.do_action_with_exception(self.request)
        except Exception as e:
            raise ValueError

    def set_text(self, text, source, target, format_type):
        if not isinstance(text, str):
            raise ValueError("Text takes strings only")
        text = {
            "q": text,
            "source": source,
            "target": target,
            "format": format_type
        }
        self.request.set_content(json.dumps(text))

    def translate(self, text, source="en", target="zh", format_type="text"):
        if not text:
            return ""
        self.set_text(text, source, target, format_type)
        self._make_request()
        if self._response:
            self.response = json.loads(str(self._response, "utf-8"))
            if isinstance(self.response, dict):
                return self.response.get("data").get("translated_text")


if __name__ == '__main__':
    obj = Translator()
    #     print(obj.translate("you are my sunshine"))
    #     print(obj.translate("asshole"))
    #     print(obj.translate("Privilege Escalation in gVisor, Google's Container Sandbox -- "))
    #     print(obj.translate(
    #         "OK I'm not sure how I missed this, but it's great – a collection of more than 300 vulnerabilities in Linux software, *with* test cases to reproduce and a VM environment with the right version of the software installed!"))
    #     print(obj.translate("""
    #     I uploaded the slides of my @roadsec Keynote “The Paradox of Choice - How to thrive in an industry with too many possibilities”:
    #
    # https://drive.google.com/file/d/13WrhoXUjH01bQ7W-vdOE0d95JxinI9HE/view?usp=drivesdk …
    #
    # More detailed blog posts about the topics I covered will follow in the upcoming days/weeks. 🖤
    #     """))
    print(obj.translate("Siemens 多个产品XML外部实体注入漏洞(CVE-2017-12069)"))
    print(obj.translate(
        "Vuln: Philips HealthSuite Health for Android CVE-2018-19001 Weak Encryption Local Security Weakness"))
    print(obj.translate("""
<p>USN-3239-1 fixed vulnerabilities in the GNU C Library. Unfortunately,
the fix for CVE-2016-3706 introduced a regression that in some
circumstances prevented IPv6 addresses from resolving. This update
reverts the change in Ubuntu 12.04 LTS. We apologize for the error.</p>
<p>Original advisory details:</p>
<p>It was discovered that the GNU C Library incorrectly handled the
 strxfrm() function. An attacker could use this issue to cause a denial
 of service or possibly execute arbitrary code. This issue only affected
 Ubuntu 12.04 LTS and Ubuntu 14.04 LTS. (CVE-2015-8982)</p>
<p>It was discovered that an integer overflow existed in the
 _IO_wstr_overflow() function of the GNU C Library. An attacker could
 use this to cause a denial of service or possibly execute arbitrary
 code. This issue only affected Ubuntu 12.04 LTS and Ubuntu 14.04
 LTS. (CVE-2015-8983)</p>
<p>It was discovered that the fnmatch() function in the GNU C Library
 did not properly handle certain malformed patterns. An attacker could
 use this to cause a denial of service. This issue only affected Ubuntu
 12.04 LTS and Ubuntu 14.04 LTS. (CVE-2015-8984)</p>
<p>Alexander Cherepanov discovered a stack-based buffer overflow in the
 glob implementation of the GNU C Library. An attacker could use this
 to specially craft a directory layout and cause a denial of service.
 (CVE-2016-1234)</p>
<p>Michael Petlan discovered an unbounded stack allocation in the
 getaddrinfo() function of the GNU C Library. An attacker could use
 this to cause a denial of service. (CVE-2016-3706)</p>
<p>Aldy Hernandez discovered an unbounded stack allocation in the sunrpc
 implementation in the GNU C Library. An attacker could use this to
 cause a denial of service. (CVE-2016-4429)</p>
<p>Tim Ruehsen discovered that the getaddrinfo() implementation in the
 GNU C Library did not properly track memory allocations. An attacker
 could use this to cause a denial of service. This issue only affected
 Ubuntu 16.04 LTS. (CVE-2016-5417)</p>
<p>Andreas Schwab discovered that the GNU C Library on ARM 32-bit
 platforms did not properly set up execution contexts. An attacker
 could use this to cause a denial of service. (CVE-2016-6323)</p>
    """, format_type="html"))
