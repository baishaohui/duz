#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/8/7 上午9:51
# @Author  : Mr.White

import datetime
from bs4 import BeautifulSoup as bs
from selenium.webdriver import PhantomJS
from selenium.webdriver import Chrome
from selenium.webdriver.chrome.options import Options
import requests

def getHtml(url):
    options = Options()
    options.add_argument("--headless")
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--disable-gpu')
    browser = Chrome(chrome_options=options)
    browser.set_page_load_timeout(300)
    browser.set_script_timeout(300)
    browser.get(url)
    return browser.page_source

# uid = "407361275"
import base64
import requests

# uin
# uin = base64.b64encode(bytes(uid, encoding="utf-8"))
# print(str(uin, encoding="utf-8"))
# print(uin)
# temp = "https://mp.weixin.qq.com/s?timestamp=1533698304&src=3&ver=1&signature=NR4PmgfOzQXX*6VtUesLHhQbtK9r2qxj3cj8*idQD3g8qrYVHkT11lNCn3Ld6TAQIXqlDm0zgHQn*NEJKAES4XMNZbGxV5zIkbpcr49cGffMH53gpQsOhPPhFT6hKviYJFEuVhKaRqfToh4gs4NtIzwKNbVGKAxGcgW04sfCr*E="

#
# def convert_to_permanent_url(temp_url):
#     pre_redirect_url = "".join([temp_url, "&uin=", str(uin, encoding="utf-8")])
#     print(pre_redirect_url)
#     response = requests.head(pre_redirect_url)
#     print(response.status_code)
#     # permanent_url = response.headers['Location']
#     # print(permanent_url)
#     # return permanent_url
# convert_to_permanent_url(temp)
page_info = getHtml("https://tools.cisco.com/security/center/publicationListing.x?product=Cisco&sort=-day_sir&offset=20#~Vulnerabilities")
print(page_info)
# soup = bs(page_info, 'lxml')
# section = soup.find("div", attrs={"class": "tableContent"})
# print(section.find_all("tbody"))
# item_list = section.find("div", attrs={"id": "tab1"})
# print(item_list)
# tp = soup.select("#history")
# item_list = tp[0].find_all("div", "weui_msg_card")
# for item in item_list:
#     obj = item.find("h4", "weui_media_title")
#     if obj:
#         title = obj.text.strip()
#         link = obj["hrefs"]
#         date_str = item.find("p", "weui_media_extra_info").text.strip("原创")
#         print(date_str)
#         date = datetime.datetime.strptime(date_str, "%Y年%m月%d日").strftime("%Y-%m-%d")
#         result.append({"title": title, "link": link, "pub_date": date})
# print(result)
