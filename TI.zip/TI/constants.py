# -*- coding: utf-8 -*-
from selenium.webdriver import (
    PhantomJS, Firefox, Chrome, FirefoxProfile,
    FirefoxOptions, ChromeOptions, DesiredCapabilities)
from selenium.common.exceptions import WebDriverException

from config import DRIVER_EXECUTABLE_PATH


# USER AGENTS LIST
USER_AGENTS = [
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv2.0.1) Gecko/20100101 Firefox/4.0.1",
        "Mozilla/5.0 (Windows NT 6.1; rv2.0.1) Gecko/20100101 Firefox/4.0.1",
        "Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; en) Presto/2.8.131 Version/11.11",
        "Opera/9.80 (Windows NT 6.1; U; en) Presto/2.8.131 Version/11.11",
        ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 "
         "(KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11")
]


def set_driver_profile():
    profile = FirefoxProfile()
    profile.set_preference("permissions.default.image", 2)
    # 禁用浏览器缓存
    profile.set_preference("network.http.use-cache", False)
    profile.set_preference("browser.cache.memory.enable", False)
    profile.set_preference("browser.cache.disk.enable", False)
    profile.set_preference("browser.cache.offline.enable", False)
    profile.set_preference("browser.sessionhistory.max_total_viewers", 3)
    profile.set_preference("network.dns.disableIPv6", True)
    profile.set_preference("Content.notify.interval", 750000)
    profile.set_preference("content.notify.backoffcount", 3)
    return profile


def set_driver_option():
    options = FirefoxOptions()
    options.add_argument('--headless')
    options.add_argument('--disable-gpu')
    return options

# Firefox preset
profile = set_driver_profile()
option = set_driver_option()

try:
    DRIVER = Firefox(options=option, firefox_profile=profile)
except WebDriverException:
    DRIVER = Firefox(
        executable_path=DRIVER_EXECUTABLE_PATH,
        options=option, firefox_profile=profile
    )
