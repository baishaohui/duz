# -*- coding: utf-8 -*-
import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_CONFIG = {
        "host": "47.97.46.232",
        # "host": "localhost",
        "port": 8443,
        "user": "root",
        "password": "!&akUfznGd",
        "db": "ti_db_test",
    }
# DB_CONFIG = {
#     "host": "rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com",
#     "port": 5656,
#     "user": "shaohui",
#     "password": "gha96gzTK&jm#",
#     "db": "ti_db",
# }
LOG_LEVEL = "info"

DING_TEMPLATE = {
    "msgtype": "markdown",
    "markdown": {
        "title": "漏洞情报",
        "text": "%s"
    },
    "at": {

        "isAtAll": False
    }
}
ACCESS_KEY_ID = "LTAI3EI5rmg8Kyvn"
ACCESS_KEY_SECRET = "Ql5US6HGeSjiGoRiXWDhtLKgcqtLnY"
NLP_REGION = 'cn-shanghai'
NLP_DOMAIN = "nlp.cn-shanghai.aliyuncs.com"
NLP_API_PATH = "/nlp/api/translate/standard"

class Config:
    BABEL_DEFAULT_LOCALE = 'zh'
    BABEL_DEFAULT_TIMEZONE = 'CST'
    SECRET_KEY = "mV5bHPJPDn7k"
    PER_PAGE = 30
    SCHEDULE_SECONDS = 5
    # Schduler config
    # JOBS = [
    #     {
    #         'id': 'monitor_job',
    #         'func': 'schedule:schedule_job',
    #         'args': None,
    #         'trigger': 'interval',
    #         'seconds': SCHEDULE_SECONDS
    #         # 'seconds': 1
    #     },
    #     {
    #         'id': 'remove_job',
    #         'func': 'schedule:check_tactic',
    #         'args': None,
    #         'trigger': 'interval',
    #         'seconds': SCHEDULE_SECONDS
    #     }
    # ]
    SQLALCHEMY_POOL_TIMEOUT = 300
    SQLALCHEMY_POOL_SIZE = 15
    SQLALCHEMY_POOL_RECYCLE = 300
    SCHEDULER_API_ENABLED = True


class DevelopmentConfig(Config):
    DEBUG = True
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/ti_db"
    # SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:!&akUfznGd@localhost/ti_db_test"   # local
    # SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:!&akUfznGd@47.97.46.232/ti_db_test"    #remote
    # DB_CONFIG = {
    #     "host": "rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com",
    #     "port": 5656,
    #     "user": "shaohui",
    #     "password": "gha96gzTK&jm#",
    #     "db": "ti_db",
    # }
    DB_CONFIG = {
            "host": "127.0.0.1",
            "port": 8443,
            "user": "root",
            # "password": "W6cO1G@YO36XYLva", # local
            "password": "!&akUfznGd",    # remote
            "db": "ti_db_test",
        }


class ProductConfig(Config):
    DEBUG = True
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://shaohui:gha96gzTK&jm#@rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com:5656/vul_db"
    # SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:W6cO1G@YO36XYLva@localhost:8443/ti_db_test"    # local
    # SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:!&akUfznGd@47.97.46.232:8443/ti_db_test"    # remote


config = {
    'development': DevelopmentConfig,
    'production': ProductConfig,
    'default': DevelopmentConfig
}
# W6cO1G@YO36XYLva