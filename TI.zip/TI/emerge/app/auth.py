# -*- coding: utf-8 -*-
import datetime
from flask import Blueprint
from flask import request
from flask import flash
from flask import render_template, redirect, url_for
from flask_login import login_user, logout_user
from .models import UserProfile
from .forms import LoginForm
auth = Blueprint("auth", __name__)


@auth.route('/login', methods=['GET', 'POST'])
def login():
    # Here we use a class of some kind to represent and validate our
    # client-side form data. For example, WTForms is a library that will
    # handle this for us, and we use a custom LoginForm to validate.
    form = LoginForm()
    if request.method == "POST":
        form = LoginForm(request.form)
        if form.validate_on_submit():
            # Login and validate the user.
            # user should be an instance of your `User` class
            user = UserProfile.query.filter_by(username=request.form.get("username")).first()
            if not user:
                flash("用户名不存在", "error")
                return render_template('login.html', form=form)
            if not user.check_password(request.form.get("password")):
                flash("用户名与密码不匹配")
                return render_template('login.html', form=form)
            login_user(user, remember=True, duration=datetime.timedelta(weeks=1))
            next_url = request.args.get('next')
            return redirect(next_url if next_url and next_url.startswith("/") else url_for("list.index"))
        else:
            return render_template("login.html", form=form)
    return render_template('login.html', form=form)


@auth.route("/logout", methods=["GET"])
def logout():
    logout_user()
    return redirect(url_for("list.index"))