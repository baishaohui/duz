# -*- coding: utf-8 -*-
from functools import wraps
import re
from flask import request
from flask_login import current_user
from flask import abort
PERMISSION_DICT = {
    "translator": {
        "allowed_app": ["advisory"],
        "allowed_endpoint": ["list.index", "list.advisory", "list.translate"]
    }
}


def permission_required(f):
    def decorated_function(*args, **kwargs):
        role_perm = PERMISSION_DICT.get(current_user.role, {})
        if current_user.is_admin or request.endpoint in role_perm.get("allowed_endpoint", []):
            return f(*args, **kwargs)
        abort(404)
    return decorated_function

