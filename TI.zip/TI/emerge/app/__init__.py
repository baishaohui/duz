# -*- coding: utf-8 -*-
import os
from flask import Flask, render_template
from .models import db
from .views import admin_dict, app_dict, permission_app
from config import DevelopmentConfig, ProductConfig
from app.views import bp
from app.auth import auth
from flask_apscheduler import APScheduler
from flask_bootstrap import Bootstrap
from flask_login import LoginManager
from flask_migrate import Migrate
from utils.json_encoder import JSONEncoder
from .template_filter import bool_to_icon, search_fields, xss


# def create_app(test_config=None):
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
static_dir = os.path.join(BASE_DIR, 'static')
templates_dir = os.path.join(BASE_DIR, 'templates')
app = Flask(__name__, instance_relative_config=True, static_folder=static_dir, template_folder=templates_dir)
# app.config.from_object("config")
app.config.from_object(ProductConfig)
schedule = APScheduler()
db.init_app(app)
app.register_blueprint(bp)
app.register_blueprint(auth)
Bootstrap(app)
Migrate(app, db)
app.json_encoder = JSONEncoder
app.add_template_global(admin_dict, "admin_dict")
app.add_template_global(app_dict, "app_dict")
app.add_template_global(permission_app, "permission_app")
app.add_template_filter(bool_to_icon, "bool_to_icon")
app.add_template_filter(search_fields, "search_fields")
app.add_template_filter(xss, "xss")
schedule.init_app(app)
schedule.start()


@app.errorhandler(404)
def page_not_found(e):
    status = 404
    error_title = "您要找的页面不存在！"
    return render_template("error_pages/40x.html", status=status, error_title=error_title), status