# -*- coding: utf-8 -*-
import re
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField, SelectField, BooleanField, PasswordField, IntegerField
from wtforms.validators import DataRequired, Length, InputRequired, ValidationError
from utils.db import date_time_choices
from .models import Config, UserProfile


class ConfigForm(FlaskForm):
    name = StringField("配置名", validators=[DataRequired("字段不能为空")], render_kw={"placeholder": "配置名"})
    host = StringField("主机名", validators=[DataRequired("字段不能为空")], render_kw={"placeholder": "主机名/IP"})
    port = IntegerField("端口号", validators=[DataRequired("字段不能为空, 且必须为数字"), ], render_kw={"placeholder": "端口"})
    user = StringField("用户名", validators=[DataRequired("字段不能为空")],
                       render_kw={"placeholder": "数据库用户名", "autocomplete": "off"})
    pwd = StringField("密码", validators=[DataRequired("字段不能为空")],
                      render_kw={"placeholder": "数据库密码", "autocomplete": "off"})
    db_name = StringField("数据库", validators=[DataRequired("字段不能为空")], render_kw={"placeholder": "数据库名"})
    submit = SubmitField("保存")

    def validate_port(self, field):
        data = field.data
        if int(data) > 65535 or int(data) < 0:
            raise ValidationError("端口号介于1—65535")


class TacticsForm(FlaskForm):
    name = StringField("名称", validators=[DataRequired("字段不能为空")], render_kw={"placeholder": "名称"})
    con_sql = TextAreaField("条件sql", default=None, render_kw={
        "placeholder": "以此字段的查询结果，作为sql语句的查询条件进行多重条件查询。可以为空，为空时直接对sql语句进行查询"
    })
    sql = TextAreaField("告警sql模板/sql语句", validators=[DataRequired("字段不能为空")], render_kw={
        "placeholder": """触发告警的sql语句。如果条件sql不为空，则以条件sql查询结果作为条件，sql模板格式：select * from table1
    where name='{name}' and age={age};条件sql为空时，此字段填写正常sql语句
        """
    })
    ding_robot = StringField("钉钉机器人", validators=[DataRequired("字段不能为空")], render_kw={"placeholder": "钉钉机器人链接"})
    ding_msg = TextAreaField("钉钉消息模板", render_kw={
        "placeholder": "消息格式举例：异常数据警告：{name}\n后台将渲染查询结果中的name字段至{name}变量。留空则发送默认模板。",
    })
    config_id = SelectField("对应配置",
                            validators=[DataRequired("请选择已存在配置")],
                            choices=(),
                            coerce=int,
                            render_kw={"placeholder": "请选择选项"})
    trigger = TextAreaField(
        "触发条件",
        render_kw={
            "placeholder": "格式示例：'a>10 and b<1 or c=\"your value\"', 其中a、b、c为查询结果的字段名称。若留空此字段，则查询结果不为空时触发"})
    job_type = SelectField("任务类型",
                           default="interval",
                           choices=(
                               ("cron", "cron"),
                               ("interval", "interval"),
                               # ("date", "date")
                           ))
    month = SelectField("月/月份", default=0, choices=(), render_kw={"placeholder": "月/月份"}, coerce=int)
    day = SelectField("天/日", default=1, choices=(), render_kw={"placeholder": "天/日"}, coerce=int)
    hour = SelectField("时/小时", default=0, choices=(), render_kw={"placeholder": "时/小时"}, coerce=int)
    minute = SelectField("分/分钟", default=0, choices=(), render_kw={"placeholder": "分/分钟"}, coerce=int)
    description = TextAreaField("描述", render_kw={"placeholder": "描述，可为空"})
    enable = BooleanField("启用", default="checked")
    submit = SubmitField("保存")

    def __init__(self, *args, **kwargs):
        super(TacticsForm, self).__init__(*args, **kwargs)
        self.config_id.choices = [(0, "请选择配置")] + [(obj.id, obj.name) for obj in Config.query.all()]
        self.month.choices = date_time_choices(13)
        self.day.choices = date_time_choices(32)
        self.hour.choices = date_time_choices(24)
        self.minute.choices = date_time_choices(60)

    def validate_con_sql(self, field):
        con = field.data
        if con:
            self.sql_validator(con)

    @staticmethod
    def sql_validator(data):
        error_msg = "只接收查询语句"
        if not (data.startswith("select") or data.startswith("SELECT")):
            raise ValidationError(error_msg)

    def validate_month(self, field):
        data = int(field.data)
        if data < 0 or data > 12:
            raise ValidationError("请选择1-12月，空值选0")

    def validate_day(self, field):
        data = int(field.data)
        month = self.month.data
        if month in [4, 6, 9, 11]:
            if data < 0 or data > 30:
                raise ValidationError("请选择1-30日，空值选0")
        elif month == 2:
            if data < 0 or data > 28:
                raise ValidationError("2月份请选1-28日，空值选0")
        else:
            if data < 0 or data > 31:
                raise ValidationError("请选择1-31日，空值选0")

    def validate_hour(self, field):
        data = int(field.data)
        if data < 0 or data > 24:
            raise ValidationError("请选择1-24小时，空值选0")

    def validate_minute(self, field):
        data = int(field.data)
        if data < 0 or data > 59:
            raise ValidationError("请选择1-59分钟，空值选0")


class LoginForm(FlaskForm):
    username = StringField("用户名",
                           validators=[DataRequired("请输入用户名"), Length(6, 24, message="请输入6到24个字符")],
                           render_kw={"placeholder": "用户名"})
    password = PasswordField("密码",
                             validators=[DataRequired(), Length(8, 64, message="请输入8到64个字符")],
                             render_kw={"placeholder": "密码"}
                             )
    submit = SubmitField("登录")
    
    # def validate_username(self, field):
    #     if UserProfile.query.filter_by(username=field.data).first():
    #         raise ValidationError("用户名已存在")


class KeywordForm(FlaskForm):
    word = StringField("关键词", validators=[
        DataRequired("字段不能为空"),
        Length(min=1, max=256, message="字段长度不可超过256字符")], render_kw={"placeholder": "关键词"})
    submit = SubmitField("保存")


class ClientForm(FlaskForm):
    name = StringField("名称", validators=[
        DataRequired("字段不能为空"),
        Length(min=1, max=256, message="字段长度不可超过256字符")], render_kw={"placeholder": "名称"})
    # mobile = StringField("手机号")
    ding_url = StringField("钉钉机器人", validators=[
        DataRequired("字段不能为空"),
        Length(min=1, max=256, message="字段长度不可超过256字符")], render_kw={"placeholder": "钉钉机器人链接"})
    active = BooleanField("启用", default=True)
    submit = SubmitField("保存")


class InfoSourceForm(FlaskForm):
    target = StringField("目标链接", validators=[
        DataRequired("字段不能为空"),
        Length(min=1, max=256, message="字段长度不可超过256字符")], render_kw={"placeholder": "目标url"})
    script = StringField("脚本名称", validators=[
        Length(min=0, max=256, message="字段长度不可超过256字符")], render_kw={"placeholder": "脚本名称"})
    type = SelectField("脚本类型", validators=[InputRequired()],
                       default=0, choices=[(0, "RSS"), (1, "爬虫脚本")], coerce=int)
    reliable = BooleanField("是否可靠来源", default=False)
    week = IntegerField("周", default=0)
    day = IntegerField("天", default=0)
    hour = IntegerField("小时", default=0)
    minute = IntegerField("分", default=0)
    # schedule_type = SelectField("周期类型", validators=[DataRequired("请选择类型")],
    #                             default=0, coerce=int, choices=[(0, "Interval"), (1, "Crontab")])
    enable = BooleanField("启用", default=True)
    submit = SubmitField("保存")


class RecordForm(FlaskForm):
    title = StringField("标题", validators=[
        DataRequired(), Length(min=1, max=128, message="字段最大长度为128字符")], render_kw={"placeholder": "标题"})
    link = StringField("链接", validators=[
        DataRequired(), Length(min=1, max=256, message="字段最大长度为256字符")], render_kw={"placeholder": "链接"})
    source = StringField("来源", validators=[
        DataRequired(), Length(min=1, max=256, message="字段最大长度为256字符")], render_kw={"placeholder": "来源"})
    submit = SubmitField("保存")


class AdvisoryForm(FlaskForm):
    translated_title = StringField("标题", validators=[DataRequired("标题不能为空")], render_kw={"placeholder": "公告标题"})
    translation = TextAreaField("翻译", validators=[DataRequired("翻译不能为空")], render_kw={"placeholder": "翻译内容"})
    submit = SubmitField("保存")


form_dict = {
    "config": ConfigForm,
    "tactics": TacticsForm,
    "keyword": KeywordForm,
    "client": ClientForm,
    "info_source": InfoSourceForm,
    "record": RecordForm
}
