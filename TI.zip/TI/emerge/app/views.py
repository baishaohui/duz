# -*- coding: utf-8 -*-
import datetime
from flask.templating import render_template
from flask import abort
from flask import request
from flask import redirect
from flask import url_for
from flask import jsonify
from flask.blueprints import Blueprint
from flask_login import login_required
from flask_login import current_user
from sqlalchemy import or_, and_
import pymysql

from .permission import permission_required, PERMISSION_DICT
from .models import Record, Client, Tactics, Config, Advisory, AffectRelease
from .forms import form_dict, AdvisoryForm
from .models import db
from .admin import site
from utils.reporter import send_msg, shorten_url
from config import DING_TEMPLATE

bp = Blueprint("list", __name__)
ADVISORY_DICT = {
    "redhat": 2,
    "ubuntu": 1
}


@bp.app_context_processor
def admin_dict():
    return site.admin_dict


@bp.app_context_processor
def permission_app():
    if current_user.is_authenticated:
        return PERMISSION_DICT.get(current_user.role, {})
    else:
        return {}


@bp.app_context_processor
def app_dict():
    return {
        # "TI": {"ch_name": "漏洞情报", "tables": ["keyword", "client", "info_source", "record"]},
        # "MMS": {"ch_name": "数据监控", "tables": ["config", "tactics"]},
        "advisory": {"ch_name": "Linux公告", "tables": ["vul_advisory", ]}
    }


@bp.route("/", endpoint="index")
@login_required
@permission_required
def index():
    # if current_user.role == "admin":
    #     return redirect(url_for("list.item_list", table_name="tactics"))
    # elif current_user.role == "translator":
    return redirect(url_for("list.advisory", a_type="redhat"))
    # abort(404)


@bp.route("/<string:table_name>", endpoint="item_list", methods=["GET", ])
@login_required
@permission_required
def item_list(table_name):
    admin_cls = site.admin_dict.get(table_name, "")
    if not admin_cls:
        abort(404)
    model = admin_cls.model
    title = model.comment + " - 列表"
    keyword = request.args.get("q")
    search_type = request.args.get("type", "")
    try:
        page = int(request.args.get("page", 1))
    except ValueError:
        page = 1
    order_by_fields = admin_cls.order_by_fields
    # order_condition = getattr(model, order_by_fields[0]) if order_by_fields else model.id
    # condition_obj = None
    query = model.query
    if table_name == "record":
        if search_type:
            condition_map = {
                "non_intel": and_(model.is_intelligence == False, model.analyzed == True),
                "is_intel": and_(model.is_intelligence == True, model.analyzed == True),
                "not_sent": model.analyzed == False,
                "has_sent": model.analyzed == True,
            }
            search_section = condition_map.get(search_type)
            query = query.filter(search_section)
    elif table_name == "advisory":
        if search_type:
            condition_map = {
                "not_translated": model.is_translated == False,
                "has_translated": model.is_translated == True,
            }
            search_section = condition_map.get(search_type)
            query = query.filter(search_section)
    if keyword:
        search_fields = admin_cls.search_fields
        condition = [getattr(model, field).ilike("%" + keyword + "%") for field in search_fields]
        condition_obj = or_(*condition)
        query = query.filter(condition_obj)
    total = query.count()
    query = query.order_by(model.id.desc() if hasattr(model, "id")
                           else model.pub_date.desc()).paginate(page, per_page=admin_cls.page_items, error_out=False)
    return render_template(
        "list.html",
        query_list=query.items,
        model=model,
        fields=model._sa_class_manager.values(),
        admin=admin_cls,
        pagination=query,
        q=keyword,
        title=title,
        total=total,
        current_section=search_type,
        search_type=search_type
    )


@bp.route("/<string:table_name>/add", endpoint="item_add", methods=["GET", "POST"])
@login_required
@permission_required
def item_add(table_name):
    form_cls = form_dict.get(table_name)
    if not form_cls:
        abort(404)
    admin = site.admin_dict.get(table_name)
    model = admin.model
    title = model.comment + " - 添加"
    if request.method == "GET":
        form = form_cls()
        return render_template("form.html", form=form, model=model, title=title)
    elif request.method == "POST":
        form = form_cls(request.form)
        if form.validate_on_submit():
            obj_dict = {}
            for field in form:
                if field.name in admin.form_fields:
                    if field.type == "BooleanField":
                        if request.form.get(field.name):
                            obj_dict[field.name] = True
                        else:
                            obj_dict[field.name] = False
                    elif field.type == "SubmitField":
                        continue
                    else:
                        obj_dict[field.name] = request.form.get(field.name)
                    if "last_update_time" in admin.form_fields:
                        obj_dict["last_update_time"] = datetime.datetime.now()
            new_obj = model(**obj_dict)
            db.session.add(new_obj)
            db.session.commit()
            return redirect(url_for("list.item_list", table_name=table_name))
        else:
            return render_template("form.html", form=form, model=model, title=title)


@bp.route("/<string:table_name>/<int:pk>", endpoint="item_update", methods=["GET", "POST"])
@login_required
@permission_required
def item_update(table_name, pk):
    admin = site.admin_dict.get(table_name)
    if not admin:
        abort(404)
    model = admin.model
    title = model.comment + " - 修改"
    form_cls = form_dict.get(table_name)
    if not form_cls:
        abort(404)
    query_obj = model.query.filter_by(id=pk).first_or_404()
    form = form_cls(obj=query_obj)
    if request.method == "GET":
        return render_template("form.html", form=form, model=model, title=title)
    elif request.method == "POST":
        form = form_cls(request.form)
        if form.validate_on_submit():
            obj_dict = {}
            for field in form:
                if field.name in admin.form_fields:
                    if field.type == "BooleanField":
                        if request.form.get(field.name):
                            obj_dict[field.name] = True
                        else:
                            obj_dict[field.name] = False
                    elif field.type == "SubmitField":
                        continue
                    else:
                        obj_dict[field.name] = request.form.get(field.name)
                    if "last_update_time" in admin.form_fields:
                        obj_dict["last_update_time"] = datetime.datetime.now()
            model.query.filter_by(id=pk).update(obj_dict)
            db.session.commit()
            return redirect(url_for("list.item_list", table_name=table_name))
        else:
            return render_template("form.html", form=form, model=model, title=title)


@bp.route("/<string:table_name>/del", endpoint="item_del", methods=["GET", "POST"])
@login_required
@permission_required
def item_del(table_name):
    admin = site.admin_dict.get(table_name)
    if not admin:
        abort(404)
    pk = request.form.get("pk") if request.method == "POST" else request.args.get("pk")
    model = admin.model
    query_obj = model.query.filter_by(id=pk).first_or_404()
    result = {"success": True}
    if request.method == "GET":
        result["data"] = query_obj.__repr__()
        return jsonify(result)
    try:
        db.session.delete(query_obj)
        db.session.commit()
        redirect_url = url_for("list.item_list", table_name=table_name)
        result["redirect"] = redirect_url
    except Exception as e:
        result["success"] = 0
        result["errorMsg"] = "删除失败"
    return jsonify(result)


@bp.route("/send/ding", endpoint="ding", methods=["POST"])
def send_ding():
    pk = request.form.get("pk")
    obj = Record.query.filter_by(id=pk).first_or_404()
    clients = Client.query.filter_by(active=True).all()
    if not obj.short_url:
        url = shorten_url(obj.link)
        if url:
            shorts, *_ = url
            if shorts:
                Record.query.filter_by(id=pk).update({"short_url": shorts.get("url_short")})
                db.session.commit()
    msg = "#### %s \n\n \1 \n\n[%s](%s)\n" % (
        obj.title.strip(),
        obj.short_url if obj.short_url else obj.link,
        obj.short_url if obj.short_url else obj.link
    )
    template = DING_TEMPLATE.copy()
    template["markdown"]["text"] = msg
    result = {"success": 1, }
    try:
        for client in clients:
            current_link = client.ding_url
            error_dict = send_msg(template, current_link)
            error_code = error_dict.get("errcode")
            if error_code != 0:
                raise ValueError(error_dict.get("errmsg"))
        Record.query.filter_by(id=pk).update(
            {"analyzed": True, "has_sent": True, "is_intelligence": True, "analyze_time": datetime.datetime.now()})
        db.session.commit()
        result["msg"] = "发送成功"
    except Exception as e:
        result["success"] = 0
        result["errorMsg"] = "钉钉消息发送失败，错误信息：%s" % e
    return jsonify(result)


@bp.route("/test/tactics", endpoint="test_tactics", methods=["POST"])
@login_required
@permission_required
def test_tactics():
    pk = request.form.get("pk")
    result = {"success": 1, }
    try:
        obj = Tactics.query.filter_by(id=pk).first_or_404()
        from schedule import task
        task(obj, obj.config)
        result["msg"] = "发送成功，让消息飞一会..."
    except Exception as e:
        result["success"] = 0
        result["errorMsg"] = "测试出错，错误信息：%s" % e
    return jsonify(result)


@bp.route("/test/config", endpoint="test_config", methods=["POST"])
@login_required
@permission_required
def test_config():
    result = {"success": 1}
    try:
        obj = Config.query.filter_by(id=request.form.get("pk")).first_or_404()
        con = pymysql.connect(
            host=obj.host,
            port=obj.port,
            user=obj.user,
            password=obj.pwd,
            db=obj.db_name,
            charset="utf8",
            cursorclass=pymysql.cursors.SSDictCursor
        )
        with con.cursor(pymysql.cursors.DictCursor) as cur:
            cur.execute("select sysdate() as cur_time from dual")
            data = cur.fetchone()
            cur_time = data.get("cur_time")
            result["msg"] = "连接成功！服务器返回时间：%s" % cur_time.strftime("%Y-%m-%d %H:%M:%S")
    except Exception as e:
        result["success"] = 0
        result["errorMsg"] = "连接出错，错误信息：%s" % e
    return jsonify(result)


@bp.route("/advisory/<string:aid>/translate", endpoint="translate", methods=["GET", "POST"])
@login_required
@permission_required
def advisory_translate(aid):
    admin_cls = site.admin_dict.get("vul_advisory")
    obj = Advisory.query.filter_by(aid=aid).first_or_404()
    form = AdvisoryForm(obj=obj)
    if request.method == "POST":
        form = AdvisoryForm(request.form)
        if form.validate_on_submit():
            translation = request.form.get("translation")
            translated_title = request.form.get("translated_title")
            obj.translation = translation
            obj.translated_title = translated_title
            obj.is_translated = True
            db.session.commit()
            if obj.advisory_type == 1:
                a_type = "ubuntu"
            else:
                a_type = "redhat"
            return redirect(url_for("list.advisory", a_type=a_type) + "?type=not_translated")
    return render_template("translate.html", form=form, advisory=obj, model=admin_cls.model)


@bp.route("/advisory/<string:a_type>", endpoint="advisory", methods=["GET"])
@login_required
@permission_required
def advisory_display(a_type):
    if not ADVISORY_DICT.get(a_type):
        abort(404)
    admin = site.admin_dict.get("vul_advisory", {})
    title = a_type.strip() + " - 公告信息"
    model = admin.model
    query = model.query.filter_by(advisory_type=ADVISORY_DICT.get(a_type))
    if a_type == "ubuntu":
        version_list = ["ubuntu 16.04", "ubuntu 14.04 lts"]
        query = query.filter(or_(*[model.affect_versions.contains(version) for version in version_list]))
    keyword = request.args.get("q", "")
    search = request.args.get("type", "")
    try:
        page = int(request.args.get("page", 1))
    except ValueError:
        page = 1
    if keyword:
        condition = [getattr(model, field).ilike("%" + keyword.strip() + "%") for field in admin.search_fields]
        condition_obj = or_(*condition)
        query = query.filter(condition_obj)
    if search:
        condition_map = {
            "not_translated": model.is_translated == False,
            "has_translated": model.is_translated == True,
        }
        search_section = condition_map.get(search.strip())
        query = query.filter(search_section)
    total = query.count()
    query = query.order_by(model.pub_date.desc()).paginate(page, per_page=admin.page_items, error_out=False)
    return render_template(
        "list.html",
        query_list=query.items,
        model=model,
        fields=model._sa_class_manager.values(),
        admin=admin,
        pagination=query,
        q=keyword,
        title=title,
        total=total,
        current_section=search,
        search_type=search,
        a_type=a_type
    )
