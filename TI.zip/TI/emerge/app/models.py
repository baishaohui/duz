# -*- coding: utf-8 -*-
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class Config(db.Model):
    __tablename__ = "config"
    __public__ = ["name", "host", "user", "db_name"]
    id = db.Column(db.Integer, primary_key=True, comment="编号")
    name = db.Column(db.String(128), nullable=False, index=True, comment="名称")
    description = db.Column(db.Text(2048), nullable=True, comment="描述")
    add_time = db.Column(db.DateTime(), nullable=True, default=datetime.now, comment="生成时间")
    host = db.Column(db.String(256), nullable=False, comment="主机/IP")
    port = db.Column(db.Integer, nullable=False, default=3306, comment="端口")
    user = db.Column(db.String(128), nullable=False, comment="用户名")
    pwd = db.Column(db.String(256), nullable=False, comment="密码")
    db_name = db.Column(db.String(64), nullable=True, comment="数据库名")
    tactic = db.relationship("Tactics", backref="config", lazy="dynamic")
    comment = "数据库配置"

    def __init__(self, name, host, user, pwd, db_name, port):
        self.name = name
        self.host = host
        self.user = user
        self.pwd = pwd
        self.port = port
        self.db_name = db_name

    def __repr__(self):
        return self.name

    def to_dict(self):
        obj_dict = {}
        for i, j in self._sa_instance_state.attrs.items():
            if i in self.__public__:
                obj_dict[i] = j.value
        return obj_dict


class Tactics(db.Model):
    __tablename__ = "tactics"
    __public__ = ["name", "description", "sql", "enable", "ding_url", "config_id"]
    id = db.Column(db.Integer, primary_key=True, comment="编号")
    name = db.Column(db.String(128), nullable=False, index=True, comment="名称")
    description = db.Column(db.Text(2048), nullable=True, comment="描述")
    add_time = db.Column(db.DateTime(), nullable=True, default=datetime.now, comment="生成时间")
    last_update_time = db.Column(db.DateTime(), nullable=True, default=datetime.now, comment="上次更改时间")
    con_sql = db.Column(db.Text, nullable=True, comment="条件sql")
    sql = db.Column(db.Text, nullable=False, comment="sql语句")
    enable = db.Column(db.Boolean, default=True, nullable=False, comment="启用")
    ding_robot = db.Column(db.String(256), comment="钉钉机器人链接")
    ding_msg = db.Column(db.Text(512), nullable=True, default="", comment="钉钉消息内容")
    trigger = db.Column(db.Text(2048), nullable=True, comment="触发条件")
    config_id = db.Column(db.Integer, db.ForeignKey("config.id"), comment="配置")
    last_notify_time = db.Column(db.DateTime(), nullable=True, default=datetime.now, comment="上次通知时间")
    job_type = db.Column(db.String(128), default="interval", nullable=False, comment="任务类型(crontab/interval/date)")
    month = db.Column(db.Integer, default=0, comment="月/月份")
    day = db.Column(db.Integer, default=1, comment="天/日")
    hour = db.Column(db.Integer, default=0, comment="时/小时")
    minute = db.Column(db.Integer, default=0, comment="分/分钟")
    comment = "钉钉消息配置"

    def __init__(self, enable=True, job_type="interval", *args, **kwargs):
        self.name = kwargs.get("name")
        self.con_sql = kwargs.get("con_sql")
        self.sql = kwargs.get("sql")
        self.ding_robot = kwargs.get("ding_robot")
        self.ding_msg = kwargs.get("ding_msg")
        self.config_id = kwargs.get("config_id")
        self.description = kwargs.get("description")
        self.trigger = kwargs.get("trigger")
        self.month = kwargs.get("month")
        self.day = kwargs.get("day")
        self.hour = kwargs.get("hour")
        self.minute = kwargs.get("minute")
        self.enable = enable
        self.job_type = job_type
        self.last_update_time = kwargs.get("last_update_time")

    def __repr__(self):
        return self.name

    def to_dict(self):
        obj_dict = {}
        for i, j in self._sa_instance_state.attrs.items():
            if i in self.__public__:
                obj_dict[i] = j.value
        return obj_dict


class UserProfile(UserMixin, db.Model):
    __tablename__ = "vul_user"
    id = db.Column(db.Integer, primary_key=True, comment="编号")
    username = db.Column(db.String(24), unique=True, nullable=False, index=True, comment="用户名")
    _password = db.Column(db.String(128), unique=True, nullable=False, index=True, comment="密码")
    role = db.Column(db.Enum("admin", "translator"), nullable=False, )

    def __init__(self, name, password, role="admin"):
        self.username = name
        self.password = password
        self.role = role

    def __repr__(self):
        return self.username

    @property
    def password(self):
        return self._password

    @password.setter
    def password(self, raw_pass):
        self._password = generate_password_hash(raw_pass)

    def check_password(self, raw_pass):
        return check_password_hash(self.password, raw_pass)
    
    @property
    def is_admin(self):
        if self.role == "admin":
            return True


class Keyword(db.Model):
    __tablename__ = "keyword"
    __public__ = ["word"]
    id = db.Column(db.Integer, primary_key=True, comment="编号")
    word = db.Column(db.String(256), comment="关键词")
    comment = "关键词"

    def __init__(self, word):
        self.word = word

    def __repr__(self):
        return self.word

    def to_dict(self):
        obj_dict = {}
        for i, j in self._sa_instance_state.attrs.items():
            if i in self.__public__:
                obj_dict[i] = j.value
        return obj_dict


class Client(db.Model):
    __tablename__ = "client"
    __public__ = ["name", "ding_url", "active"]
    id = db.Column(db.Integer, primary_key=True, comment="编号")
    name = db.Column(db.String(256), index=True, comment="名称")
    mobile = db.Column(db.Integer, nullable=True, comment="手机号")
    ding_url = db.Column(db.String(256), nullable=True, comment="钉钉机器人链接")
    email = db.Column(db.String(128), nullable=True, comment="邮箱")
    active = db.Column(db.Boolean, default=True, comment="可用")
    comment = "消息配置"

    def __init__(self, name, ding_url, mobile=None, email=None, active=True):
        self.name = name
        self.mobile = mobile
        self.ding_url = ding_url
        self.email = email
        self.active = active

    def __repr__(self):
        return self.name

    def to_dict(self):
        obj_dict = {}
        for i, j in self._sa_instance_state.attrs.items():
            if i in self.__public__:
                obj_dict[i] = j.value
        return obj_dict


class InfoSource(db.Model):
    __tablename__ = "info_source"
    __public__ = ["target", "script", "type", "need_filter", "week", "day", "hour", "minute", "schedule_type",
                  "run_time", "enable"]
    id = db.Column(db.Integer, primary_key=True, comment="编号")
    target = db.Column(db.String(256), comment="目标链接")
    script = db.Column(db.String(256), comment="脚本文件名")
    type = db.Column(db.SmallInteger, default=1, comment="脚本类型")
    reliable = db.Column(db.Boolean, default=True, comment="可信来源")
    week = db.Column(db.Integer, default=0, comment="周")
    day = db.Column(db.Integer, default=0, comment="天")
    hour = db.Column(db.Integer, default=0, comment="小时")
    minute = db.Column(db.Integer, default=0, comment="分钟")
    schedule_type = db.Column(db.SmallInteger, default=0, comment="任务类型")
    run_time = db.Column(db.BigInteger, default=0, comment="任务执行时间")
    last_executed = db.Column(db.TIMESTAMP, default=None, nullable=True, comment="上次执行时间")
    enable = db.Column(db.Boolean, default=True, comment="启用")
    comment = "情报来源"

    def __init__(self, target, script, reliable=True, week=0, day=0, hour=0, minute=0, source_type=0, enable=True):
        self.target = target
        self.script = script
        self.type = source_type
        self.reliable = reliable
        self.week = week
        self.day = day
        self.hour = hour
        self.minute = minute

    def __repr__(self):
        return self.target

    def to_dict(self):
        obj_dict = {}
        for i, j in self._sa_instance_state.attrs.items():
            if i in self.__public__:
                obj_dict[i] = j.value
        return obj_dict


class Record(db.Model):
    __tablename__ = "record"
    __public__ = ["title", "link", "source", "pub_date", "has_sent", "is_intelligence", "analyzed"]
    id = db.Column(db.Integer, primary_key=True, comment="编号")
    title = db.Column(db.String(128), comment="标题")
    translation = db.Column(db.String(512), nullable=True, default=None, comment="翻译")
    link = db.Column(db.String(256), comment="链接")
    summary = db.Column(db.Text, nullable=True, comment="详情")
    source = db.Column(db.String(256), comment="来源")
    type = db.Column(db.Boolean, default=False, nullable=False, comment="类型")
    pub_date = db.Column(db.Date, default=None, nullable=True, comment="发布日期")
    record_time = db.Column(db.TIMESTAMP, nullable=False, comment="记录时间")
    has_sent = db.Column(db.Boolean, default=False, comment="已发送")
    is_intelligence = db.Column(db.Boolean, default=False, comment="是否情报")
    analyze_time = db.Column(db.DateTime, nullable=True, default=None, comment="分析时间")
    analyzed = db.Column(db.Boolean, default=False, comment="已分析")
    short_url = db.Column(db.String(20), nullable=True, default=None, comment="短链接")
    tweet_id = db.Column(db.String(128), nullable=True, default=None, comment="推特id")
    comment = "情报记录"

    def __init__(self, title, link, source, short_url=None, translation=None):
        self.title = title
        self.link = link
        self.source = source
        self.short_url = short_url
        self.translation = translation

    def __repr__(self):
        return self.title

    def to_dict(self):
        obj_dict = {}
        for i, j in self._sa_instance_state.attrs.items():
            if i in self.__public__:
                obj_dict[i] = j.value
        return obj_dict


class Advisory(db.Model):
    __tablename__ = "vul_advisory"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True, comment="id标识")
    aid = db.Column(db.String(24), index=True, unique=True, comment="公告标识")
    title = db.Column(db.String(256), nullable=False, comment="原标题")
    translated_title = db.Column(db.String(256), default="", nullable=False, comment="翻译标题")
    link = db.Column(db.String(256), nullable=False, comment="链接")
    advisory_body = db.Column(db.Text, nullable=True, comment="通告内容")
    description = db.Column(db.Text, nullable=True, comment="详细信息")
    translation = db.Column(db.Text, nullable=True, comment="详情译文")
    cves = db.Column(db.Text, nullable=True, comment="相关CVE")
    affect_versions = db.Column(db.Text, nullable=True, comment="影响版本")
    pub_date = db.Column(db.Date(), nullable=False, comment="发布时间")
    record_time = db.Column(db.DateTime, default=datetime.now(), comment="记录时间")
    is_translated = db.Column(db.Boolean, default=False, comment="审核状态")
    advisory_type = db.Column(db.SmallInteger, default=1, comment="公告类型")
    comment = "公告信息"

    def __init__(self, aid, title, link, pub_date, advisory="", description="", translation="", advisory_type=1,
                 translated_title="", cves="", is_translated=False):
        self.aid = aid
        self.title = title
        self.link = link
        self.pub_date = pub_date
        self.advisory = advisory
        self.description = description
        self.translation = translation
        self.advisory_type = advisory_type
        self.translated_title = translated_title
        self.is_translated = is_translated
        self.cves = cves

    def __repr__(self):
        return self.title

    def to_dict(self):
        obj_dict = {}
        for i, j in self._sa_instance_state.attrs.items():
            if i in self.__public__:
                obj_dict[i] = j.value
        return obj_dict


class AffectRelease(db.Model):
    __tablename__ = "affect_release"
    id = db.Column(db.Integer, primary_key=True, comment="唯一标识")
    aid = db.Column(db.String(64), index=True, comment="公告标识")
    type = db.Column(db.String(1048), nullable=True, comment="影响版本")
    cves = db.Column(db.String(2000), nullable=True, comment="相关CVE")
    
    