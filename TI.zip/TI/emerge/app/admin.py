# -*- coding: utf-8 -*-
from .models import (Config, Tactics, Keyword, Client, InfoSource, Record, Advisory)


class BaseAdmin:
    display_fields = []
    search_fields = []
    search_sections = {"": "全部"}
    form_fields = []
    order_by_fields = []
    page_items = 30
    form_exclude_fields = []
    allow_edit = True
    allow_add = True
    allow_del = True


class Site:

    def __init__(self, name="admin"):
        self.name = name
        self.admin_dict = {}

    def register(self, model_cls, admin_cls=None):
        if not admin_cls:
            admin_cls = BaseAdmin()
        admin_cls.model = model_cls
        if model_cls.__tablename__ not in self.admin_dict:
            self.admin_dict[model_cls.__tablename__] = admin_cls
        # else:
        #     self.admin_dict[model_cls.__tablename__].append(admin_cls)


class ConfigAdmin(BaseAdmin):
    display_fields = ["name", "host", "port", "user", "db_name", "add_time"]
    search_fields = ["name", "host"]
    form_fields = ["name", "host", "port", "user", "db_name", "pwd"]
    order_by_fields = ["add_time"]


class TacticsAdmin(BaseAdmin):
    display_fields = ["name", "description", "sql", "enable", "last_update_time", "ding_robot", "config_id", "month",
                      "day", "hour", "minute"]
    search_fields = ["name", "description", "sql", "ding_robot"]
    form_fields = ["name", "con_sql", "sql", "ding_robot", "config_id", "job_type", "enable", "trigger", "description",
                   "month",
                   "day", "hour", "minute", "last_update_time", "ding_msg"]
    order_by_fields = ["add_time"]


class KeywordAdmin(BaseAdmin):
    display_fields = ["word"]
    search_fields = ["word"]
    form_fields = ["word"]
    order_by_fields = ["word"]


class ClientAdmin(BaseAdmin):
    display_fields = ["name", "ding_url", "active"]
    search_fields = ["name", "ding_url"]
    form_fields = ["name", "ding_url", "active"]
    order_by_fields = []


class InfoSourceAdmin(BaseAdmin):
    display_fields = [
        "target", "script", "type", "need_filter", "week", "day", "hour", "minute", "schedule_type", "run_time",
        "enable"
    ]
    search_fields = ["script", "target"]
    form_fields = ["target", "script", "type", "reliable", "week", "day", "hour", "minute", "enable"]
    # order_by_fields = ["pub_date"]


class RecordAdmin(BaseAdmin):
    display_fields = ["title", "link", "source", "pub_date", "has_sent", "is_intelligence", "analyzed"]
    search_fields = ["title", "link", "source"]
    search_sections = {"": "全部", "has_sent": "已分析", "not_sent": "未分析", "is_intel": "情报", "non_intel": "非情报"}
    form_fields = ["title", "link", "source"]
    order_by_fields = ["pub_date"]


class AdvisoryAdmin(BaseAdmin):
    display_fields = ["title", "translated_title", "link", "pub_date", "is_translated"]
    search_fields = ["aid", "title", "link"]
    search_sections = {"": "全部", "has_translated": "已翻译", "not_translated": "未翻译"}
    form_fields = ["title", "link", "is_translated"]
    order_by_fields = ["pub_date"]
    allow_edit = False
    allow_add = False
    allow_del = False


site = Site()
# site.register(Config, ConfigAdmin)
# site.register(Tactics, TacticsAdmin)
# site.register(Keyword, KeywordAdmin)
# site.register(Client, ClientAdmin)
# site.register(InfoSource, InfoSourceAdmin)
# site.register(Record, RecordAdmin)
site.register(Advisory, AdvisoryAdmin)
