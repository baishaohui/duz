# -*- coding: utf-8 -*-
from flask import request
from bleach.sanitizer import Cleaner

TAGS = ['a', 'abbr', 'acronym', 'b', 'blockquote', 'code', 'em', 'i', 'li', 'ol', 'strong', 'ul']
TAGS.extend(
    ["div", "p", "hr", "br", "pre", "code", "span", "h1", "h2", "h3", "h4", "h5", "h6", "del", "dl", "table", "thead",
     "tr", "td", "tbody", "dd", "blockquote", "section"])
STYLES = ["color", "font", "font-size", "font-weight"]
ATTRIBUTES = {"*": ["class", "id", "style"], "a": ["href", "title", "target"],
              "img": ["src", "style", "width", "height"]}
cleaner = Cleaner(tags=TAGS, attributes=ATTRIBUTES, styles=STYLES)

def bool_to_icon(value):
    if isinstance(value, bool):
        if value is True:
            return '<i class="fa fa-check text-success"></i>'
        else:
            return '<i class="fa fa-remove text-red"></i>'
    elif isinstance(value, str):
        if value.startswith("http"):
            value = "<a href='{0}' target='_blank'>{0}</a>".format(value)
    else:
        if value is None:
            value = ""
    return value


def search_fields(admin):
    fields = []
    for field in admin.model._sa_class_manager.attributes:
        if field.key in admin.search_fields:
            fields.append(field.comment)
    return "，".join(fields)


def xss(html):
    if html:
        return cleaner.clean(html)
    return html
