# -*- coding: utf-8 -*-
import re
n = "num < 1 and title='aaa' a<=55 and b!=55 sdfasdf"
p = re.compile("\w+\s+(=)\s+\w+")
pattern = re.compile("\w+\s*(=)\s*['|\"]?\w+['|\"]?")
# m = re.findall(pattern, n)
# m = re.match(pattern, n)
print(re.match(pattern, n))
m = re.sub(pattern, lambda x: x.group().replace("=", "=="), n)
# m = re.findall("\w+\s*=+\s*(\w+)", n)
# m = re.sub(, "==", n)
print(m)