from flask_login import LoginManager
# from app import create_app
from app import app
from app.models import UserProfile
# app = create_app()
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "auth.login"
login_manager.session_protection = "strong"
login_manager.login_message = "请先登录"
login_manager.login_message_category = "info"


@login_manager.user_loader
def load_user(user_id):
    return UserProfile.query.get(user_id)


if __name__ == '__main__':
    app.run(use_reloader=False)


