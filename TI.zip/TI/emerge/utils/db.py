# -*- coding: utf-8 -*-
import pymysql
from config import DB_CONFIG
from utils.logger import LogUtil


class DBHandler:

    # def __new__(cls, *args, **kwargs):
    #     if not hasattr(cls, "instance"):
    #         cls.instance = super(DBHandler, cls).__new__(cls)
    #         return cls.instance

    def __init__(self, host, port, user, password, db, charset="utf8"):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.db = db
        self.charset = charset
        self.connection = self.make_connection()
        self.logger = LogUtil(__name__, "log/db_error.log")

    def __del__(self):
        if self.connection:
            self.connection.close()

    def make_connection(self):
        connection = pymysql.connect(
            host=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
            db=self.db,
            charset=self.charset,
            cursorclass=pymysql.cursors.DictCursor
        )
        return connection

    def execute(self, sql, params=None, select=False, single=False):
        with self.connection.cursor(pymysql.cursors.DictCursor) as cur:
            cur = pymysql.cursors.DictCursor(self.connection)
            try:
                cur.execute(sql, params)
                if not select:
                    self.connection.commit()
                else:
                    if single:
                        return cur.fetchone()
                    return cur.fetchall()
            except Exception as e:
                self.connection.rollback()
                print("execute error", sql, params, e)

    def retrieve(self, table, fields, condition=None):
        sql = "select {fields} from {table} where {condition}".format(
            table=table,
            fields=fields if isinstance(fields, str) else ",".join(fields),
            condition=self.__condition_formater(condition)
        )
        data = self.execute(
            sql,
            params=tuple(condition.values()) if isinstance(condition, dict) else None,
            select=True,
            single=True
        )
        return data

    def list(self, table, fields, condition=None):
        """根据查询条件获取批量数据"""
        sql = "select {fields} from {table} where {condition}".format(
            table=table,
            fields=fields if isinstance(fields, str) else ",".join(fields),
            condition=self.__condition_formater(condition)
        )
        data = self.execute(
            sql,
            params=tuple(condition.values()) if isinstance(condition, dict) else tuple(),
            select=True
        )
        return data

    def count(self, table, condition=None):
        sql = "select count(1) from {table} where {condition}".format(
            table=table,
            condition=self.__condition_formater(condition)
        )
        data = self.execute(sql, params=tuple(condition.values()) if isinstance(condition, dict) else None, select=True)
        return data[0].get("count(1)") if data else 0

    def create(self, table, data):
        """添加数据"""
        if data:
            params = tuple(data.values())
            sql = "insert into {table} ({fields}) values ({value})".format(
                table=table, fields=",".join(tuple(data.keys())), value=self.__value_formater(data))
            self.execute(sql, params=params)

    def update(self, table, data, condition=None):
        """更新数据"""
        if data:
            params = list(data.values())
            sql = "update {table} set {value} where {condition}".format(
                table=table,
                value=self.__update_formater(data),
                condition=self.__condition_formater(condition)
            )
            if condition and not isinstance(condition, str):
                params.extend(list(condition.values()))
            self.execute(sql, params=params)

    @staticmethod
    def __update_formater(data):
        query = []
        for item in data.keys():
            query.append("{}=%s".format(item))
        return ",".join(query)

    @staticmethod
    def __value_formater(values):
        return ",".join(["%s"] * len(values))

    @staticmethod
    def __condition_formater(condition):
        if not condition:
            return "1=1"
        else:
            # where a=%s and b=%s and c=%s
            return condition.strip("\n") if isinstance(condition, str) else " and ".join(
                ["{field}=%s".format(field=field) for field in condition.keys()]
            )

    def delete(self, table, condition=None):
        """删除数据"""
        sql = "delete from {table} where {condition}".format(table=table,
                                                             condition=self.__condition_formater(condition))
        self.execute(sql, params=tuple(condition.values()) if condition else condition)


def db_con():
    db = DBHandler(
        DB_CONFIG.get("host"),
        DB_CONFIG.get("port"),
        DB_CONFIG.get("user"),
        DB_CONFIG.get("password"),
        DB_CONFIG.get("db")
    )
    return db


def get_choices(table_name, fields):
    db = db_con()
    result = db.list(table_name, fields)
    choices = [(0, "请选择对应配置"), ]
    if result:
        choices.extend([(i.get("id"), i.get("name")) for i in result])
    return choices


def date_time_choices(end, start=0):
    return ((i, i) for i in range(start, end))


if __name__ == '__main__':
    db = db_con()

