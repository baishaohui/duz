# -*- coding: utf-8 -*-
import os
from utils.logger import LogUtil

obj = LogUtil("task_error", file_name=os.path.join("..", "error", "task.log"))
logger = obj.get_logger()
logger.error("report 测试")