# -*- coding: utf8 -*-
import uuid
import json
from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.request import CommonRequest
from aliyunsdkcore.http import method_type
from config import ACCESS_KEY_ID, ACCESS_KEY_SECRET, NLP_REGION, NLP_DOMAIN, NLP_API_PATH


class Translator:
    client = AcsClient(ACCESS_KEY_ID, ACCESS_KEY_SECRET, NLP_REGION)

    def __init__(self):
        self.request = CommonRequest()
        self.request_initial()
        self._response = None
        self.response = None

    def request_initial(self):
        self.request.set_domain(NLP_DOMAIN)
        self.request.set_uri_pattern(NLP_API_PATH)
        self.request.set_method(method_type.POST)
        self.request.add_header("x-acs-signature-method", "HMAC-SHA1")
        self.request.add_header("x-acs-signature-nonce", uuid.uuid4().hex)
        self.request.add_header("x-acs-signature-version", "1.0")
        self.request.set_content_type("application/json;chrset=utf-8")
        self.request.set_accept_format("application/json;chrset=utf-8")
        self.request.set_version('2018-04-08')
        self.request.set_action_name("None")

    def _make_request(self):
        try:
            self._response = self.client.do_action_with_exception(self.request)
        except Exception as e:
            print(e)
            pass

    def set_text(self, text, source, target, format_type="text"):
        if not isinstance(text, str):
            raise ValueError("Text takes strings only")
        text = {
            "q": text,
            "source": source,
            "target": target,
            "format": format_type
        }
        self.request.set_content(json.dumps(text))

    def translate(self, text, source="en", target="zh"):
        if not text:
            return ""
        self.set_text(text, source, target)
        self._make_request()
        if self._response:
            self.response = json.loads(str(self._response, "utf-8"))
            if isinstance(self.response, dict):
                return self.response.get("data").get("translated_text")


if __name__ == '__main__':
    obj = Translator()
    print(obj.translate("you are my sunshine"))
    print(obj.translate("asshole"))
    print(obj.translate("Privilege Escalation in gVisor, Google's Container Sandbox -- "))
    print(obj.translate(
        "OK I'm not sure how I missed this, but it's great – a collection of more than 300 vulnerabilities in Linux software, *with* test cases to reproduce and a VM environment with the right version of the software installed!"))
    print(obj.translate("""
    I uploaded the slides of my @roadsec Keynote “The Paradox of Choice - How to thrive in an industry with too many possibilities”: 

https://drive.google.com/file/d/13WrhoXUjH01bQ7W-vdOE0d95JxinI9HE/view?usp=drivesdk …

More detailed blog posts about the topics I covered will follow in the upcoming days/weeks. 🖤
    """))
