# -*- coding: utf-8 -*-
import os
import json
import pymysql
import datetime
import re

from app.models import Tactics
from utils.reporter import ding_reporter

from app import schedule
from config import Config

job_name_str = "job_of_tactic_%d"


def execute_sql(sql, config):
    con = pymysql.connect(
        host=config.host,
        db=config.db_name,
        user=config.user,
        port=config.port,
        password=config.pwd,
        charset="utf8"
    )
    cursor = con.cursor(pymysql.cursors.SSDictCursor)
    cursor.execute(sql)
    result = cursor.fetchall()
    con.close()
    return result


def get_query(tactic, config):
    """
    1. 查询条件sql，无条件sql的情况下，直接查询sql
    2.
    :param tactic:
    :param config:
    :return:
    """
    con_sql = tactic.con_sql
    sql_template = tactic.sql
    try:
        if con_sql:
            conditions = execute_sql(tactic.con_sql, config)
            if conditions:
                result = []
                for condition in conditions:
                    sql = sql_template.format(**condition)
                    result.extend(execute_sql(sql, config))
                return result
            # else:
            #     return execute_sql(sql_template, config)
        else:
            return execute_sql(sql_template, config)
    except Exception as e:
        print(e)
        error_msg = "sql执行错误，请检查sql语句：%s" % e
        ding_reporter(tactic, error_msg=error_msg)


def task(tactic, config):
    result = get_query(tactic, config)
    if not result:
        return
    else:
        trigger = tactic.trigger
        if not trigger:
            return ding_reporter(tactic, result)
        else:
            pattern = re.compile("\w+\s*(=)\s*['|\"]?\w+['|\"]?")
            ex_trace = None
            query_list = []
            try:
                for item in result:
                    expression = re.sub(pattern, lambda x: x.group().replace("=", "=="), trigger)
                    for k, v in item.items():
                        if isinstance(v, int):
                            expression = expression.replace(k, str(v), 1)
                        else:
                            if v:
                                if "'" in v:
                                    expression = expression.replace(k, '"' + v + '"', 1)
                                else:
                                    expression = expression.replace(k, "'" + v + "'", 1)
                    ex_trace = expression
                    if eval(expression, {"__builtin__": {}}):
                        query_list.append(item)
                if query_list:
                    return ding_reporter(tactic, query_list)
            except Exception as e:
                print(e)
                error = "触发条件错误，请检查。错误信息：%s, \n\n表达式：「%s」" % (e, ex_trace)
                return ding_reporter(tactic, error_msg=error)


def add_job(tactic):
    if tactic.job_type == "date":
        now = datetime.datetime.now()
        run_date = datetime.datetime(
            year=now.year,
            month=tactic.month | now.month,
            day=tactic.day | now.day,
            hour=tactic.hour | now.hour,
            minute=tactic.minute | now.minute + 1,
            second=0
        )
        job = schedule.add_job(
            job_name_str % tactic.id,
            func=task,
            args=[tactic, tactic.config],
            trigger=tactic.job_type,
            run_date=run_date,
            replace_existing=True
        )
    elif tactic.job_type == "interval":
        job = schedule.add_job(
            id=job_name_str % tactic.id,
            func=task,
            args=[tactic, tactic.config],
            trigger=tactic.job_type,
            days=tactic.day,
            hours=tactic.hour,
            minutes=tactic.minute if list(filter(lambda x: x, [tactic.day, tactic.hour, tactic.minute])) else 1,
            seconds=0,
            replace_existing=True,
            max_instances=5
        )
    else:
        job = schedule.add_job(
            id=job_name_str % tactic.id,
            func=task,
            args=[tactic, tactic.config],
            trigger=tactic.job_type,
            year="*",
            month=tactic.month or "*",
            day=tactic.day or "*",
            hour=tactic.hour,
            minute=tactic.minute,
            second=0,
            replace_existing=True
        )
    return job


def modify_job(tactic):
    if tactic.job_type == "date":
        now = datetime.datetime.now()
        run_date = datetime.datetime(
            year=now.year,
            month=tactic.month | now.month,
            day=tactic.day | now.day,
            hour=tactic.hour | now.hour,
            minute=tactic.minute | now.minute + 1,
            second=0
        )
        schedule.modify_job(
            job_name_str % tactic.id,
            args=[tactic, tactic.config],
            trigger=tactic.job_type,
            run_date=run_date
        )
    elif tactic.job_type == "interval":
        schedule.modify_job(
            id=job_name_str % tactic.id,
            args=[tactic, tactic.config],
            trigger=tactic.job_type,
            days=tactic.day,
            hours=tactic.hour,
            minutes=tactic.minute if list(filter(lambda x: x, [tactic.day, tactic.hour, tactic.minute])) else 1,
            seconds=0,
        )
    else:
        schedule.modify_job(
            id=job_name_str % tactic.id,
            args=[tactic, tactic.config],
            trigger=tactic.job_type,
            month=tactic.month or "*",
            day=tactic.day or "*",
            hour=tactic.hour,
            minute=tactic.minute,
            second=0,
        )


def remove_job(tactic):
    schedule.remove_job(id=job_name_str % tactic.id)


def schedule_job():
    job_list = schedule.get_jobs()
    from app import app
    with app.app_context():
        tactics = Tactics.query.all()
        for tactic in tactics:
            job = schedule.get_job(job_name_str % tactic.id)
            if job in job_list and tactic.enable:
                if datetime.datetime.now() - tactic.last_update_time <= datetime.timedelta(
                        seconds=Config.SCHEDULE_SECONDS):
                    modify_job(tactic)
            elif job in job_list and not tactic.enable:
                remove_job(tactic)
            elif job not in job_list and tactic.enable:
                add_job(tactic)
            else:
                pass


def check_tactic():
    job_list = schedule.get_jobs()
    for job in job_list:
        job_id = job.id
        job_prefix = "job_of_tactic_"
        if job_id.startswith(job_prefix):
            tactic_id = int(job_id.split(job_prefix)[-1])
            from app import app
            with app.app_context():
                if not Tactics.query.filter_by(id=tactic_id).first():
                    schedule.remove_job(job_id)

# if __name__ == '__main__':
#     from apscheduler.schedulers.blocking import BlockingScheduler
#     schedule = BlockingScheduler()
#     schedule.add_job(monitor, "interval", seconds=30)
