#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/8/19 下午8:34
# @Author  : Mr.White
import logging
from logging.handlers import RotatingFileHandler
import os

from config import LOG_LEVEL


class LogUtil:
    LEVELS = {
        'debug': logging.DEBUG,
        'info': logging.INFO,
        'warning': logging.WARNING,
        'error': logging.ERROR,
        'critical': logging.CRITICAL
    }

    # def __new__(cls, *args, **kwargs):
    #     if not hasattr(cls, "instance"):
    #         cls.instance = super(LogUtil, cls).__new__(cls)
    #     return cls.instance

    def __init__(self, logger_name, file_name=None):
        self.name = logger_name
        self.file_name = file_name
        self.log_level = self.LEVELS.get(LOG_LEVEL, logging.DEBUG)

    def get_logger(self):
        if not os.path.exists(os.path.split(self.file_name)[0]):
            os.makedirs(os.path.split(self.file_name)[0])

        # 创建一个logger
        logger = logging.getLogger(self.name)
        logger.setLevel(self.log_level)

        # 创建一个handler，用于写入日志文件
        fh = RotatingFileHandler(self.file_name, maxBytes=1024 * 1024 * 100, backupCount=5, )
        fh.setLevel(self.log_level)

        # 再创建一个handler，用于输出到控制台
        ch = logging.StreamHandler()
        ch.setLevel(logging.WARNING)
        # ch.setLevel(logging.DEBUG)

        # 定义handler的输出格式
        # formatter = logging.Formatter('%(asctime)s - %(name)s- %(lineno)d- %(levelname)s - %(message)s')
        formatter = logging.Formatter('%(asctime)s - %(filename)s- %(lineno)d- %(levelname)s - %(message)s')
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)

        # 给logger添加handler
        logger.addHandler(fh)
        # logger.addHandler(ch)
        return logger