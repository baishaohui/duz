# -*- coding: utf-8 -*-
"""
    所有spider的基类
"""
import cfscrape
import requests


class BaseSpider(object):
    driver = None

    def __init__(self, url, headers=None,
                 params=None, payload=None, cookie=None):
        self.url = url
        self.headers = headers
        self.params = params
        self.payload = payload
        self.cookie = cookie

    def set_easy_cookie(self, target):
        response = requests.get(target)
        if response.status_code != 200:
            raise ConnectionError(
                f"Set cookie for {self.url} failed. {target} return a response of {response.status_code}")
        self.cookie = response.cookies

    def prepare(self):
        if self.driver is None:
            raise NotImplementedError("Driver must a selenium driver, requests or feed parser")

    def get(self):
        self.prepare()
        response = self.driver.get(self.url, params=self.params, cookies=self.cookie)
        if response.status_code == 503:
            scraper = cfscrape.create_scraper()
            response = scraper.get(self.url)
        return response.text

    def post(self):
        self.prepare()
        response = self.driver.post(self.url, json=self.payload, cookies=self.cookie)
        return response