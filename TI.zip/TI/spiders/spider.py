# -*- coding: utf-8 -*-
import json

import requests
import feedparser
from spiders.base import BaseSpider

from constants import DRIVER


class Spider(BaseSpider):
    driver = requests

    def __del__(self):
        try:
            if hasattr(self.driver, "close"):
                getattr(self.driver, "close")()
        except Exception as e:
            print(e)


class SeleniumSpider(Spider):
    driver = DRIVER

    def get(self):
        self.driver.get(self.url)
        page_source = self.driver.page_source
        print(self.url)
        return page_source


class AtomSpider(Spider):

    def get(self):
        xml = super(AtomSpider, self).get()
        atom_xml = feedparser.parse(xml)
        return atom_xml.entries


class ApiSpider(Spider):

    def get(self):
        json_ = super(ApiSpider, self).get()
        return json.loads(json_)


if __name__ == '__main__':
    spider = SeleniumSpider("https://github.com/django/django/commits/master")
    spider.get()
    import time
    time.sleep(10)
    spider2 = SeleniumSpider("https://hackerone.com/hacktivity?order_direction=DESC&order_field=popular&filter=type%3Aall")
    spider2.get()