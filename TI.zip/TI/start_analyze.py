#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/8/15 下午4:10
# @Author  : Mr.White
import time
import schedule
from scheduler import Scheduler
from analyze import Analyzer

if __name__ == '__main__':
    # notify = Notification()
    analyzer = Analyzer()
    # analyzer.analyze()
    # schedule.every(15).minutes.do(analyzer.filter)
    schedule.every().day.at("9:00").do(analyzer.analyze)  # 每天早上9:00执行任务
    schedule.every().day.at("12:00").do(analyzer.analyze)   # 每天上午12:00执行任务
    schedule.every().day.at("15:00").do(analyzer.analyze)   # 每天下午15:00执行任务
    schedule.every().day.at("18:00").do(analyzer.analyze)   # 每天下午16:00执行任务
    # schedule.every().day.at("17:00").do(analyzer.analyze)  # 每天晚上18:00执行任务
    # schedule.every().day.at("19:00").do(analyzer.analyze)  # 每天晚上20:00执行任务
    schedule.every().day.at("21:00").do(analyzer.analyze)  # 每天晚上21:00执行任务

    while True:
        schedule.run_pending()
        time.sleep(1)