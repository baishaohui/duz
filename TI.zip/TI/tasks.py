# -*- coding: utf-8 -*-
import traceback
import importlib
import os
import sys
from datetime import datetime, timedelta
from celery import Celery
from celery import Task

from rss import FeedScanner
from fxxk_twitter import TwitterCrawler
from logger import LogUtil
from db import db_con
from config import DEFAULT_EXECUTE_INTERVAL


app = Celery("tasks")
app.config_from_object("celery_cfg")
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(BASE_DIR)


class SpiderTask(Task):

    @staticmethod
    def reset_time(target):
        db = db_con()
        interval = db.retrieve(
            "info_source",
            ["`day`", "`hour`", "`minute`"],
            condition={"target": target}
        )
        if interval:
            if not list(filter(lambda x: x, interval.values())):
                interval["minute"] = DEFAULT_EXECUTE_INTERVAL if DEFAULT_EXECUTE_INTERVAL else 15
            params = {
                "days": interval.get("day"),
                "hours": interval.get("hour"),
                "minutes": interval.get("minute"),
            }
            next_run_time = int((datetime.now() + timedelta(**params)).timestamp())
            db.update(
                "info_source",
                {
                    "run_time": next_run_time,
                    "last_executed": datetime.now()
                },
                condition={"target": target}
            )

    def on_success(self, retval, task_id, *args, **kwargs):
        self.reset_time(args[0][0])
        return super(SpiderTask, self).on_success(retval, task_id, *args, **kwargs)

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        print("fail", args[0][0], einfo)
        self.reset_time(args[0][0])
        return super(SpiderTask, self).on_failure(exc, task_id, args, kwargs, einfo)


@app.task(base=SpiderTask)
def spider(target, source_type, script):
    try:
        if source_type == 0:
            scrape = FeedScanner(target)
        elif source_type == 2:
            scrape = TwitterCrawler()
            scrape.crawl(target)
            return "%s success" % target
        else:
            package = importlib.import_module("scripts." + script)
            scrape = getattr(package, "Task")(target)
        scrape.scan()
        return "%s success" % target
    except Exception as e:
        logger_obj = LogUtil(target, "log/spider_error.log")
        logger = logger_obj.get_logger()
        logger.error("A error happened when %s is running\nerror message:%s\n" % (target, traceback.format_exc()))


