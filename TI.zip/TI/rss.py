"""
    解析RSS/feed
    由于RSS通常是时间上从新到老的排序，通常在遍历是可以通过时间做过滤。
    时效性方面，大于两天或以上的信息已经没有价值，将直接过滤
    并且当首次遇到超出两天的item，将会中断遍历并返回结果
    rss链接源从数据库中提取，通过更新数据的方式实现热更新
"""
import re
import requests
import feedparser
import datetime
import time
from urllib3.exceptions import InsecureRequestWarning

import cfscrape

from db import db_con
from config import INTERVAL
from config import USER_AGENT
from config import TIMEOUT
from tools.translator import Translator


class FeedScanner:
    zh_pattern = re.compile(u'[\u4e00-\u9fa5]+')

    def __init__(self, url):
        self.url = url
        self.db = db_con()
        self.feed_list = []
        self.feed_dict = self.feed_parser()

    def feed_parser(self):
        if self.url.startswith("https://"):
            # requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
            html = requests.get(self.url, verify=False, headers={"User-Agent": USER_AGENT}, timeout=TIMEOUT)
            if html.status_code == 503:
                scraper = cfscrape.create_scraper()
                html = scraper.get(self.url)
            feed_obj = feedparser.parse(html.text)
        else:
            feed_obj = feedparser.parse(self.url)
        return feed_obj

    @property
    def items(self):
        return self.feed_dict.entries

    @staticmethod
    def get_title(item):
        return item.get("title")

    @staticmethod
    def get_link(item):
        return item.get("link")

    @staticmethod
    def get_summary(item):
        try:
            return item.get("summary")
        except KeyError:
            return item.get("description")

    @staticmethod
    def get_time(item):
        if item.get("published_parsed"):
            p_tuple = item.get("published_parsed")
        else:
            p_tuple = item.get("updated_parsed")
            if not p_tuple:
                p_tuple = item.get("published")
        if isinstance(p_tuple, tuple):
            date = datetime.datetime.fromtimestamp(time.mktime(p_tuple))
        else:
            _, p_tuple = p_tuple.split(" ", 1)
            p_tuple, _ = p_tuple.rsplit(" ", 1)
            date = datetime.datetime.strptime(p_tuple, "%d %b %Y")
        if datetime.datetime.now() - date <= datetime.timedelta(INTERVAL):
            # 小于INTERVAL天
            return date.strftime("%Y-%m-%d")

    @classmethod
    def contain_zh(cls, data):
        return cls.zh_pattern.search(data)

    @staticmethod
    def trans_en(text):
        translator = Translator()
        return translator.translate(text)

    def store(self, data):
        for item in data:
            if not self.db.count("record", condition={"title": item.get("title"), "link": item.get("link")}):
                item.setdefault("translation", self.trans_en(item.get("title")) if not self.contain_zh(
                    item.get("title")) else None)
                self.db.create("record", item)

    @staticmethod
    def analyze_summary(item):
        summary = item.get("summary")
        if summary:
            real_date = re.search("\d+-\d+-\d+", summary)
            if real_date:
                item["pub_date"] = real_date.group()
        return item

    def feed_filter(self, item):
        timestamp = self.get_time(item)
        if timestamp:
            title = self.get_title(item)
            link = self.get_link(item)
            summary = self.get_summary(item)
            return {"title": title, "link": link, "summary": summary, "pub_date": timestamp, "source": self.url}

    def scan(self):
        for item in self.items:
            data = self.feed_filter(item)
            if not data:
                continue
            self.feed_list.append(data)
        # self.store(self.feed_list)


if __name__ == '__main__':
    url = "https://github.com/php/php-src/commits/stable/3.0.x.atom"
    url = "https://github.com/django/django/releases.atom"
    # url = "https://github.com/django/django/tags.atom"
    obj = FeedScanner(url)
    print("scan", obj.scan())
    for i in obj.feed_list:
        print(i)
