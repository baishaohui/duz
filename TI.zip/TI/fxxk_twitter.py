# -*- coding: utf-8 -*-
import os
import time
import datetime
from urllib.parse import urljoin, quote

from selenium.webdriver import PhantomJS
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from bs4 import BeautifulSoup

from db import db_con


class TwitterCrawler:
    origin_domain = "https://twitter.com"

    def __init__(self):
        self.driver = None
        self.db = db_con()

    def _get(self, user):
        if user.__str__().startswith("https://"):
            target = user.__str__()
        else:
            target = os.path.join(self.origin_domain, user.__str__())
        if self.driver is None:
            self._set_headers_driver()
        self.driver.get(target)
        results = self.parse(self.driver.page_source, target)
        self.driver.close()
        print(results)
        # self._storage(results)

    # def search(self, query):
    #     if not query.startswith(self.origin_domain):
    #         query = self.origin_domain + f"/search?q={quote(query)}&src=typed_query"
    #     self.driver.get(query)
    #     self.driver.execute_script("window.scrollTo(0, 10000)")
    #     # input = self.driver.find_element_by_css_selector("input[data-testid=['SearchBox_Search_Input']")
    #     # input.send_keys(query)
    #     # input.submit()
    #     # time.sleep(10)
    #     print(self.driver.find_elements_by_tag_name("article"))
    #     data, has_next = self.parse_query(self.driver.page_source)
    #     if has_next:
    #         self.driver.execute_script("window.scrollTo(0, 10000)")
    #         data_next, _ = self.parse_query(self.driver.page_source)
    #         data.extend(data_next)
    #     self.driver.close()
    #     return data

    def _set_headers_driver(self, executable_path="/usr/local/bin/phantomjs"):
        desire = DesiredCapabilities.PHANTOMJS.copy()
        headers = {'Accept': '*/*',
                   'Accept-Language': 'en-US,en;q=0.8',
                   'Cache-Control': 'max-age=0',
                   'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36',
                   'Connection': 'keep-alive',
                   'Referer': 'http://www.baidu.com/'
                   }
        for key, value in headers.items():
            desire['phantomjs.page.customHeaders.{}'.format(key)] = value
        self.driver = PhantomJS(executable_path=executable_path,
                                desired_capabilities=desire,
                                service_args=['--load-images=no'])

    @staticmethod
    def make_soup(document):
        try:
            return BeautifulSoup(document, "lxml")
        except Exception:
            return BeautifulSoup(document, "html.parser")

    @staticmethod
    def link_format(source, link):
        if link.startswith("http://") or link.startswith("https://"):
            return link
        else:
            return urljoin(source, link)

    def parse(self, document, source):
        soup = self.make_soup(document)
        section = soup.find("ol", attrs={"id": "stream-items-id"})
        items = section.select(".tweet")
        results = []
        for item in items:
            tweet_id = item.get("data-tweet-id")
            link = self.link_format(source, item.get("data-permalink-path"))
            data_tag = item.find("span", "_timestamp")
            timestamp = data_tag.get("data-time")
            title = item.find("p", attrs={"class": "tweet-text"}).get_text().strip()
            # translator = Translator()
            # translation = translator.translate(title)
            pub_date = datetime.datetime.fromtimestamp(int(timestamp)).strftime("%Y-%m-%d")
            # results.append(
            #     {"title": title, "link": link, "pub_date": pub_date, "source": source, "translation": translation,
            #      "tweet_id": tweet_id})
            results.append(
                {"title": title, "link": link, "pub_date": pub_date,
                 "source": source, "tweet_id": tweet_id})
        return results

    # def parse_query(self, document):
    #     soup = self.make_soup(document)
    #     self.fetch_query_items(soup)
    #     result = []
    #     flag = False
    #     return result, flag

    # def fetch_query_items(self, soup):
    #     items = soup.find_all("article")
    #     print(soup)
    #     print(items)

    def _storage(self, items):
        for item in items:
            if not self.db.count("record", condition={"tweet_id": item.get("tweet_id")}):
                self.db.create("record", item)

    def crawl(self, target):
        self._get(target)
        self.driver = None


if __name__ == '__main__':
    tweet = TwitterCrawler()
    tweet.crawl("h1_kenan")
    # tweet.crawl("mmolgtm")
    # tweet.search("WAF bypass")
