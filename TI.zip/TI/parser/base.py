# -*- coding: utf-8 -*-


class BaseParser:

    def __init__(self):
        pass