#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/8/15 上午10:04
# @Author  : Mr.White
from celery.schedules import crontab

CELERY_IMPORTS = ("tasks", )
# CELERY_RESULT_BACKEND = "amqp"
CELERY_RESULT_BACKEND = "redis"
# BROKER_URL = "amqp://guest:guest@localhost:5672//"
BROKER_URL = "redis://localhost:6379/0"
CELERY_TASK_RESULT_EXPIRES = 600
CELERYD_CONCURRENCY = 5

CELERYD_FORCE_EXECV = True
CELERYD_TASK_TIME_LIMIT = 300

CELERYD_MAX_TASKS_PER_CHILD = 100
# CELERYBEAT_SCHEDULE = {
#     'ptask': {
#         'task': 'tasks.period_task',
#         'schedule': crontab(hour=1),
#     },
# }

# timezone = "Asia/Shanghai"