# -*- coding: utf-8 -*-
"""
1.查询数据库中未分析过的数据
2.对查询结果进行分析，并更改分析状态
3.将分析结果发出消息通知
"""
import re
import datetime
from urllib.parse import urljoin
from config import INTERVAL
from db import db_con
from notification import Notification


class Analyzer(object):

    def __init__(self):
        self.db = db_con()
        # self.data = self.coll_data()
        self.result = []

    @property
    def data(self):
        """
        Get the new information which has not been analyzed yet from db and return
        :return:
        """
        items = self.db.list(
            "record",
            ["title", "link", "source", "summary", "pub_date", "translation"],
            condition={
                "analyzed": 0,
                "has_sent": 0,
            }
        )
        return items

    def set_analyzed(self, item):
        if item:
            self.db.update(
                "`record`",
                {
                    "analyze_time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "`analyzed`": 1
                },
                condition={
                    "title": item.get("title"),
                    "link": item.get("link")
                }
            )

    @property
    def keyword_pattern(self):
        """
        Get queries of the keywords from db and return the regular expressions
        :return:
        """
        # sql = "select word from keyword"
        data = self.db.list("keyword", ["word"])
        return "|".join([word["word"].strip() for word in data])

    def check_reliable(self, item):
        """
        Check if the query is a from a reliable source.
        If true return the query else none.
        :param item:
        :return:
        """
        source = item.get("source")
        if source:
            data = self.db.list("info_source", ["reliable"], condition={"target": source})
            if data:
                return data[0].get("reliable")

    @staticmethod
    def time_filter(item):
        """
        First analyze condition,to make sure the information is the latest.
        If it is,return the information else none
        :param item:
        :return:
        """
        time = item.get("pub_date")
        if time:
            # year, month, day = time.split("-")
            try:
                if datetime.date.today() - datetime.timedelta(days=INTERVAL) <= datetime.date(
                        year=time.year, month=time.month, day=time.day):
                    return item
            except Exception as e:
                print(e)

    def title_filter(self, item):
        """
        Analyze information by regular expressions which were included by all the keywords.
        There are exceptions for those information which is from the reliable sources.
        :param item:
        :return:
        """
        if not self.check_reliable(item):
            pattern = self.keyword_pattern
            if re.findall(pattern, item.get("title")):
                if not (re.search("^CVE-\d+-\d+$", item.get("title")) or re.search("^CVE-\d+-\d+$", item.get("title"))):
                    # 去除CVE样式title
                    return item
            else:
                if item.get("summary"):
                    if re.findall(pattern, item.get("summary")):
                        return item
        else:
            return item

    def duplication_filter(self, item):
        """通过对item做分词，并与已加入结果的title进行相似性对比"""
        # sql = "select 1 from record where title=%s"
        pass

    def info_storage(self, data):
        """
        Just to storage .
        :param data:
        :return:
        """
        self.db.create("record", data)

    def set_intelligence(self, item):
        """
        Update db by setting intelligence field
        :param condition:
        :return:
        """
        self.db.update(
            "record",
            {
                "is_intelligence": 1
            },
            condition={
                "title": item.get("title"),
                "link": item.get("link")
            }
        )

    @staticmethod
    def _batch(field, items):
        """
        To make condition
        :param field:
        :param items:
        :return:
        """
        params = []
        for item in items:
            params.append(item.get(field))
        con_temp = "%s in (%s)" % (field, ",".join(["%s" for item in items]))
        return {con_temp: params}

    @staticmethod
    def make_notify(message):
        notify = Notification(data=message)
        notify.send()

    def _analyze(self):
        items = self.data
        for item in items:
            if self.time_filter(item) and self.title_filter(item):
                if not (item["link"].startswith("http://") or item["link"].startswith("https://")):
                    item["link"] = urljoin(item["source"], item["link"])
                self.result.append(item)
                self.set_intelligence(item)
            self.set_analyzed(item)

    def analyze(self):
        print("Start analyzing at %s..." % datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        if self.result:
            self.result.clear()
        if self.data and self.data != 1:
            self._analyze()
        self.make_notify(self.result)


if __name__ == '__main__':
    obj = Analyzer()
    # print(obj.check(item))
    result = obj.analyze()
    print(result)
