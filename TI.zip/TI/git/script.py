# -*- coding: utf-8 -*-
import json
from selenium.webdriver import PhantomJS, DesiredCapabilities

commit_uri = "https://github.com/{}/commits/master"
commit_atom = "https://github.com/django/django/commits/{}.atom"
release_atom = "https://github.com/{}/releases.atom"
tag_atom = "https://github.com/{}/tags.atom"
header = {
    # "User-Agent": USER_AGENT,
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.8',
    'Cache-Control': 'max-age=0',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36',
    'Connection': 'keep-alive',
    'Referer': 'http://www.baidu.com/'
}

with open("commits.json", "r") as w:
    data = json.loads(w.read())

with open("releases.json", "r") as r:
    data.extend(json.loads(r.read()))

with open("tags.json", "r") as f:
    data.extend(json.loads(f.read()))
from db import db_con

db = db_con()
print(len(data))
for item in data:
    # print(item)
    db.create(
        "info_source",
        {"target": item,
         "type": 0, "reliable": 0, "day": 0, "week": 0, "hour": 5, "minute": 0, "schedule_type": 0, "enable": 1})
