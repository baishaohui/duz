# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup
from selenium.webdriver import PhantomJS
import datetime
import json

driver = PhantomJS()
url = "https://twitter.com/hacksysteam"
driver.get(url)
response = driver.page_source
# response = requests.get("https://twitter.com/moritzj")
soup = BeautifulSoup(response, "lxml")
section = soup.find("ol", attrs={"id": "stream-items-id"})
items = section.select(".tweet")
results = []
for item in items:
    link = item.get("data-permalink-path")
    content = item.find("div", "content")
    data_tag = item.find("span", "_timestamp")
    timestamp = data_tag.get("data-time")
    title = item.find("p", attrs={"class": "tweet-text"}).get_text().strip()
    pub_date = datetime.datetime.fromtimestamp(int(timestamp)).strftime("%Y-%m-%d")
    results.append({"title": title, "link": link, "pub_date": pub_date, "source": url})
print(json.dumps(results))
