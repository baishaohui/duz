# -*- coding: utf-8 -*-
import logging

import requests

from config import ALERT_ROBOTS, ALERT_ALL


class Robot:
    msgtype = "text"

    @classmethod
    def message(cls, msg):
        content = {"content": msg}
        template = cls.template()
        template[cls.msgtype] = content
        return template

    @classmethod
    def template(cls):
        return {
            "msgtype": cls.msgtype,
            cls.msgtype: {},
            "at": {
                "isAtAll": ALERT_ALL
            }
        }

    @classmethod
    def send_msg(cls, msg, title=""):
        header = {"Content-Type": "application/json; charset=utf-8"}
        tmpl = cls.message(msg)
        if title and cls.msgtype != "text":
            tmpl[cls.msgtype]["title"] = title
        for robot in ALERT_ROBOTS:
            response = requests.post(robot, json=tmpl, headers=header)
            if response.json()["errcode"] != 0:
                logging.error(robot + " : " + response.text)


class MarkdownRobot(Robot):
    msgtype = "markdown"

    @classmethod
    def message(cls, msg):
        content = {
            "title": "",
            "text": msg
        }
        template = cls.template()
        template[cls.msgtype] = content
        return template


if __name__ == '__main__':
    Robot.send_msg("测试")