# -*- coding: utf-8 -*-
import datetime
from scripts import ScrawlAbstract



class Task(ScrawlAbstract):

    def get_info(self):
        item_list = self.initial_json
        result = []
        for item in item_list:
            title = item.get("title")
            summary = item.get("summary")
            link = self.link_formatter(item.get("url"))
            utc_time = item.get("firstPublished").split(".")[0]
            local_time = datetime.datetime.strptime(utc_time, "%Y-%m-%dT%H:%M:%S") + datetime.timedelta(hours=8)
            pub_date = local_time.date().strftime("%Y-%m-%d")
            result.append({"title": title, "link": link, "summary": summary, "source": self.url, "pub_date": pub_date})
        return result


if __name__ == '__main__':
    url = "https://tools.cisco.com/security/center/publicationService.x?criteria=exact&cves=&keyword=&last_published_date=&limit=20&offset=20&publicationTypeIDs=1,3&securityImpactRatin"
    obj = Task(url)
    print(obj.get_info())