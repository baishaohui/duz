# -*- coding: utf-8 -*-
import datetime
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("div", "report-block")
        result = []
        if section:
            item_list = section.find_all("div", "report-item")
            if item_list:
                for item in item_list:
                    title = item.find("div", "report-title").text
                    link = item.find("div", "report-link").text
                    time = datetime.date.today().strftime("%Y-%m-%d")
                    result.append({"title": title, "link": link, "pub_date": time, "source": self.url})
        return result


if __name__ == '__main__':
    obj = Task("https://cert.360.cn/daily")
    data = obj.get_info()
    print(data)