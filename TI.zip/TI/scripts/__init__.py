# -*- coding: utf-8 -*-
import re
import json
import requests
from urllib.parse import urljoin

# from pyvirtualdisplay import Display
# from selenium.webdriver.common.by import By
from selenium.webdriver import DesiredCapabilities, Firefox, ChromeOptions, FirefoxOptions, Chrome, PhantomJS
from bs4 import BeautifulSoup as bs

from tools.translator import Translator
from config import USER_AGENT
from db import db_con
from config import TIMEOUT
from logger import LogUtil


class ScrawlAbstract(object):
    zh_pattern = re.compile(u'[\u4e00-\u9fa5]+')

    def __init__(self, url, method="get", params=None, load_js=False):
        self.url = url
        self.method = method
        self.params = params
        self.db = db_con()
        self.response = None
        self.cursor = None
        self.driver = None
        self.cookies = None
        self.result = []
        self.load_js = load_js
        self.initial_response()
        self.logger = LogUtil("log/request_error.log")

    def initial_response(self):
        if self.load_js:
            self.load_by_js()
        else:
            self.make_request()

    @staticmethod
    def initial_header():
        header = {
            "User-Agent": USER_AGENT,
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.8',
            'Cache-Control': 'max-age=0',
            # 'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36',
            'Connection': 'keep-alive',
            'Referer': 'http://www.baidu.com/'

        }
        return header

    @property
    def initial_soup(self):
        return bs(self.response, "lxml")

    @property
    def initial_json(self):
        return json.loads(self.response, encoding="utf-8")

    def make_request(self):
        response = requests.request(
            self.method,
            self.url,
            params=self.params,
            headers=self.initial_header(),
            timeout=TIMEOUT,
            cookies=self.cookies
        )

        if response.status_code == 200:
            response.encoding = "utf-8"
            self.response = response.text
        else:
            logger_obj = LogUtil(self.url, "log/spider_error.log")
            logger = logger_obj.get_logger()
            logger.error("%s request error-%d" % (self.url, response.status_code))
            raise ValueError("%s request error-%d" % (self.url, response.status_code))

    def load_by_js(self):
        # display = Display(visible=0, size=(1024, 768))
        # display.start()
        desire = DesiredCapabilities().FIREFOX.copy()
        desire["marionette"] = False
        headers = self.initial_header()
        for key, value in headers.items():
            desire['phantomjs.page.customHeaders.{}'.format(key)] = value
        # self.driver = Firefox(executable_path="/usr/local/bin/geckodriver",
        #    desired_capabilities=desire, service_args=['--load-images=no'])
        # self.driver = Chrome(executable_path="/usr/local/bin/chromedriver",
        #     desired_capabilities=desire, service_args=['--load-images=no'])
        self.driver = PhantomJS(executable_path="/usr/local/bin/phantomjs",
                                desired_capabilities=desire, service_args=['--load-images=no'])
        self.driver.implicitly_wait(20)
        self.driver.get(self.url)
        self.response = self.driver.page_source.encode("utf-8").decode()
        self.driver.quit()

    def link_formatter(self, link):
        if link.startswith("http://") or link.startswith("https://"):
            return link
        else:
            return urljoin(self.url, link)

    def get_info(self):
        raise NotImplementedError("subclasses should overwrite this method to get the information of your own")

    @classmethod
    def contain_zh(cls, data):
        return cls.zh_pattern.search(data)

    @staticmethod
    def trans_en(text):
        translator = Translator()
        return translator.translate(text)

    def store(self, data, table, fields):
        if data:
            for item in data:
                if not self.db.count(table, condition={field: item.get(field) for field in fields}):
                    item.setdefault("translation", self.trans_en(item.get("title")) if not self.contain_zh(
                        item.get("title")) else None)
                    self.db.create(table, item)

    def scan(self):
        data = self.get_info()
        self.store(data, "record", ("title",))
