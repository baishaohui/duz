# -*- coding: utf-8 -*-
import re
from datetime import datetime
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def time_formater(self, date_str):
        date = date_str.split(" ")[1]
        date_re = re.search("\d+", date).group()
        date_str = date_str.replace(date, date_re)
        return date_str

    def get_info(self):
        soup = self.initial_soup
        section = soup.select("body > table")[-1]
        title_list = section.find_all("h3")
        date_list = section.find_all("i", "date")
        result = []
        for i in range(0, len(title_list)):
            title = title_list[i].get_text()
            date_str = date_list[i].get_text()
            if len(date_str.split(" on ")) > 1:
                pub_date = datetime.strptime(
                    self.time_formater(date_str.rsplit(" on ", 1)[-1]), "%B %d %Y").strftime("%Y-%m-%d")
            else:
                pub_date = datetime.strptime(self.time_formater(date_str), "%B %d %Y").strftime("%Y-%m-%d")
            result.append({
                "title": title,
                "link": self.url,
                "pub_date": pub_date,
                "source": self.url
            })
        return result


if __name__ == '__main__':
    url = "https://rsync.samba.org/security.html"
    obj = Task(url)
    print(obj.get_info())