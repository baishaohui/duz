# -*- coding: utf-8 -*-
import datetime
import re
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        pattern = re.compile('<div style="padding: 4px;">.*</div>', re.S)
        p = re.search(pattern, self.response)
        section = p.group()
        title_list = re.findall('<span class="headline">(.*?)</span>', section)
        date_list = re.findall('<span class="date">(.*?)</span>', section)
        link_list = re.findall('<a href="/bid/\d+">(http.*?)</a>', section)
        result = []
        for item in range(0, min(len(title_list), len(date_list), len(link_list))):
            title = title_list[item]
            date = date_list[item]
            link = link_list[item]
            result.append({"title": title, "link": link, "pub_date": date, "source": self.url})
        return result


if __name__ == '__main__':
    obj = Task("https://www.securityfocus.com/vulnerabilities")
    print(obj.get_info())
