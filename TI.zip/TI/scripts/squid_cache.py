# -*- coding: utf-8 -*-
import re
import datetime

from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("div", attrs={"id": "colOne"})
        result = []
        if section:
            dt_list = section.select("dl > dt")
            dd_list = section.select("dl > dd")
            if dt_list and dd_list:
                pattern = re.compile("(\w+ \d{1,2}, \d{4})", re.DOTALL)
                for i in range(min(len(dd_list), len(dt_list))):
                    dt = dt_list[i]
                    dd = dd_list[i]
                    a_tag = dt.find("a")
                    link = self.link_formatter(a_tag.get("href"))
                    text= dt.get_text().lstrip(a_tag.get_text())
                    date_str = re.search(pattern, text)
                    date_str = date_str.group()
                    try:
                        pub_date = datetime.datetime.strptime(date_str.strip(), "%b %d, %Y").strftime("%Y-%m-%d")
                    except ValueError:
                        pub_date = datetime.datetime.strptime(date_str.strip(), "%B %d, %Y").strftime("%Y-%m-%d")
                    cve = text.strip().strip(date_str)
                    if cve:
                        title = cve.strip() + dd.get_text().replace("\n", " ").replace("\t", "")
                    else:
                        title = dd.get_text().replace("\n", " ").replace("\t", "")
                    result.append(
                        {
                            "title": title,
                            "link": link,
                            "source": self.url,
                            "pub_date": pub_date
                        }
                    )
        return result


if __name__ == '__main__':
    obj = Task("http://www.squid-cache.org/Advisories/")
    print(obj.get_info())