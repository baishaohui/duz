# -*- coding: utf-8 -*-
import requests

from scripts import ScrawlAbstract

headers = {
            'accept': "application/json, text/javascript, */*; q=0.01",
            'accept-encoding': "gzip, deflate, br",
            'accept-language': "zh-CN,zh;q=0.9",
            'content-type': "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
            'cookie': "_cfuid=36c246bc-d711-4ef0-939b-96c6a148d12b; __cfduid=d2558e1d0bf5f471d2e0aee40312a59401567785229; _ga=GA1.2.1240667727.1567785236; __Host-session=bXVOQnF5SmN1VFFrRHg5ZFBRZFQveUZzM0EzV2RvZlFrdW44ZHI1Q1VXdmtPTVMvbk1YMTJBUHpMZ3pBN1lnbGxOdlZyVHJqeEwxOWJjWU1oNGJTeUZYYzdEQkxFRGZReldTWG51QzVQend4UzhQQy91enJVL3VYOVJVK1VMaW9kMzFJb29QcTl5U1hpVWZQMU1LVHlnPT0tLWQ0aEM2cWJ6cnR5OEVjUzlwR1lvTEE9PQ%3D%3D--32ad5beb482f1015499c8a2afb2503d58efb529c",
            'referer': "https://hackerone.com/hacktivity?sort_type=latest_disclosable_activity_at&filter=type%3Apublic&page=1",
            'user-agent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
            'x-requested-with': "XMLHttpRequest",
            'cache-control': "no-cache",
        }


class Task(ScrawlAbstract):
    headers = headers

    def __init__(self, url, method="get", params=None, load_js=True):
        super(Task, self).__init__(url, method, load_js=load_js, params=None)

    @staticmethod
    def initial_header():

        return headers

    def get_info(self):
        print(self.initial_soup)
        result = []
        try:
            api_json = self.initial_json
            item_list = api_json.get("reports")
        except Exception:
            item_list = []
        if item_list:
            for item in item_list:
                title = item.get("title")
                link = self.link_formatter(item.get("url"))
                pub_date = item.get("latest_disclosable_activity_at").split("T")[0]
                result.append(dict(title=title, link=link, pub_date=pub_date, source=self.url))
        return result


if __name__ == '__main__':
    # url = "https://hackerone.com/hacktivity?sort_type=latest_disclosable_activity_at&page=1&filter=type%3Apublic"
    url = "https://hackerone.com/hacktivity?order_direction=DESC&order_field=popular&filter=type%3Aall"
    # obj = Task("https://hackerone.com/hacktivity?sort_type=latest_disclosable_activity_at&filter=type%3Apublic&page=1")
    obj = Task(url)
    print(obj.get_info())