# -*- coding: utf-8 -*-
from scripts import ScrawlAbstract
import time

refer = 'https://www.aliyun.com/product/new?spm=5176.8142029.388261.486.e939'

headers = {
    'referer': refer

}


class Task(ScrawlAbstract):
    headers = headers

    @staticmethod
    def initial_header():
        return headers

    def get_info(self):
        result = []
        try:
            api_json = self.initial_json
            a_list = api_json.get('data')
            a_info_list = a_list['list']

            for l in a_info_list:
                featureTypeName = l['featureTypeName']
                featureProperties = l['featureProperties']
                releaseTime = l['releaseTime'] / 1000
                timeArray = time.localtime(releaseTime)
                releaseTime = time.strftime("%Y-%m-%d %H:%M:%S", timeArray)
                if 'productId=62' in self.url:
                    title = '[态势感知]' + featureTypeName + '——' + featureProperties[0]['propertyContent']
                else:
                    title = '[安骑士]' + featureTypeName + '——' + featureProperties[0]['propertyContent']
                title.replace('\n', '')
                title.replace('\r', '')
                link = featureProperties[4]['propertyContent']
                result.append(dict(title=title, link=link, pub_date=releaseTime, source=self.url))

        except:
            pass

        return result


if __name__ == '__main__':
    sas_url = 'https://promotion.aliyun.com/ops/listFeatures?cback=&channelCode=GUANWANG_PC_356EA7ACAD&startTime=&productCategoryId=21&productId=62&featureTypeIds=2%2C3%2C5%2C6%2C16%2C17&pageSize=10&pageNum=1'
    sas_url2 = "https://promotion.aliyun.com/ops/listFeatures?cback=&channelCode=GUANWANG_PC_356EA7ACAD&startTime=&productCategoryId=225&productId=51&featureTypeIds=2%2C3%2C5%2C6%2C16%2C17&pageSize=10&pageNum=1"
    obj = Task(sas_url2)
    print(obj.get_info())
