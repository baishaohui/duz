# -*- coding: utf-8 -*-
import re
import datetime

from bs4 import BeautifulSoup as bs
from scripts import ScrawlAbstract
from tools.translator import Translator
from db import DBHandler
from config import DB_CONFIG


class Task(ScrawlAbstract):
    cve_pattern = re.compile("CVE-\d+-\d+")

    def __init__(self, url, method="get", params=None, load_js=True):
        self.update_links = []
        super(Task, self).__init__(url, method=method, params=params, load_js=load_js)
        self.initial_db()

    def initial_db(self):
        db = DBHandler(
            DB_CONFIG.get("host"),
            DB_CONFIG.get("port"),
            DB_CONFIG.get("user"),
            DB_CONFIG.get("password"),
            DB_CONFIG.get("vul_db")
        )
        self.db = db

    def fetch_link(self):
        soup = self.initial_soup
        data_list = soup.select("#DataTables_Table_0 > tbody > tr")
        for data in data_list:
            main_tag = data.find("a")
            time_tag = data.find("time")
            title_tag = data.select(".td-synopsis > .cell-content")[0]
            aid = main_tag.get_text()
            link = main_tag["href"]
            # pub_date = time_tag["datetime"].split("T")[0]
            pub_date = datetime.datetime.strptime(time_tag.get_text(), "%d %b %Y")
            title = aid + "-" + title_tag.get_text()
            translated_title = self.translate_title(title)
            # if self.db.count("vul_advisory", {"aid": aid, "advisory_body": None}):
            if self.db.count("vul_advisory", condition=f"aid='{aid}' and advisory_body!=null"):
                continue
            self.update_links.append(
                {"aid": aid, "title": title, "pub_date": pub_date, "link": link, "translated_title": translated_title,
                 "record_time": datetime.datetime.now(), "is_translated": 0, "advisory_type": 2,
                 "gmt_modified": datetime.datetime.now()})

    @staticmethod
    def translate_title(title: str):
        title = title.replace(", ", ",").replace("Low", "低危").replace("Moderate", "中危").replace(
            "Important", "重要").replace("Critical", "关键").replace("security update", "安全更新").replace(
            "kernel", "内核").replace("security and bug fix update", "安全和BUG修复更新").replace(
            "security,bug fix and enhancement update", "安全和BUG修复更新").replace(
            "security and enhancement update", " 安全和BUG修复更新").replace(
            "security fix update", "安全和BUG修复更新").replace("and", "和")
        return title

    def request_detail(self):
        self.fetch_link()
        # self.store(self.update_links, "vul_advisory", ("aid",))
        for link in self.update_links:
            self.driver.get(link.get("link"))
            print(link.get("link"))
            details = self.fetch_detail(bs(self.driver.page_source, "lxml"))
            self.db.update("vul_advisory", details, condition={"aid": link.get("aid")})

    @classmethod
    def fetch_detail(cls, soup):
        advisory_body = soup.find("div", attrs={"id": "overview"})
        description_list = advisory_body.find_all("h2")
        text = advisory_body.get_text()
        cves = ",".join(set(re.findall(cls.cve_pattern, text))).lower()
        description = []
        translation = ""
        for tag in description_list:
            if tag.get_text() == "Description":
                for ele in tag.next_siblings:
                    if ele.name is None:
                        continue
                    if ele.name == "h2" and ele.get_text() == "Solution":
                        break
                    description.append(ele.__str__())
                description = "".join(description)
                # translator = Translator()
                # translation = translator.translate(description, format_type="html")
        return {"description": description, "advisory_body": advisory_body.__str__(), "translation": translation,
                "cves": cves}

    def store(self, data, table, fields):
        if data:
            for item in data:
                if not self.db.count(table, condition={field: item.get(field) for field in fields}):
                    self.db.create(table, item)

    def scan(self):
        self.request_detail()


if __name__ == '__main__':
    obj = Task(
        "https://access.redhat.com/errata/#/?q=&p=1&sort=portal_publication_date%20desc&rows=100&portal_advisory_type=Security%20Advisory")
    obj.scan()

