# -*- coding: utf-8 -*-
import datetime

from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.select("body > ul")
        result = []
        if section:
            item_list = section[0].find_all("li")
            if item_list:
                for item in item_list:
                    if item.find("strong"):
                        pub_date = datetime.datetime.strptime(
                        item.find("strong").get_text().strip(":"), "%B %d, %Y").strftime("%Y-%m-%d")
                        title = item.get_text().replace("\n", "").replace("   ", "")
                        a_tag = item.find("a")
                        link = a_tag.get("href") if a_tag else self.url
                        result.append(
                            {
                                "title": title,
                                "link": self.link_formatter(link),
                                "pub_date": pub_date,
                                "source": self.url
                            }
                        )
        return result


if __name__ == '__main__':
    obj = Task("http://www.openssh.com/security.html")
    print(obj.get_info())
