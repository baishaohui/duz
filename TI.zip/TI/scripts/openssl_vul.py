# -*- coding: utf-8 -*-
import datetime
from bs4 import BeautifulSoup
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("div", "entry-content").find("dl")
        item_list = section.find_all("dt")
        result = []
        for index, item in enumerate(item_list):
            title = item.contents[0].text
            link = item.contents[0]["href"]
            time = datetime.datetime.strptime(item.contents[-2].strip(": "), "%d %B %Y").strftime("%Y-%m-%d")
            result.append({"title": title, "link": link, "pub_date": time, "source": self.url})
        return result


if __name__ == '__main__':
    obj = Task("https://www.openssl.org/news/vulnerabilities.html")
    obj.get_info()
