# -*- coding: utf-8 -*-
from datetime import datetime

from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("div", attrs={"id": "content"})
        title_list = section.find_all("h1")
        date_str_list = section.find_all("i")
        result = []
        for i in range(0, len(title_list)):
            title = title_list[i].get_text()
            pub_date = datetime.strptime(date_str_list[i].get_text(), "%d/%b/%Y").strftime("%Y-%m-%d")
            result.append({
                "title": title,
                "link": self.url,
                "source": self.url,
                "pub_date": pub_date
            })
        return result


if __name__ == '__main__':
    url = "http://www.proftpd.org/"
    obj = Task(url)
    print(obj.get_info())