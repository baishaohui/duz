# -*- coding: utf-8 -*-
import datetime
import re
from scripts import ScrawlAbstract
from bs4 import BeautifulSoup


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("table", "tlist")
        result = []
        if section:
            item_list = section.select("tbody > tr")
            if item_list:
                for item in item_list:
                    elements = item.find_all("td")
                    title_link = elements[0].find("a")
                    title = title_link.text.strip()
                    link = self.link_formatter(title_link.get("href"))
                    pub_date = elements[-1].text.strip()
                    result.append({"title": title, "link": link, "pub_date": pub_date, "source": self.url})
        return result


if __name__ == '__main__':
    obj = Task("http://www.cnvd.org.cn/flaw/list.htm")
    data = obj.get_info()
    print(data)
