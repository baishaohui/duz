# -*- coding: utf-8 -*-
import datetime
import re
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("ul", "vul_list")
        result = []
        if section:
            item_list = section.find_all("li")
            if item_list:
                for item in item_list:
                    title_link = item.find("a")
                    title = title_link.text.strip()
                    link = self.link_formatter(title_link.get("href"))
                    pub_date = item.find("span").text.strip()
                    result.append({"title": title, "link": link, "pub_date": pub_date, "source": self.url})
        return result


if __name__ == '__main__':
    # obj = Task("http://www.nsfocus.net/index.php?act=sec_bug")
    obj = Task("http://www.nsfocus.net/index.php?act=advisory")
    data = obj.get_info()
    print(data)
