# -*- coding: utf-8 -*-
import datetime
from bs4 import BeautifulSoup as bs
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def __init__(self, url, method="get", params=None, load_js=True):
        super(Task, self).__init__(url, method=method, params=params, load_js=load_js)

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("table", "searchresult")
        result = []
        if section:
            item_list = section.select("tbody > tr")
            if item_list:
                for item in item_list:
                    title_link = item.find("a")
                    date = item.find_all("td")[-1].get_text().strip()
                    try:
                        pub_date = datetime.datetime.strptime(date, "%Y年%m月%d日").strftime("%Y-%m-%d")
                    except ValueError:
                        pub_date = datetime.datetime.strptime(date, "%b %d, %Y").strftime("%Y-%m-%d")
                    title = title_link.get_text()
                    link = self.link_formatter(title_link.get("href"))
                    result.append({"title": title, "link": link, "pub_date": pub_date, "source": self.url})
        return result


if __name__ == '__main__':
    obj = Task("https://exchange.xforce.ibmcloud.com/activity/list?filter=Vulnerabilities")
    print(obj.get_info())


