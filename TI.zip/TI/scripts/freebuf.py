# -*- coding: utf-8 -*-
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        results = []
        items = soup.find_all("div", "news-info")
        for item in items:
            a_tag = item.find("a")
            date_tag = item.find("span", "time")
            try:
                link = a_tag["href"]
                title = a_tag["title"]
                release_time = date_tag.get_text(strip=True)
                results.append(
                    {"title": title, "link": link,
                     "pub_date": release_time, "source": self.url})
            except AttributeError:
                pass
        return results


if __name__ == '__main__':
    obj = Task("https://www.freebuf.com/articles/database")
    obj.scan()