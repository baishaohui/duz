# -*- coding: utf-8 -*-
import datetime
from bs4 import BeautifulSoup
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.select(".aws-table > table > tbody")
        item_list = section[0].find_all("tr")
        result = []
        for index, item in enumerate(item_list):
            if index != 0:
                field_list = item.find_all("td")
                time = datetime.datetime.strptime(field_list[2].text.strip(), "%B %d, %Y").strftime("%Y-%m-%d")
                ele = field_list[4]
                title = ele.text
                link = ele.find("a")["href"]
                result.append({"title": title, "link": link, "pub_date": time, "source": self.url})
        return result


if __name__ == '__main__':
    obj = Task("https://aws.amazon.com/cn/security/security-bulletins/")
    print(obj.get_info())
