# -*- coding: utf-8 -*-
from datetime import datetime

from selenium.webdriver import PhantomJS

from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def __init__(self, url, method="get", params=None, load_js=True):
        super(Task, self).__init__(url, method=method, params=params, load_js=load_js)

    def load_by_js(self):
        driver = PhantomJS("/usr/local/bin/phantomjs")
        driver.get(self.url)
        try:
            iframe = driver.find_element_by_id('twitter-widget-0')
            driver.switch_to.frame(iframe)
        except Exception:
            pass
        self.response = driver.page_source

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("ol", "timeline-TweetList")
        result = []
        if section:
            item_list = section.find_all("li", "timeline-TweetList-tweet")
            if item_list:
                for item in item_list:
                    if item:
                        link = item.find("div", "timeline-Tweet-metadata").find("a").get("href")
                        title = item.find("p", "timeline-Tweet-text").get_text().strip()
                        pub_date = item.find("time", "dt-updated").get("datetime").strip().split("T")[0]
                        result.append({"title": title, "pub_date": pub_date, "link": link})
        return result


if __name__ == '__main__':
    task = Task("https://cve.mitre.org/cve/data_feeds.html")
    print(task.get_info())
