# -*- coding: utf-8 -*-
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("div", "versions")
        result = []
        if section:
            item_list = section.select(".version")
            if item_list:
                for item in item_list:
                    key_des = "ug fix release"
                    if key_des in item.find("div", "version-description-inner").text:
                        pub_date = item.find("div", "version-date").text
                        title = item.find("div", "version-name-inner").text.strip()
                        link = source = self.url
                        summary = item.find("div", "version-change-list-inner").get_text().strip()
                        result.append({
                            "title": title,
                            "link": link,
                            "summary": summary,
                            "pub_date": pub_date,
                            "source": source
                        })
        return result




if __name__ == '__main__':
    url = "http://caucho.com/products/resin/download/archive"
    obj = Task(url)
    print(obj.get_info())
