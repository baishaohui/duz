# -*- coding: utf-8 -*-
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("section", attrs={"id": "layout-content"})
        result = []
        if section:
            item_list = section.find_all("section", "version")
            if item_list:
                for item in item_list:
                    pub_date = item.find("time", "releasedate").get("datetime")
                    elements = item.find_all("li")
                    for element in elements:
                        link = element.find("a")
                        if link:
                            link = link.get("href")
                            title = element.get_text().strip()
                            result.append({"title": title, "link": link, "pub_date": pub_date, "source": self.url})
        return result


if __name__ == '__main__':
    obj = Task("http://www.php.net/ChangeLog-5.php")
    print(obj.get_info())