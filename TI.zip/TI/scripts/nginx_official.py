# -*- coding: utf-8 -*-
import datetime
import requests
from bs4 import BeautifulSoup as bs
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("div", attrs={"id": "content"})
        result = []
        if section:
            item_list = section.select("li > p")
            if item_list:
                for item in item_list:
                    for tag in item.find_all("a"):
                        if tag.get("href").endswith(tag.text.strip()):
                            title = tag.text
                            link = tag.get("href")
                            if link:
                                detail = requests.get(link)
                                sp = bs(detail.text, "lxml")
                                pub_date = datetime.datetime.strptime(sp.find_all("b")[1].text,
                                                                      "%Y%m%d").strftime("%Y-%m-%d")
                                result.append({"title": title, "link": link, "pub_date": pub_date, "source": self.url})

        return result

if __name__ == '__main__':
    url = "http://nginx.org/en/security_advisories.html"
    obj = Task(url)
    print(obj.get_info())