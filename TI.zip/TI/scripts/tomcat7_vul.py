# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find(id="content")
        item_list = section.find_all("div", "text")
        item_list.pop(0)
        item_list.pop(0)
        # # print(item_list)
        result = []
        for index, item in enumerate(item_list):
            print(item.previous_element)
            # print(item.find("strong").parent.text.replace("\n", " ").strip() )
            # print(item.find("strong").parent.find("a")["href"])
            # for p in item.strong.find_all("p")

        #     if index != 0:, "
        #         ele = item.select(".new")[0].find("a", "xst")
        #         title = ele.text
        #         title = ele.text
        #         link = ele["href"]
        #         time = item.select(".by")[0].find("span").text
        #         result.append({"title": title, "link": link, "pub_date": time, "source": self.url})
        # return result


if __name__ == '__main__':
    obj = Task("http://tomcat.apache.org/security-7.html")
    obj.get_info()

