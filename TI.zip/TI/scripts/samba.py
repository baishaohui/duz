# -*- coding: utf-8 -*-
import datetime

from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("table", "security_table")
        result = []
        if section:
            item_list = section.find_all("tr")
            if item_list:
                for item in item_list:
                    if not item.find_all("em") or item.find_all("th"):
                        elements = item.find_all("td")
                        if elements:
                            date_str = elements[0].get_text()
                            try:
                                pub_date = datetime.datetime.strptime(
                                    date_str, "%d %B %Y").strftime("%Y-%m-%d")
                            except ValueError:
                                pub_date = datetime.datetime.strptime(
                                    date_str.replace("Sept", "Sep"), "%d %b %Y").strftime("%Y-%m-%d")
                            details = elements[4].find_all("a")
                            links = elements[5].find_all("a")
                            for i in range(len(details)):
                                title = details[i].get_text()
                                try:
                                    link = self.link_formatter(links[i].get("href"))
                                except IndexError:
                                    link = self.link_formatter(links[i-1].get("href"))
                                result.append(
                                    {"title": title,
                                     "link": link,
                                     "pub_date": pub_date,
                                     "source": self.url}
                                )
        return result


if __name__ == '__main__':
    obj = Task("https://www.samba.org/samba/history/security.html")
    print(obj.get_info())