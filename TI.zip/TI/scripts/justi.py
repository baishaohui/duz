# -*- coding: utf-8 -*-
import datetime
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("ul")
        print(section)
        item_list = section.find_all("li")
        result = []
        for item in item_list:
            pub_date = item.find("span").get_text()
            title = item.find("a")
            link = self.link_formatter(title.get("href"))
            title = title.get_text()
            pub_date = datetime.datetime.strptime(pub_date, "%b %d, %Y").strftime("%Y-%m-%d")
            result.append({"title":title,"link": link, "pub_date": pub_date, "source": self.url})
        return result


if __name__ == '__main__':
    url = "https://justi.cz/"
    obj = Task(url)
    print(obj.get_info())