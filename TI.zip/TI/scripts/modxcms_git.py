# -*- coding: utf-8 -*-
import datetime
from bs4 import BeautifulSoup
from urllib.parse import urlparse, urljoin

from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        main_section = soup.find("div", "commits-listing")
        date_item_list = main_section.find_all("div", "commit-group-title")
        link_item_list = main_section.find_all("ol", "commit-group")
        result = []
        for item in date_item_list:
            date_str = datetime.datetime.strptime(item.text.lstrip("\nCommits on ").rstrip(), "%b %d, %Y")
            result.append({"pub_date": date_str.strftime("%Y-%m-%d"), "source": self.url})
        for index, item in enumerate(link_item_list):
            link_title = item.find("a", "message")
            result[index]["title"] = link_title.text
            result[index]["link"] = urljoin(self.url, link_title["href"])
        return result


if __name__ == '__main__':
    obj = Task("https://github.com/modxcms/revolution/commits/2.x/core/docs/changelog.txt")
    obj.get_info()