# -*- coding: utf-8 -*-
from urllib.parse import urljoin
from . import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.select(".width-auto > tbody > tr")
        result = []
        for item in section:
            ele_list = item.find_all("td")
            time = ele_list[0].text
            title = ele_list[1].text.strip()
            link = ele_list[1].find("a")["href"]
            if not (link.startswith("http://") or link.startswith("https://")):
                link = urljoin(self.url, link)
            result.append({"title": title, "link": link, "pub_date": time, "source": self.url})
        return result

if __name__ == '__main__':
    url = ""