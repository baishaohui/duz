# -*- coding: utf-8 -*-
import datetime
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        # soup = soup.prettify()
        print(soup)
        section = soup.find("body > center")
        print(section)
        result = []
        if section:
            item_list = section.select("table > tbody > tr center > table > tbody > tr")
            if item_list:
                print(item_list)
                # for item in item_list:
                #     elements = item.find_all("td")
                #     title_link = elements[0].find("a")
                #     title = title_link.text.strip()
                #     link = self.link_formatter(title_link.get("href"))
                #     pub_date = elements[-1].text.strip()
                #     print(title, link, pub_date)
                #     result.append({"title": title, "link": link, "pub_date": pub_date, "source": self.url})
        return result


if __name__ == '__main__':
    obj = Task("https://securitytracker.com/archives/summary/9000.html")
    data = obj.get_info()
    print(data)
