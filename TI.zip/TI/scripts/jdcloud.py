# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = BeautifulSoup(self.response, "lxml")
        section = soup.find("div", "list-content-item")
        item_list = section.find_all("a")
