# -*- coding: utf-8 -*-
import datetime
from urllib.parse import urljoin
import requests
from bs4 import BeautifulSoup as bs
from scripts import ScrawlAbstract

class Task(ScrawlAbstract):

    def item_date(self, link):
        resp = requests.get(link)
        sp = bs(resp.text, "lxml")
        date_str = sp.find("td", "field-body").text
        date = datetime.datetime.strptime(date_str, "%d.%m.%Y").strftime("%Y-%m-%d")
        return date

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("div", "compound")
        item_list = section.find_all("a", "internal")
        result = []
        for item in item_list:
            title = item.text
            link = urljoin(self.url, item["href"])
            date = self.item_date(link)
            result.append({"title": title, "link": link, "pub_date": date, "source": self.url})
        return result


if __name__ == '__main__':
    obj = Task("http://docs.couchdb.org/en/2.2.0/cve/index.html")
    obj.get_info()