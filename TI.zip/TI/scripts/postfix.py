# -*- coding: utf-8 -*-
import datetime

from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("div", attrs={"id": "main"})
        result = []
        if section:
            item_list = section.select("ul > li")
            if item_list:
                for item in item_list:
                    text = item.get_text()
                    date_str, title = text.split(":", 1)
                    title = title.strip().replace("\n", " ")
                    try:
                        pub_date = datetime.datetime.strptime(date_str.strip(), "%b %d, %Y").strftime("%Y-%m-%d")
                    except ValueError:
                        pub_date = datetime.datetime.strptime(date_str.strip(), "%B %d, %Y").strftime("%Y-%m-%d")
                    a_tag = item.find("a")
                    link = a_tag.get("href") if a_tag else self.url
                    result.append({"title": title, "link": link, "pub_date": pub_date, "source": self.url})
        return result


if __name__ == '__main__':
    obj = Task("http://www.postfix.org/announcements.html")
    print(obj.get_info())