# -*- coding: utf-8 -*-
import re
from urllib.parse import urljoin
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.select("body > ul")
        item_list = section[0].find_all("li")
        date_pattern = re.compile("\d+/\d+/\d+")
        result = []
        for item in item_list:
            title_link = item.find("a")
            title = title_link.text.strip()
            link = urljoin(self.url, title_link.get("href"))
            data_match = re.search(date_pattern, item.text)
            date = data_match.group().replace("/", "-")
            result.append({"title": title, "link": link, "pub_date": date, "source": self.url})
        return result


if __name__ == '__main__':
    url = "http://www.openwall.com/lists/oss-security/"
    obj = Task(url)
    print(obj.get_info())
