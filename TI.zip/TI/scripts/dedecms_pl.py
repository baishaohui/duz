# -*- coding: utf-8 -*-
import datetime
import re
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("div", "span9")
        result = []
        if section:
            item_list = section.find_all("section")
            if item_list:
                theme = "DedeCMS"
                for item in item_list:
                    title = theme + item.find("h4").text.split("\n")[0].strip()
                    link = self.url
                    has_date = re.findall("\d+", item.find("p").text)
                    time = ""
                    if has_date:
                        time = datetime.datetime.strptime(has_date[0], "%Y%m%d").strftime("%Y-%m-%d")
                    result.append({"title": title, "link": link, "pub_date": time, "source": self.url})

        return result


if __name__ == '__main__':
    obj = Task("http://www.dedecms.com/pl/")
    data = obj.get_info()
    print(data)
