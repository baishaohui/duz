# -*- coding: utf-8 -*-
import re
import datetime
from bs4 import BeautifulSoup as bs
import requests

from scripts import ScrawlAbstract
from tools.translator import Translator
from db import DBHandler
from config import DB_CONFIG


class Task(ScrawlAbstract):
    cve_pattern = re.compile("CVE-\d+-\d+")

    def __init__(self, url, method="get", params=None, load_js=False):
        self.update_links = []
        super(Task, self).__init__(url, method=method, params=params, load_js=load_js)
        self.initial_db()

    def initial_db(self):
        db = DBHandler(
            DB_CONFIG.get("host"),
            DB_CONFIG.get("port"),
            DB_CONFIG.get("user"),
            DB_CONFIG.get("password"),
            DB_CONFIG.get("vul_db")
        )
        self.db = db

    def fetch_link(self):
        soup = self.initial_soup
        data_list = soup.select("#main-content .row .col-8 > h3")
        for data in data_list:
            title = data.get_text()
            aid = title.split(":")[0]
            link = data.find("a")["href"]
            pub_date = datetime.datetime.now().date()
            translated_title = self.translate_title(title)
            if self.db.count("vul_advisory", {"aid": aid}):
                continue
            self.update_links.append(
                {"aid": aid, "title": title, "link": link, "pub_date": pub_date, "translated_title": translated_title,
                 "advisory_type": 1, "is_translated": 0, "record_time": datetime.datetime.now(),
                 "gmt_modified": datetime.datetime.now()})

    @staticmethod
    def translate_title(title: str):
        title = title.replace("Linux kernel vulnerabilities", "Linux内核漏洞").replace(
            "vulnerabilities", "漏洞").replace("vulnerability", "漏洞").replace("and", "和")
        return title

    def request_detail(self):
        self.fetch_link()
        self.store(self.update_links, "vul_advisory", ("aid",))
        for link in self.update_links:
            document = requests.get(link.get("link"))
            details = self.fetch_detail(document.text)
            self.db.update("vul_advisory", details, condition={"aid": link.get("aid")})
            # details.setdefault("aid", link.get("aid"))
            # self.store_affect_release(details)

    def fetch_detail(self, document):
        soup = bs(document, "lxml")
        section = soup.find("div", "col-8")
        pub_date = datetime.datetime.strptime(section.find("em").get_text(), "%d %B %Y")
        advisory_body = section.__str__()
        description_part = section.find("h3", attrs={"id": "details"})
        description = self.compile_detail(description_part)
        cves = self.fetch_cves(section)
        affect_versions = self.fetch_release(section)
        return {"advisory_body": advisory_body, "pub_date": pub_date, "description": description,
                "translation": "", "cves": cves, "affect_versions": affect_versions.strip().lower()}

    @staticmethod
    def compile_detail(tag_obj):
        detail_list = []
        for p in tag_obj.next_elements:
            if not p.name or p.name == "h3":
                continue
            if p.name and p.name != "p":
                break
            detail_list.append(p.__str__())
        description = "".join(detail_list)
        return description

    # @staticmethod
    # def detail_translation(description):
    #     translator = Translator()
    #     translation = translator.translate(description, format_type="html")
    #     return translation

    @classmethod
    def fetch_cves(cls, tag_obj):
        text = tag_obj.get_text()
        cves = ",".join(set(re.findall(cls.cve_pattern, text)))
        return cves.lower()

    @staticmethod
    def fetch_release(tag_obj):
        return tag_obj.find("ul").get_text()

    # def store_affect_release(self, item):
    #     version_list = item.get("affect_versions", "").split("\n")
    #     for version in version_list:
    #         if version:
    #             data_dict = {"aid": item.get("aid").lower(), "`type`": version, "cve_id": version}
    #             if not self.db.count("vul_rule_usn_aid", condition=data_dict):
    #                 self.db.create("vul_usn_platform_cve", data_dict)

    def store(self, data, table, fields):
        if data:
            for item in data:
                if not self.db.count(table, condition={field: item.get(field) for field in fields}):
                    print(item.get("aid"))
                    self.db.create(table, item)

    def scan(self):
        print(self.url)
        self.request_detail()


if __name__ == '__main__':
    # from concurrent.futures import ThreadPoolExecutor, wait
    # task_list = []
    # with ThreadPoolExecutor(20) as e:
    #     for i in range(1, 10):
            obj = Task("https://usn.ubuntu.com/")
            # task_list.append(e.submit(obj.scan))
            obj.scan()
        # wait(task_list)
