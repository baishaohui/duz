# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup
from urllib.parse import urljoin

from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        main_section = soup.find("div", "notice-list")
        li_list = main_section.find_all("li", "content-item")
        result = []
        for i in li_list:
            time = i.find("span", "time").text
            content = i.find("span", "content")
            link = content.find("a")["href"]
            title = content.text.strip()
            if not (link.startswith("http") or link.startswith("https")):
                link = urljoin(self.url, link)
            result.append({"title": title, "link": link, "pub_date": time, "source": self.url})

        return result


if __name__ == '__main__':
    url = ""