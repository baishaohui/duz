# -*- coding: utf-8 -*-
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.select(".body > .col-md-12 > .container > .row")[1]
        item_list = section.select(".container > .row > ul > li")
        result = []
        for index, item in enumerate(item_list):
            title_link = item.find("a")
            title = title_link.text.strip()
            link = title_link["href"]
            time = title.rsplit(" ", 1)[-1]
            result.append({"title": title, "link": link, "pub_date": time, "source": self.url})
        return result


if __name__ == '__main__':
    obj = Task("https://jenkins.io/security/advisories/")
    obj.get_info()

