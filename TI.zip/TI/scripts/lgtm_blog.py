# -*- coding: utf-8 -*-
from scripts import ScrawlAbstract
import datetime
import json


class Task(ScrawlAbstract):

    def __init__(self, url, method="get", params=None, load_js=True):
        super(Task, self).__init__(url, method=method, params=params, load_js=load_js)

    def get_info(self):
        soup = self.initial_soup
        content = soup.select("script[data-path='/internal_api/v0.2/getBlogPosts']")
        json_str = content[0].get_text()
        if json_str:
            item_dict = json.loads(json_str)
            if item_dict:
                data = []
                for link, item in item_dict.items():
                    link = self.link_formatter(link)
                    title = item.get("title")
                    summary = item.get("description")
                    pub_date = datetime.datetime.fromtimestamp(item.get("date") // 1000).strftime(
                        "%Y-%m-%d")
                    data.append(
                        {"title": title, "link": link, "summary": summary, "pub_date": pub_date, "source": self.url})
                return data


if __name__ == '__main__':
    obj = Task(url="https://lgtm.com/blog/")
    obj.get_info()
