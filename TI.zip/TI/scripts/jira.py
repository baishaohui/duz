# -*- coding: utf-8 -*-
import datetime

from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("ol", "issue-list")
        # section = soup.find("table", attrs={"id": "issuetable"})
        # section = section.find("tbody")
        item_list = section.find_all("li")
        # item_list = section.find_all("tr")
        results = []
        for item in item_list:
            title = item["title"]
            link_tag = item.find("a", "splitview-issue-link")
            link = self.link_formatter(link_tag["href"])
            pub_date = datetime.date.today()
            results.append(dict(title=title, link=link, source=self.url, pub_date=pub_date))
        # for item in item_list:
        #     title = item.find("td", "summary")
        #     link_tag = title.find("a", "issue-link")
        #
        #     title = title.get_text(strip=True)
        #     link = self.link_formatter(link_tag["href"])
        #     pub_date = item.find("td", "created").get_text()
        #     results.append(dict(title=title, link=link, source=self.url, pub_date=pub_date))
        return results


if __name__ == '__main__':
    # url = "https://issues.apache.org/jira/issues/?filter=-4"
    url = "https://issues.apache.org/jira/issues/?filter=-4"
    obj = Task(url)
    print(obj.get_info())