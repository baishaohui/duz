# -*- coding: utf-8 -*-
from scripts import ScrawlAbstract
import datetime


class Task(ScrawlAbstract):

    def __init__(self, *args, **kwargs):
        super(Task, self).__init__(*args, **kwargs, load_js=True)

    def get_info(self):
        soup = self.initial_soup
        print(soup)


if __name__ == '__main__':
    url = "https://nosec.org/home/index/threaten.html"
    obj = Task(url)
    obj.get_info()