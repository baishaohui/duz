# -*- coding: utf-8 -*-
import datetime
import requests
from selenium.webdriver.common.by import By

from scripts import ScrawlAbstract

headers = {
    'accept': "application/json, text/javascript, */*; q=0.01",
    'accept-encoding': "gzip, deflate, br",
    'accept-language': "zh-CN,zh;q=0.9",
    'content-type': "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
    'cookie': "_cfuid=36c246bc-d711-4ef0-939b-96c6a148d12b; __cfduid=d2558e1d0bf5f471d2e0aee40312a59401567785229; _ga=GA1.2.1240667727.1567785236; __Host-session=OGtKZXVFTWNKUEVESGlodEFWRGhJK3QxYkx1aUhvai9TY0Y5RjVFelowSm5GUFZKQWZ3QmsrSU02RFVsTFhjVjVCMlU2d3cyd0xCWjI1WUx4czRzTkpqS010eEtQNWE5YnJyeVFtSlh1SCtqcnR2VHphZkhFcFFrMm5QeDJSZXdmQ2FvdU5lWndzRk1VT3UvNGJmOXF3PT0tLW5SUTJ5d09EVTJUUW10Uk11blBBUmc9PQ%3D%3D--e2b1511c9e430da52953edfd636aab15092f91d3",
    'referer': "https://hackerone.com/hacktivity?sort_type=latest_disclosable_activity_at&filter=type%3Apublic&page=1",
    'user-agent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
    'x-requested-with': "XMLHttpRequest",
    'cache-control': "no-cache",
}


class Task(ScrawlAbstract):
    headers = headers

    def __init__(self, url, method="get", params=None, load_js=True):
        super(Task, self).__init__(url, method, load_js=load_js, params=params)

    @staticmethod
    def initial_header():
        return headers

    def get_info(self):
        result = []
        titles = self.driver.find_elements(By.CLASS_NAME, "fade")
        for title in titles:
            print("obj: ", title)
            try:
                title_link = title.find_element(By.CLASS_NAME, "spec-hacktivity-item-title")
                t = title_link.text
                print(t)
                link = title_link.get_attribute("href")
                if link is None:
                    continue
                print("link: ", link)
                content = title_link.find_element_by_css_selector("strong")
                content = content.text
                print("title: ", content)
                date = title.find_element_by_css_selector(".spec-hacktivity-item-timestamp > span")
                release = date.get_attribute("title")
                if not release:
                    continue
                dt, zone = release.rsplit(" ", 1)
                pub_date = datetime.datetime.strptime(dt, "%B %d, %Y %H:%M:%S")
                print(dt, zone)
                result.append({"title": t, "pub_date": pub_date, "link": link, "source": self.url})

            except Exception as e:
                print(e)
        self.driver.close()
        self.driver.quit()
        return result


if __name__ == '__main__':
    # url = "https://hackerone.com/hacktivity?sort_type=latest_disclosable_activity_at&page=1&filter=type%3Apublic"
    url = "https://hackerone.com/hacktivity?order_direction=DESC&order_field=popular&filter=type%3Aall"
    # obj = Task("https://hackerone.com/hacktivity?sort_type=latest_disclosable_activity_at&filter=type%3Apublic&page=1")
    obj = Task(url)
    obj.scan()
