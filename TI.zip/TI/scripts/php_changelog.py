# -*- coding: utf-8 -*-
import datetime
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("section", attrs={"id": "layout-content"})
        if section:
            item_list = section.find_all("section", "version")
            if item_list:
                for item in item_list:
                    print(item.find("time").get("datetime"))
                    for element in item.select("ul > li li"):
                        print(element)


if __name__ == '__main__':
    url = "http://www.php.net/ChangeLog-5.php"
    obj = Task(url)
    obj.get_info()
