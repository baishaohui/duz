# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = BeautifulSoup(self.response, "lxml")
        section = soup.find(id="threadlist").find("div", "bm_c")
        item_list = section.find_all("tr")
        result = []
        for index, item in enumerate(item_list):
            if index != 0:
                ele = item.select(".new")[0].find("a", "xst")
                title = ele.text
                link = ele["href"]
                time_tag_list = item.select(".by")[0].find_all("span")
                time_tag = time_tag_list[-1]
                pub_date = time_tag.get("title") if time_tag.get("title") else time_tag.text
                result.append({"title": title, "link": link, "pub_date": pub_date, "source": self.url})
        return result


if __name__ == '__main__':
    obj = Task("http://bbs.qcloud.com/forum.php?mod=forumdisplay&fid=42&filter=typeid&typeid=433")
    print(obj.get_info())

