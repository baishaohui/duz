# -*- coding: utf-8 -*-
from datetime import datetime
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("table", "widefat")
        result = []
        if section:
            item_list = section.find_all("tr")
            if item_list:
                for item in item_list:
                    if item.find("span", "date"):
                        pub_date = datetime.strptime(item.find("span", "date").text.strip(),
                                                     "%B %d, %Y").strftime("%Y-%m-%d")
                        title_tag = item.find("a")
                        title = title_tag.get_text()
                        link = self.link_formatter(title_tag.get("href"))
                        result.append({
                            "title": title,
                            "link": link,
                            "source": self.url,
                            "pub_date": pub_date
                        })
        return result


if __name__ == '__main__':
    url = "https://wordpress.org/news/category/releases/"
    obj = Task(url)
    print(obj.get_info())