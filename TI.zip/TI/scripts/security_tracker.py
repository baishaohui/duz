# -*- coding: utf-8 -*-
import datetime
from urllib.parse import urljoin
from bs4 import BeautifulSoup as bs
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find_all("center")[-1]
        item_list = section.select("tr")
        print(item_list)
        result = []
        # for item in item_list:
        #     ele_list = item.find_all("td")
        #     print(ele_list[0].get_text().replace(" ", ""))
        #     date = datetime.datetime.strptime(ele_list[0].get_text().strip(), "%b %d %Y").strftime("%Y-%m-%d")
        #     ele = ele_list[1].find("a")
        #     title = ele.text.strip()
        #     link = urljoin(self.url, ele.get("href"))
        #     result.append({"title": title, "link": link, "source": self.url, "pub_date": date})
        print(result)
        return result


if __name__ == '__main__':
    url = "https://securitytracker.com/archives/summary/9000.html"
    obj = Task(url)
    obj.get_info()