# -*- coding: utf-8 -*-
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def __init__(self, load_js=True, *args, **kwargs):
        super(Task, self).__init__(load_js=load_js, *args, **kwargs)
        self.cookies = {
            "__cfduid": "da4f87f643aa68a82dd0935dbade5f9171552530978",
            "cf_clearance": "11c8f3958520b510309499ba6f56e1a19d1303c6-1552530983-604800-150",
            "_ga": "GA1.2.1006712640.1552530985",
            "_gid": "GA1.2.1232909311.1552530985",
            "__hstc": "145519147.4329c47257a1df103c78246f382deccb.1552530985655.1552530985655.1552530985655.1",
            "hubspotutk": "4329c47257a1df103c78246f382deccb",
            "__hssrc": "1",
            "__hssc": "145519147.2.1552530985655",
        }

    def initial_header(self):
        header = super(Task, self).initial_header()
        header.update({
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Cache-Control": "max-age=0",
            "Connection": "keep-alive",
            "Host": "rhinosecuritylabs.com",
            "If-Modified-Since": "Tue, 12 Mar 2019 10:41:43 GMT",
            "If-None-Match": 'W/"b534d96ebbc909aa88616e86cee1f4c3"',
            "Upgrade-Insecure-Requests": "1",
            "Cookie": """__cfduid=da4f87f643aa68a82dd0935dbade5f9171552530978; cf_clearance=11c8f3958520b510309499ba6f56e1a19d1303c6-1552530983-604800-150; _ga=GA1.2.1006712640.1552530985; _gid=GA1.2.1232909311.1552530985; __hstc=145519147.4329c47257a1df103c78246f382deccb.1552530985655.1552530985655.1552530985655.1; hubspotutk=4329c47257a1df103c78246f382deccb; __hssrc=1; __hssc=145519147.2.1552530985655"""
        })
        return header

    def get_info(self):
        soup = self.initial_soup
        print(soup)


if __name__ == '__main__':
    obj = Task(url="https://rhinosecuritylabs.com/feed/")
    obj.get_info()
