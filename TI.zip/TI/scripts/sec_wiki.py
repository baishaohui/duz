# -*- coding: utf-8 -*-
import bs4
import requests
from notification import Notification

from . import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        table = soup.select("table > tbody")
        result = []
        for ele in table:
            tr = ele.find_all("tr")
            for td in tr:
                time = td.find_all("td")[0].text
                link_tag = td.find_all("td")[1]
                title = link_tag.text
                link = link_tag.find("a")["href"]
                result.append({"title": title, "link": link, "pub_date": time, "source": self.url})

        return result


if __name__ == '__main__':
    url=""