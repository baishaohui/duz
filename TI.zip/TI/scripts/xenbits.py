# -*- coding: utf-8 -*-
from scripts import ScrawlAbstract


class Task(ScrawlAbstract):

    def get_info(self):
        soup = self.initial_soup
        section = soup.find("table")
        result = []
        if section:
            item_list = section.select("tr")
            item_list.pop(0)
            item_list.pop()
            if item_list:
                for item in item_list:
                    elements = item.find_all("td")
                    title = elements[-1].get_text()
                    link_ele = elements[0].find("a")
                    link = self.link_formatter(link_ele.get("href")) if link_ele else self.url
                    pub_date = elements[1].get_text().split(" ")[0]
                    summary = elements[-2].get_text()
                    result.append({
                        "title": title,
                        "link": link,
                        "pub_date": pub_date,
                        "source": self.url,
                        "summary": summary
                    })
        return result


if __name__ == '__main__':
    url = "http://xenbits.xen.org/xsa/"
    obj = Task(url)
    print(obj.get_info())