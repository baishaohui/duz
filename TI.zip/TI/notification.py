import json
import uuid
import requests
from math import ceil

from urllib.parse import quote_plus
from concurrent.futures import ThreadPoolExecutor

import time
from aliyunsdkdysmsapi.request.v20170525 import SendSmsRequest
from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.profile import region_provider

from config import DING_TEMPLATE, APP_KEY
from config import DYSMS_CONFIG
from db import db_con
from config import SHORT_URL_SOURCE
from config import SHORT_URL
from config import NON_INTELLEGENCE_WARNING


class Notification(object):

    def __init__(self, data=None):
        self.db = db_con()
        self.data = data
        self.targets = []
        self.source = []
        self.shorten_url = SHORT_URL
        self.appkey = APP_KEY
        self.shorten_limit = 20
        self.template = DING_TEMPLATE
        self.access_key = DYSMS_CONFIG["access_key"]
        self.access_secret = DYSMS_CONFIG["access_secret"]
        self.region = DYSMS_CONFIG["region"]
        self.product_name = DYSMS_CONFIG["product_name"]
        self.domain = DYSMS_CONFIG["domain"]
        self.template_code = DYSMS_CONFIG["template_code"]
        self.template_params = {"title": "", "link": "", "date": ""}
        self.sign_name = ""
        self.acs_client = AcsClient(self.access_key, self.access_secret, self.region)
        self.initial_endpoint()
        self.chunks = []

    def initial_endpoint(self):
        """
        初始化endpoint
        :return:
        """
        region_provider.add_endpoint(self.product_name, self.region, self.domain)

    def initial_chunks(self):
        if self.chunks:
            self.chunks.clear()
        # if self.data is None:
        #     self.data = self.collect_data()
        chunk_num = ceil(len(self.data) / 40)
        for num in range(0, int(chunk_num)):
            data = self.data[40 * num: 40 * (num + 1)]
            self.chunks.append(self.initial_ding_template(data))

    def initial_ding_template(self, items):
        temp = ""
        if items:
            notify_list = self.shorten_urls(items)
            for item in notify_list:
                temp += "#### %s \n\n[%s](%s)\n\n &nbsp; \n\n" % (
                    item.get("title").strip(),
                    # "[译文] " + item.get("translation") if item.get("translation") else "",
                    item.get("url_raw"),
                    item.get("url_raw")
                )
                self.store_short_url(item)
            # temp += "\n\n &nbsp; \n\n > 共%d条记录" % len(notify_list)
            return temp.strip().strip("&nbsp;")

    def store_short_url(self, item):
        self.db.update(
            "record",
            {
                "short_url": item.get("url_short")
            },
            condition={
                "link": item.get("url_raw")
            }
        )

    def dwz(self, url):
        quote_url = quote_plus(url)
        params = {'long_url': quote_url, 'appkey': self.appkey}
        try:
            response = requests.get(url=self.shorten_url, params=params)
            return response.json()
        except Exception as e:
            print(e)
            return {"url_long": url, "short_url": url}

    # def dwz(self, url):
    #     if isinstance(url, list):
    #         url = "\n".join(url)
    #     long_url = quote_plus(url)
    #     params = {'url': long_url, 'key': self.appkey, "expireDate": "2020-03-31", "format": "json"}
    #     try:
    #         response = requests.get(url=self.shorten_url, params=params)
    #         return response.json()
    #     except Exception as e:
    #         print(e)
    #         return {"url": long_url}

    # def dwz(self, url):
    #     if isinstance(url, list):
    #         url = "\n".join(url)
    #     long_url = quote_plus(url)
    #     params = {'urlListStr': long_url, 'key': self.appkey,
    #               "expireType": "5", "domain": "suo.im",
    #               "mark": "cd0b93633002b5ba3051b3943bc33a29",
    #               "random": "1569485640155"}
    #     headers = {
    #         'accept': "application/json, text/javascript, */*; q=0.01",
    #         'content-type': "application/x-www-form-urlencoded; charset=UTF-8",
    #         'origin': "http://home.suolink.cn",
    #         'referer': "http://home.suolink.cn/ucenter/mult/tinyurl/create.htm",
    #         'user-agent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36",
    #         'cache-control': "no-cache",
    #     }
    #     response = requests.get("http://home.suolink.cn/ucenter/mult/tinyurl/create.htm", headers=headers)
    #     print(response)
    #     print(response.text)
    #     cookie = response.cookies
    #     try:
    #         response = requests.post(url=self.shorten_url, data=json.dumps(params), headers=headers, cookies=cookie)
    #         print(response)
    #         print(response.text)
    #         print(response.json())
    #         return response.json()
    #     except Exception as e:
    #         print(e)
    #         return {"url": long_url}

    def shorten_urls(self, items):
        notify_info = []
        data = items
        urls = []
        for item in data:
            long_url = item.get("link")
            try:
                dwz_dict = self.dwz(long_url)
                short_url = dwz_dict.get("short_url")
                time.sleep(2)
                url = {"url_short": short_url, "url_long": long_url, "type": 0}
            except Exception as e:
                print(e)
                url = {"url_short": long_url, "url_long": long_url, "type": 0}
            urls.append(url)
        for u in urls:
            for item in items:
                if item.get("link") == u.get("url_long") or item.get("link") == u.get("url_short"):
                    notify_info.append(
                        {
                            "title": item.get("title"),
                            "url_raw": u.get("url_long"),
                            "url_short": u.get("url_short"),
                            "translation": item.get("translation")
                        }
                    )
        return notify_info

    def collect_data(self):
        """查询上次收集的情报信息"""
        data = self.db.list(
            "record",
            ("title", "link", "source", "pub_date", "translation"),
            condition={"has_sent": 0, "is_intelligence": 1}
        )
        return data

    def update_db(self):
        self.db.update(
            "record",
            {"has_sent": 1},
            condition="id in (select temp.id from (select * from record where has_sent=0 and is_intelligence=1) as temp)"
        )

    @property
    def clients(self):
        """
        获取钉钉机器人列表和手机列表
        """
        # sql = "select mobile, ding_url from client where active=1"
        # clients = fetch_data(sql)
        clients = self.db.list("client", ("mobile", "ding_url"), condition={"active": 1})
        return clients

    def ding_request(self, target):
        header = {"Content-Type": "application/json; charset=utf-8"}
        # msg = json.dumps(self.template)
        response = requests.post(target, json=self.template, headers=header)
        return response.json().get("errcode")

    def ding(self, target):
        """发送钉钉消息"""
        self.initial_chunks()
        if self.chunks:
            for chunk in self.chunks:
                self.template["markdown"]["text"] = chunk
                response = self.ding_request(target)

    def text(self, phone_numbers):
        """
        发送短信
        :param business_id: smsReq设置业务请求流水号，必填
        :param phone_numbers: 短信发送的号码列表，必填
        :param sign_name: 短信签名
        :param template_code: 申请的短信模板编码,必填
        :param template_param: 短信模板变量参数
        :return:
        """
        smsRequest = SendSmsRequest.SendSmsRequest()
        smsRequest.set_TemplateCode(self.template_code)
        if self.template_params is not None:
            smsRequest.set_TemplateParam(self.template_params)
        smsRequest.set_OutId(uuid.uuid1())
        smsRequest.set_SignName(self.sign_name)
        smsRequest.set_PhoneNumbers(phone_numbers)
        # 调用短信发送接口，返回json
        smsResponse = self.acs_client.do_action_with_exception(smsRequest)
        print(smsResponse)
        return smsResponse.decode("utf-8")

    def send_single(self, ding_url):
        # if mobile:
        #     self.text(mobile)
        if ding_url:
            self.ding(ding_url)

    def send(self, client=None):
        """同时发送钉钉和短信"""
        for client in self.clients:
            with ThreadPoolExecutor(max_workers=5) as executor:
                task = executor.submit(self.send_single, client.get("ding_url"))
                task.result()
        self.update_db()


if __name__ == '__main__':
    notify = Notification()
    # notify.send()
    # from db import db_con
    # conn = db_con()
    # result = conn.list("info_source", "target")
    # # print(result)
    # result = [r.get("target") for r in result]
    # for i in result:
    #     print(notify.dwz(i))
    #     time.sleep(2)
    # notify.dwz(result)
    from urllib.parse import unquote
    # print("\n".join(result[:50]))
    # print(notify.dwz("http://feedproxy.google.com/~r/PentestTools/~3/bewtEc2_F7w/linpwn-interactive-post-exploitation.html"))
    # print()
    res = notify.dwz("https://posts.specterops.io/covenant-developing-custom-c2-communication-protocols-895587e7f325?source=rss----f05f8696e3cc---4")
    print(res)

