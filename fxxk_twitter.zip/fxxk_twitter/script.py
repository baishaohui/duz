# -*- coding: utf-8 -*-
import json


with open("word_tweets.json", "r") as f:
    data = json.load(f)

string = []

for d in data.values():
    for item in d:
        title = item.get("title")
        string.append(title)

text = "\n\n-------------------------------------------------\n\n".join(string)

with open("tweet.txt", "w") as w:
    w.write(text)
