# -*- coding: utf-8 -*-
import datetime

from peewee import *

from config import DATABASE_CONFIG

database = DATABASE_CONFIG.copy()

base = database.pop("db")

db = MySQLDatabase(base, **database)


class QueryModel(Model):
    word = CharField(128, verbose_name="twitter word")
    search_type = CharField(
        choices=(("user", "user"), ("query", "query")),
        default="user", verbose_name="twitter type")
    enabled = BooleanField(default=True)
    create_time = DateTimeField(default=datetime.datetime.now, verbose_name="create time")

    class Meta:
        database = db
        table_name = "query"

    def __str__(self):
        return self.word


class TwitterRecordModel(Model):
    tweet_id = BigIntegerField(primary_key=True)
    title = TextField()
    publish_time = DateTimeField()
    link = CharField(null=True)
    source = CharField(null=True)
    create_time = DateTimeField(default=datetime.datetime.now)

    class Meta:
        database = db
        table_name = "twitter"

    def __str__(self):
        return self.tweet_id


if __name__ == '__main__':
    db.create_tables([QueryModel, TwitterRecordModel])