# -*- coding: utf-8 -*-
import random
import time
import datetime
from apscheduler.schedulers.background import BlockingScheduler

from logger import logger
from fxxk_twitter import tweet_spider
from models import QueryModel

tweet_job_config = {
    "trigger": "interval",
    "hours": 1,
    "minutes": 30
}


class Engine(object):
    scheduler_class = BlockingScheduler
    query_class = QueryModel

    def __init__(self, schedule_config=None):
        self.schedule_config = schedule_config or tweet_job_config
        self.twitter_spider = tweet_spider
        self.schedule = None

    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, "instance"):
            cls.instance = super(Engine, cls).__new__(cls)
            return cls.instance

    def spider_query_job(self, query):
        word = query.word
        type_ = query.search_type
        if type_ == "user":
            self.twitter_spider.crawl(word)
        elif type_ == "query":
            self.twitter_spider.search(word)

    def job(self):

        logger.info(f"Job start at {datetime.datetime.now()}")
        model = self.query_class
        queries = model.select().where(model.enabled == True)
        for query in queries:
            try:
                self.spider_query_job(query)
            except Exception as e:
                logger.error(str(e))
                self.twitter_spider.reset_headless_driver()
                try:
                    self.spider_query_job(query)
                except Exception as e:
                    logger.error(str(e))
            time.sleep(random.randint(15, 45))
        logger.info(f"Job finish at {datetime.datetime.now()}")

    def reset_config(self, config):
        self.schedule_config = config
        if self.schedule is None:
            self.run()
        else:
            self.schedule.add_job(
                self.job, name="twitter",
                replace_existing=True,
                **self.schedule_config)

    def run(self):
        scheduler = self.scheduler_class()
        scheduler.add_job(
            self.job, name="twitter",
            next_run_time=datetime.datetime.now(),
            **self.schedule_config)
        self.schedule = scheduler
        scheduler.start()


engine = Engine()


if __name__ == '__main__':
    # test_config = {
    #     "trigger": "cron",
    #     "hour": 9,
    #     "minute": 22
    # }
    # engine.reset_config(test_config)
    engine.run()