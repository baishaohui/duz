# -*- coding: utf-8 -*-
import os
import json
import time
import random
import logging
import datetime
from urllib.parse import urljoin, quote

from bs4 import BeautifulSoup
from peewee import IntegrityError
from selenium.webdriver import FirefoxProfile, Firefox, FirefoxOptions
from selenium.webdriver.common.keys import Keys

from logger import logger
from models import TwitterRecordModel


class TwitterCrawler:
    origin_domain = "https://twitter.com"

    def __init__(self, executable_path="/usr/local/bin/geckodriver"):
        self.driver = None
        self.driver_path = executable_path
        self.model_class = TwitterRecordModel
        self._set_headless_driver(executable_path)

    def get(self, target, history=False):
        if self.driver is None:
            self._set_headless_driver(self.driver_path)
        logger.info(f"Start crawling {target}")
        print(self.driver)
        print(self.driver.current_window_handle)
        print(self.driver.window_handles)
        self.driver.get(target)
        time.sleep(5)
        if history:
            self.load_all()

    def load_all(self):
        load = True
        while load:
            tmp_height = self.driver.execute_script(
                "return action=document.body.scrollHeight")
            self.driver.execute_script(
                "window.scrollTo(0, document.body.scrollHeight)")
            time.sleep(random.randint(8, 15))
            height = self.driver.execute_script(
                "return action=document.body.scrollHeight")
            if tmp_height >= height:
                load = False

    @classmethod
    def with_query(cls, query):
        if not query.startswith(cls.origin_domain):
            query = (cls.origin_domain +
                     f"/search?q={quote(query)}&src=recent_search_click")
        return query

    @classmethod
    def with_user(cls, user):
        if user.__str__().startswith("https://"):
            target = user.__str__()
        else:
            target = os.path.join(cls.origin_domain, user.__str__())
        return target

    def search(self, query, history=False):
        query = self.with_query(query)
        self.get(query, history=history)
        self.parse_with_driver()
        # logger.info(f"Start crawling {query}")
        # self.driver.get(query)
        # time.sleep(5)
        # if history:
        #     self.load_all()
        # body = self.driver.find_element_by_tag_name("body")
        # for _ in range(10):
        #     body.send_keys(Keys.PAGE_DOWN)
        #     time.sleep(1)
        # tweet_list = []
        # tweets = self.driver.find_elements_by_class_name("tweet")
        # for tweet in tweets:
        #     tweet_info = self.search_one(tweet)
        #     tweet_list.append(tweet_info)
        # self.store(*tweet_list)
        # return tweet_list

    def crawl(self, user, history=False):
        user = self.with_user(user)
        self.get(user, history=history)
        self.parse_with_driver()

    def parse_with_driver(self):
        tweet_list = []
        tweets = self.driver.find_elements_by_class_name("tweet")
        for tweet in tweets:
            tweet_info = self.parse_one(tweet)
            tweet_list.append(tweet_info)
        self.store(*tweet_list)

    def parse_one(self, window):
        title = window.find_element_by_class_name("tweet-text").text
        tweet_id = window.get_attribute("data-tweet-id")
        timestamp = window.find_element_by_class_name(
            "_timestamp").get_attribute("data-time")
        pub_date = datetime.datetime.fromtimestamp(
            int(timestamp)).strftime("%Y-%m-%d %H:%M:%S")
        link = self.link_format(
            self.origin_domain, window.get_attribute("data-permalink-path"))
        source = self.driver.current_url
        return {
            "title": title,
            "tweet_id": tweet_id,
            "link": link,
            "publish_time": pub_date,
            "source": source
        }

    def __del__(self):
        if self.driver is not None:
            self.driver.quit()

    @staticmethod
    def set_driver_option():
        options = FirefoxOptions()
        options.add_argument('--headless')
        options.add_argument('--disable-gpu')
        return options

    @staticmethod
    def set_driver_profile():
        profile = FirefoxProfile()
        profile.set_preference("permissions.default.image", 2)
        # 禁用浏览器缓存
        profile.set_preference("network.http.use-cache", False)
        profile.set_preference("browser.cache.memory.enable", False)
        profile.set_preference("browser.cache.disk.enable", False)
        profile.set_preference("browser.cache.offline.enable", False)
        profile.set_preference("browser.sessionhistory.max_total_viewers", 3)
        profile.set_preference("network.dns.disableIPv6", True)
        profile.set_preference("Content.notify.interval", 750000)
        profile.set_preference("content.notify.backoffcount", 3)
        return profile

    def _set_headless_driver(self, executable_path):
        # display = Display(visible=0, size=(800, 600))
        # display.start()
        options = self.set_driver_option()
        profile = self.set_driver_profile()
        self.driver = Firefox(
            executable_path=executable_path,
            service_log_path="logs/driver_error.log",
            firefox_options=options,
            firefox_profile=profile)
        # self.driver.set_page_load_timeout(300)
        # self.driver.set_script_timeout(300)

    def reset_headless_driver(self):
        if self.driver is not None:
            self.driver.quit()
        os.system("killall firefox")  # 防止残留Firefox进程，通过命令kill
        self._set_headless_driver(self.driver_path)

    @staticmethod
    def make_soup(document):
        try:
            return BeautifulSoup(document, "lxml")
        except Exception:
            return BeautifulSoup(document, "html.parser")

    @staticmethod
    def link_format(source, link):
        if link.startswith("http://") or link.startswith("https://"):
            return link
        else:
            return urljoin(source, link)

    def parse_with_bs4(self, document, source):
        soup = self.make_soup(document)
        section = soup.find("ol", attrs={"id": "stream-items-id"})
        items = section.select(".tweet")
        results = []
        for item in items:
            tweet_id = item.get("data-tweet-id")
            link = self.link_format(self.origin_domain, item.get("data-permalink-path"))
            data_tag = item.find("span", "_timestamp")
            timestamp = data_tag.get("data-time")
            title = item.find("p", attrs={"class": "tweet-text"}).get_text().strip()
            pub_date = datetime.datetime.fromtimestamp(int(timestamp)).strftime("%Y-%m-%d")
            results.append(
                {"title": title, "link": link, "publish_time": pub_date,
                 "source": source, "tweet_id": tweet_id})
        return results

    def store(self, *data_list):
        for data in data_list:
            try:
                self.model_class.insert(**data).execute()
                logger.info(f"Tweet id {data['tweet_id']} insert success")
            except IntegrityError:
                logger.warning(f"Tweet id {data['tweet_id']} is already existed.")


tweet_spider = TwitterCrawler()


if __name__ == '__main__':
    # tweet = TwitterCrawler()
    # tweet_spider.crawl("h1_kenan")
    # tweet.crawl("mmolgtm")
    tweet_spider.search("WAF bypass")
    # run()
    # start()
