# -*- coding: utf-8 -*-

DATABASE_CONFIG = {
    "host": "rm-uf664y69l9q607xo64o.mysql.rds.aliyuncs.com",
    "user": "shaohui",
    "port": 5656,
    "password": "gha96gzTK&jm#",
    "db": "ti_db"
}

ALERT_ROBOTS = [
    "https://oapi.dingtalk.com/robot/send?access_token=e0ff8260309dcbf818336dc5722475e7ef2d037501ae64587d7b6eb6776962b7"
]

ALERT_ALL = False